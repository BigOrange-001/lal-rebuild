package com.meng52.game.module.avatar
{
   import com.meng52.game.command.avatar.AvatarData;
   import com.meng52.game.command.avatar.AvatarManager;
   import com.meng52.game.global.GlobalData;
   import com.meng52.game.global.GlobalFunction;
   import com.meng52.game.global.GlobalLanguageStr;
   import com.meng52.game.global.GlobalTextStyle;
   import com.meng52.game.module.BaseDisplayModule;
   import com.meng52.game.module.equip.Equip;
   import com.meng52.game.module.guide.GuideMaster;
   import com.meng52.game.module.map.GameMap;
   import com.meng52.game.module.map.GameMapConfig;
   import com.meng52.game.module.map.GameMapTools;
   import com.meng52.game.module.map.Random;
   import com.meng52.game.module.skill.Buff;
   import com.meng52.game.module.skill.SkillSet;
   import com.meng52.game.module.talent.Talent;
   import com.meng52.game.ui.effect.DisplayTools;
   import com.meng52.game.ui.effect.DragonBonesSprite;
   import com.meng52.game.ui.element.ProgressBar;
   import com.meng52.game.ui.map.AvatarLayer;
   import com.meng52.game.ui.map.GameMapLayer;
   import com.meng52.game.ui.panel.PanelDetailDN;
   import com.meng52.game.ui.screen.PanelCenterDNTeam;
   import com.meng52.sound.SoundManager;
   import com.meng52.utils.StarlingTools;
   import com.meng52.utils.LocalStore;
   import com.meng52.utils.Tools;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import starling.animation.Tween;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.filters.ColorMatrixFilter;
   import starling.text.TextField;

   public class Avatar extends BaseDisplayModule
   {

      public static var iconStyle:int = 1;

      public var bondLineup104:Array = null;



      // BEGIN NEW SKIN BONDS 104
      public function skinBondNumber104(key:String, fallback:Number = 0) : Number
      {
         var family:String = String(avatarData.id).split("_").slice(0,2).join("_");
         var value:Number = fallback;
         for each(var bond:Object in getBondRows104())
         {
            var benefit:Object = bond.benefits[family];
            if(benefit && benefit.mechanics && benefit.mechanics[key]!=null)
               value = Math.max(value,Number(benefit.mechanics[key]));
         }
         return value;
      }
      // END NEW SKIN BONDS 104

      private static var bondDefinitionSource104:Array;
      private static var bondFamilies104:Object;

      private static function familyBondDefinitions104(definitions:Array, family:String) : Array
      {
         if(definitions !== bondDefinitionSource104)
         {
            bondDefinitionSource104 = definitions;
            bondFamilies104 = {};
         }
         var rows:Array = bondFamilies104[family] as Array;
         if(rows == null)
         {
            rows = [];
            for each(var definition:Object in definitions)
            {
               if(definition.families.indexOf(family) >= 0) rows.push(definition);
            }
            bondFamilies104[family] = rows;
         }
         return rows;
      }

      public function getBondRows104() : Array
      {
         var definitions:Array = GlobalData.$mConfig_simple.bonds_104 as Array;
         var result:Array = [];
         if(!definitions || !avatarData) return result;
         var aid:String = String(avatarData.id);
         var parts:Array = aid.split("_");
         var family:String = parts[0]+"_"+parts[1];
         var candidates:Array = familyBondDefinitions104(definitions,family);
         if(candidates.length == 0) return result;
         var quality:int = int(parts[2]);
         var roster:Object = GlobalData.$userData;
         var aids:Array = [];
         var snapshot:Array = mData && mData.bonds_104 is Array ? mData.bonds_104 as Array : null;
         if(snapshot == null)
         {
            if(!GlobalData.modChannelAllowed(aid,"usage.destiny")) return result;
            if(!roster || !roster.team || !roster.avatars || isOthers) return result;
            var selected:int = roster.attrs && roster.attrs.team_num != null ? int(roster.attrs.team_num) : 0;
            var lineup:Array = bondLineup104 != null ? bondLineup104 : roster.team[selected] as Array;
            if(!lineup || lineup.indexOf(id)<0) return result;
            var ids:Array = lineup.concat();
            var dn:Object = roster.attrs ? roster.attrs.dn : null;
            if(dn) for(var node:String in dn)
            {
               var nodeCfg:Array = GlobalData.$mConfig_simple.dn[node] as Array;
               if(nodeCfg && nodeCfg[5]=="all" && dn[node] is Array && int(dn[node][0])>0) ids.push(dn[node][1]);
            }
            for each(var iid:Object in ids)
            {
               var hero:Object = roster.avatars[String(iid)];
               if(hero)
               {
                  var candidateAid:String = String(hero.aid != null ? hero.aid : iid).split("|")[0];
                  if(GlobalData.modChannelAllowed(candidateAid,"usage.destiny")) aids.push(candidateAid);
               }
            }
         }
         for each(var bond:Object in candidates)
         {
            if(snapshot != null)
            {
               if(snapshot.indexOf(String(bond.id))>=0) result.push(bond);
               continue;
            }
            var levels:Array = [quality];
            if(quality==5 && int(bond.minimum_quality[family])==5) levels.push(4);
            for each(var level:int in levels)
            {
               var matched:Boolean = true;
               var selfMatched:Boolean = false;
               for each(var member:String in bond.families)
               {
                  var needed:String = member+"_"+(level==4 && int(bond.minimum_quality[member])==5 ? 5 : level);
                  if(needed==aid) selfMatched=true;
                  if(aids.indexOf(needed)<0) matched=false;
               }
               if(matched && selfMatched) { result.push(bond); break; }
            }
         }
         return result;
      }

      public function bondPanel104(stat:String, value:Number) : Number
      {
         var family:String = String(avatarData.id).split("_").slice(0,2).join("_");
         var quality:String = String(avatarData.id).split("_")[2];
         for each(var bond:Object in getBondRows104())
         {
            var benefit:Object = bond.benefits[family];
            if(benefit.stats && benefit.stats[stat] != null) value = Tools.toInt(value*(1+Number(benefit.stats[stat])));
            if(benefit.flat_by_quality && benefit.flat_by_quality[quality] && benefit.flat_by_quality[quality][stat] != null) value += Number(benefit.flat_by_quality[quality][stat]);
         }
         for each(var equipmentBond:Object in getEquipmentBondRows104())
            if(equipmentBond.stats && equipmentBond.stats[stat]!=null)
               value = Tools.toInt(value*(1+Number(equipmentBond.stats[stat])));
         return value;
      }

      public function getEquipmentBondRows104() : Array
      {
         var all:Object = GlobalData.$mConfig_simple.equipment_bonds_104;
         var definitions:Array = all && avatarData ? all[avatarData.id] as Array : null;
         var result:Array = [];
         if(!definitions) return result;
         var ids:Array = [];
         if(mData && mData.hp_max != null && mData.equipment_bonds_104 is Array) ids = mData.equipment_bonds_104 as Array;
         else if(equips) for each(var item:Equip in equips) if(item && item.equipData) ids.push(String(item.equipData.id));
         for each(var row:Object in definitions) if(ids.indexOf(String(row.equipment))>=0) result.push(row);
         return result;
      }

      public function equipmentOutputRate104() : Number
      {
         return 1; // Equipment benefits are scoped to their skill variants.
      }

      public function equipmentSkillId104(source:String) : String
      {
         if(!source) return source;
         var keys:Array = [];
         for each(var row:Object in getEquipmentBondRows104()) keys.push(String(row.equipment));
         keys.sort();
         var all:Object = GlobalData.$mConfig_simple.equipment_skill_variants_104;
         var hero:Object = all ? all[avatarData.id] : null;
         var variants:Object = hero ? hero[source] : null;
         return variants && variants[keys.join("|")] ? String(variants[keys.join("|")]) : source;
      }

      public function getEquipmentBondDescription104() : String
      {
         var all:Object = GlobalData.$mConfig_simple.equipment_bonds_104;
         var definitions:Array = all && avatarData ? all[avatarData.id] as Array : null;
         if(!definitions) return "";
         var active:Array = getEquipmentBondRows104();
         var text:String = definitions.length && definitions[0].kind=="stats" ? "<br/>装备羁绊（本人穿戴，提升属性）" : "<br/>装备羁绊（本人穿戴，分别强化指定技能部分）";
         for each(var row:Object in definitions)
         {
            var equipment:Object = GlobalData.$mConfig_equip[row.equipment];
            var label:String = (equipment ? equipment.name : row.equipment)+" · "+row.name;
            var info:String = label+"（"+(active.indexOf(row)>=0 ? "已激活" : "未激活")+"）<br/>"+row.info;
            if(row.kind=="ordinary" && row.reworks) for(var rewriteName:String in row.reworks) info += "<br/>羁绊重做后："+row.reworks[rewriteName].info;
            if(row.kind=="exclusive") info += "<br/>新增伤害、护盾、治疗系数另按全局80%结算。";
            text += "<br/>"+Tools.formatHtmlText(info,active.indexOf(row)>=0 ? 0x00CCFF : 0x888888,false,15,"",0);
         }
         return text;
      }

      public function updateBondSkills104() : void
      {
         if(!GlobalData.$mConfig_simple.bonds_104 || !avatarData || mData && mData.hp_max) return;
         var keys:Array = [];
         for each(var bond:Object in getBondRows104()) keys.push(String(bond.id));
         keys.sort();
         var all:Object = GlobalData.$mConfig_simple.bond_skill_variants_104;
         var variants:Object = all ? all[avatarData.id] : null;
         var variant:Object = variants ? variants[keys.join("|")] : null;
         var sourceTable:Object = GlobalData.$mConfig_simple.bond_skill_sources_104;
         var sources:Object = sourceTable ? sourceTable[avatarData.id] : null;
         var normal:String = variant && variant.skill && sources && sources.skill == avatarData.skill0 ? String(variant.skill) : avatarData.skill0;
         var captain:String = variant && variant.leader_skill && sources && sources.leader_skill == avatarData.skill1 ? String(variant.leader_skill) : avatarData.skill1;
         normal = equipmentSkillId104(normal);
         captain = equipmentSkillId104(captain);
         var heroRow104:Object = GlobalData.$mConfig_avatar[avatarData.id];
         var passive104:String = heroRow104 && heroRow104.pl.length>13 ? heroRow104.pl[13] : null;
         passive104 = equipmentSkillId104(passive104);
         if(passive104 && (!skillB || skillB.skillSetData.id != passive104)) skillB = new SkillSet(passive104,this,1);
         if(normal && (!skill0 || skill0.skillSetData.id != normal || skill0.lv != slv)) skill0 = new SkillSet(normal,this,slv);
         if(captain && (!skill1 || skill1.skillSetData.id != captain)) skill1 = new SkillSet(captain,this,1,true);
      }

      public function getBondEntries104() : Array
      {
         var entries:Array = [];
         if(!avatarData) return entries;
         var definitions:Array = GlobalData.$mConfig_simple.bonds_104 as Array;
         var family:String = String(avatarData.id).split("_").slice(0,2).join("_");
         var active:Array = getBondRows104();
         var labels:Object = {hp:"生命",ap:"攻击",de_ph:"物防",de_ma:"法防",hit:"精准",flee:"闪避",crit:"暴击",tough:"韧性"};
         for each(var bond:Object in definitions)
         {
            if(bond.families.indexOf(family)<0) continue;
            var names:Array = [];
            var body:String = "";
            for each(var member:String in bond.families)
            {
               var quality:int = Math.max(getStar(),int(bond.minimum_quality[member]));
               var hero:Object = GlobalData.$mConfig_avatar[member+"_"+quality];
               if(!hero) hero = GlobalData.$mConfig_avatar[member+"_"+bond.minimum_quality[member]];
               var name:String = hero ? hero.name : member;
               names.push(name);
               if(member != family) continue;
               var benefit:Object = bond.benefits[member];
               var effects:Array = [];
               if(benefit.stats) for(var stat:String in benefit.stats) effects.push(labels[stat]+"提高"+Math.round(Number(benefit.stats[stat])*10000)/100+"%");
               var flats:Object = benefit.flat_by_quality ? benefit.flat_by_quality[String(quality)] : null;
               if(flats) for(stat in flats) effects.push(labels[stat]+"增加"+flats[stat]);
               if(benefit.skill_rate) effects.push("技能数值提高"+Math.round(Number(benefit.skill_rate)*100)+"%");
               if(benefit.info) effects.push(String(benefit.info));
               if(bond.focus==member)
               {
                  var variantTable:Object = GlobalData.$mConfig_simple.bond_skill_variants_104;
                  var memberVariants:Object = hero && variantTable ? variantTable[hero.id] : null;
                  var binding:Object = memberVariants ? memberVariants[String(bond.id)] : null;
                  var normalInfo:String = SkillSet.conciseInfo104(bond.mechanism.normal.info);
                  var captainInfo:String = bond.mechanism.captain ? SkillSet.conciseInfo104(bond.mechanism.captain.info) : "";
                  if(binding && binding.skill) normalInfo = new SkillSet(String(binding.skill),this,1).getInfo();
                  if(binding && binding.leader_skill) captainInfo = new SkillSet(String(binding.leader_skill),this,1,true).getInfo();
                  effects.push(bond.mechanism.normal.name+"："+normalInfo);
                  if(bond.mechanism.captain) effects.push(bond.mechanism.captain.name+"："+captainInfo);
               }
               body += "\n\n"+effects.join("；\n");
            }
            var enabled:Boolean = active.indexOf(bond)>=0;
            var info:String = "组合："+names.join("、")+body;
            entries.push({txt:String(bond.name),isOK:enabled,info:info});
         }
         var all:Object = GlobalData.$mConfig_simple.equipment_bonds_104;
         var equipmentRows:Array = all ? all[avatarData.id] as Array : null;
         var equipped:Array = getEquipmentBondRows104();
         for each(var row:Object in equipmentRows)
         {
            var equipment:Object = GlobalData.$mConfig_equip[row.equipment];
            enabled = equipped.indexOf(row)>=0;
            info = (enabled ? "已激活" : "未激活")+"\n本人装备"+(equipment ? equipment.name : row.equipment)+"\n"+SkillSet.conciseInfo104(row.info);
            if(row.kind=="ordinary" && row.reworks) for(var rewriteName:String in row.reworks) info += "\n\n"+rewriteName+"："+SkillSet.conciseInfo104(row.reworks[rewriteName].info);
            entries.push({txt:equipment ? String(equipment.name) : String(row.equipment),isOK:enabled,info:info});
         }
         return entries;
      }

      public function getBondDescription104() : String
      {
         var definitions:Array = GlobalData.$mConfig_simple.bonds_104 as Array;
         if(!definitions) return "";
         var family:String = String(avatarData.id).split("_").slice(0,2).join("_");
         var active:Array = getBondRows104();
         var text:String = "";
         var labels:Object = {hp:"生命",ap:"攻击",de_ph:"物防",de_ma:"法防",hit:"精准",flee:"闪避",crit:"暴击",tough:"韧性"};
         for each(var bond:Object in definitions)
         {
            if(bond.families.indexOf(family)<0) continue;
            var names:Array = [];
            for each(var member:String in bond.families)
            {
               var hero:Object = GlobalData.$mConfig_avatar[member+"_"+bond.minimum_quality[member]];
               names.push(hero ? hero.name : member);
            }
            var description:String = bond.name+"（"+(active.indexOf(bond)>=0 ? "已激活" : "未激活")+"）\n"+names.join("、");
            var benefit:Object = bond.benefits[family];
            if(benefit.stats) for(var stat:String in benefit.stats) description += "\n"+labels[stat]+" +"+Math.round(Number(benefit.stats[stat])*10000)/100+"%（独立乘区）";
            var flats:Object = benefit.flat_by_quality ? benefit.flat_by_quality[String(getStar())] : null;
            if(flats) for(stat in flats) description += "\n"+labels[stat]+" +"+flats[stat];
            if(benefit.skill_rate) description += "\n技能数值 +"+Math.round(Number(benefit.skill_rate)*100)+"%";
            if(benefit.info) description += "\n"+String(benefit.info);
            if(bond.focus==family) description += "\n"+bond.mechanism.normal.name+"："+bond.mechanism.normal.info+(bond.mechanism.captain ? "\n"+bond.mechanism.captain.name+"："+bond.mechanism.captain.info : "");
            if(bond.focus==family && GlobalData.$mConfig_simple.hero_skill_output_rate_104 != null) description += "\n伤害、护盾、治疗按上述技能基准的80%结算；增减益不变。";
            text += "<br/>"+Tools.formatHtmlText(description.replace(/\n/g,"<br/>"),active.indexOf(bond)>=0 ? 0x00CCFF : 0x888888,false,15,"",0);
         }
         return text;
      }

      private static var purpleBondMap:GameMap;

      private static function ensurePurpleBonds() : void
      {
         var map:GameMap = GameMap.currentMap;
         if(!map || purpleBondMap === map) return;
         purpleBondMap = map;
         var definitions:Array = GlobalData.$mConfig_simple.purple_bonds as Array;
         if(!definitions) return;
         for(var side:int=1;side<=2;side++)
         {
            var units:Vector.<Avatar> = side == 1 ? map.team1List : map.team2List;
            if(!units) continue;
            for each(var original:Avatar in units) if(original && original.abilityState) delete original.abilityState.bond;
            for each(var bond:Object in definitions)
            {
               if(!(bond.families is Array) || bond.families.length == 0) continue;
               var families:Array = [];
               var members:Array = [];
               for each(var unit:Avatar in units)
               {
                  if(!unit || unit.getStar()!=5 || unit.getType()!=1 || unit.isManualSummonUnit || !GlobalData.modChannelAllowed(unit.avatarData.id,"usage.destiny")) continue;
                  var family:String = GlobalData.baseModHeroId(unit.avatarData.id).split("_").slice(0,2).join("_");
                  if(bond.families.indexOf(family)<0 || families.indexOf(family)>=0) continue;
                  members.push(unit);
                  families.push(family);
               }
               if(families.length==bond.families.length) for each(unit in members) unit.abilityState.bond=String(bond.id);
            }
         }
      }

      public function getPurpleBondIsActive() : Boolean
      {
         if(GlobalData.$mConfig_simple.bonds_104) return getBondRows104().length>0;
         if(!GlobalData.modChannelAllowed(avatarData.id,"usage.destiny") || getStar()!=5 || getType()!=1 || !GlobalData.$userData || !GlobalData.$userData.team || !GlobalData.$userData.avatars) return false;
         var definitions:Array = GlobalData.$mConfig_simple.purple_bonds as Array;
         if(!definitions) return false;
         var family:String = GlobalData.baseModHeroId(avatarData.id).split("_").slice(0,2).join("_");
         var teamIndex:int = GlobalData.$userData.attrs && GlobalData.$userData.attrs.team_num != null ? int(GlobalData.$userData.attrs.team_num) : 0;
         var teams:Array = GlobalData.$userData.team as Array;
         var lineup:Array = teams && teamIndex >= 0 && teamIndex < teams.length ? teams[teamIndex] as Array : null;
         if(!lineup) return false;
         for each(var bond:Object in definitions)
         {
            if(!(bond.families is Array) || bond.families.indexOf(family)<0) continue;
            var found:Array = [];
            var selfInLineup:Boolean = false;
            for each(var instanceId:Object in lineup)
            {
               var instance:String = String(instanceId);
               var hero:Object = GlobalData.$userData.avatars[instance];
               if(!hero) continue;
               var aid:String = String(hero.aid != null ? hero.aid : instance).split("|")[0];
               var parts:Array = aid.split("_");
               if(parts.length != 3 || parts[0] != "A" || parts[1].charAt(0) != "1" || int(parts[2]) != 5) continue;
               if(instance == id) selfInLineup = true;
               var memberFamily:String = parts[0] + "_" + parts[1];
               if(bond.families.indexOf(memberFamily)>=0 && found.indexOf(memberFamily)<0) found.push(memberFamily);
            }
            if(selfInLineup && found.length == bond.families.length) return true;
         }
         return false;
      }

      public function getPurpleBondDescription() : String
      {
         if(GlobalData.$mConfig_simple.bonds_104) return getBondDescription104()+getEquipmentBondDescription104();
         if(getStar()!=5) return "";
         var definitions:Array = GlobalData.$mConfig_simple.purple_bonds as Array;
         if(!definitions) return "";
         var family:String = GlobalData.baseModHeroId(avatarData.id).split("_").slice(0,2).join("_");
         for each(var bond:Object in definitions)
         {
            if(bond.families.indexOf(family)<0) continue;
            var color:uint = getPurpleBondIsActive() ? 0x00CCFF : 0x888888;
            var concise:String = bond.short_info != null ? String(bond.short_info) : String(bond.name) + "\n" + String(bond.info);
            var lines:Array = concise.split(/\r?\n/);
            var html:String = "<br/>";
            for(var i:int=0;i<lines.length;i++)
            {
               if(i>0) html += "<br/>";
               html += Tools.formatHtmlText(String(lines[i]),color,i==0,i==0 ? 16 : 15,"",0);
            }
            return html;
         }
         return "";
      }

      public function getDestinyDescription() : String
      {
         var original:String = mDestiny && mDestiny.htmlArr ? Tools.formatHtmlTextBr(mDestiny.htmlArr) : (mDestiny ? mDestiny.nameStr : "");
         var bond:String = getPurpleBondDescription();
         if(bond && original.indexOf("暂无命运关系") >= 0) original = "";
         return original + bond;
      }

      private function purpleBondMultiplier() : Number
      {
         var context:Object = currentAbilityAttack();
         return abilityState.bond && context && context.owner===this && context.kind=="active" ? 1.3 : 1;
      }

      public var formationOwner:Avatar;

      public function clampSummonFormation(targetPos:int) : int
      {
         if(!formationOwner || formationOwner.hp <= 0 || formationOwner.team != team || formationOwner.line != line) return targetPos;
         // Keep a unit of visible spacing; never teleport displaced summons.
         return team == 1 ? Math.min(targetPos,Math.max(pos,formationOwner.pos - GameMapConfig.MIN_SPACE_POS)) : Math.max(targetPos,Math.min(pos,formationOwner.pos + GameMapConfig.MIN_SPACE_POS));
      }

      private function clampOwnerAdvance(targetPos:int) : int
      {
         var units:Vector.<Avatar> = GameMap.currentMap.getAliveList(team) as Vector.<Avatar>;
         for each(var unit:Avatar in units)
         {
            if(unit.formationOwner !== this || unit.hp <= 0 || unit.line != line) continue;
            // Wait for the front summon instead of walking through it.
            targetPos = team == 1 ? Math.max(targetPos,Math.min(pos,unit.pos + GameMapConfig.MIN_SPACE_POS)) : Math.min(targetPos,Math.max(pos,unit.pos - GameMapConfig.MIN_SPACE_POS));
         }
         return targetPos;
      }

      public var abilityState:Object = {};
      private var abilityEntryAttack:Number = 0;
      private var initializingFightAttributes:Boolean = false;
      public var previewTeamTalentBonuses:Object = null;
      private var abilitySerial:int = 0;
      private var abilityIndex:int = 0;
      private static var abilityNextIndex:int = 0;
      private static var abilityContexts:Array = [];
      private var parallelVisualBatches:Array = [];

      public function beginParallelVisualBatch() : Object
      {
         var batch:Object = {context:currentAbilityAttack(),start:NaN,end:GameMap.actionDelay,target:null,hits:[],wave:-1,step:0.15,serial:0,animated:{}};
         parallelVisualBatches.push(batch);
         return batch;
      }

      public function setParallelVisualWave(batch:Object, wave:int, step:Number = 0.15) : void
      {
         if(!batch || parallelVisualBatches[parallelVisualBatches.length-1] !== batch) return;
         batch.end = Math.max(Number(batch.end),GameMap.actionDelay);
         if(isNaN(Number(batch.start))) batch.start = GameMap.actionDelay;
         batch.wave = Math.max(0,wave);
         batch.step = Math.max(0,step);
         GameMap.actionDelay = Number(batch.start)+int(batch.wave)*Number(batch.step);
      }

      public function prepareParallelVisualTarget(target:Avatar, hit:Boolean) : void
      {
         if(!target || parallelVisualBatches.length == 0) return;
         var batch:Object = parallelVisualBatches[parallelVisualBatches.length-1];
         // Reactions retain their own sequence and must not rewind their caller.
         if(batch.context !== currentAbilityAttack()) return;
         batch.end = Math.max(Number(batch.end),GameMap.actionDelay);
         if(isNaN(Number(batch.start))) batch.start = GameMap.actionDelay;
         if(int(batch.wave) >= 0)
         {
            GameMap.actionDelay = Number(batch.start)+int(batch.wave)*Number(batch.step);
            return;
         }
         if(hit && batch.hits.indexOf(target) >= 0)
         {
            // A repeated target starts the next damage wave, not another victim.
            batch.start = Number(batch.end);
            batch.serial = int(batch.serial)+1;
            batch.hits = [];
            batch.target = null;
         }
         if(batch.target !== target)
         {
            GameMap.actionDelay = Number(batch.start);
            batch.target = target;
         }
         if(hit) batch.hits.push(target);
      }

      public function endParallelVisualBatch(batch:Object) : void
      {
         if(!batch || parallelVisualBatches[parallelVisualBatches.length-1] !== batch) return;
         GameMap.actionDelay = Math.max(Number(batch.end),GameMap.actionDelay);
         parallelVisualBatches.pop();
      }

      private function flushParallelVisualBatch() : void
      {
         if(parallelVisualBatches.length)
            GameMap.actionDelay = Math.max(GameMap.actionDelay,Number(parallelVisualBatches[parallelVisualBatches.length-1].end));
      }

      private function playParallelAttackTween() : Boolean
      {
         if(parallelVisualBatches.length == 0) return true;
         var batch:Object = parallelVisualBatches[parallelVisualBatches.length-1];
         if(batch.context !== currentAbilityAttack()) return true;
         var key:String = int(batch.wave) >= 0 ? "wave"+int(batch.wave) : "auto"+int(batch.serial);
         if(batch.animated[key]) return false;
         batch.animated[key] = true;
         return true;
      }

      public static function beginAbilityAttack(owner:Avatar, kind:String) : Object
      {
         ensurePurpleBonds();
         var context:Object = {owner:owner,kind:kind,targets:[],hits:[],kills:[],guards:[],damage:0,hitSerial:0};
         abilityContexts.push(context);
         return context;
      }

      private static function currentAbilityAttack() : Object
      {
         return abilityContexts.length ? abilityContexts[abilityContexts.length - 1] : null;
      }

      private function activeManualEffectMultiplier() : Number
      {
         var context:Object = currentAbilityAttack();
         var value:Number = context && context.owner === this ? Number(context.manualEffectMultiplier) : 1;
         return isFinite(value) && value > 0 ? value : 1;
      }

      private function ownGrowthValue(effect:String) : Number
      {
         if(!talent || !talent.my_HaloData || !talent.my_HaloData.dataObj) return 0;
         var row:Object = talent.my_HaloData.dataObj;
         if(String(row.growth_effect) != effect) return 0;
         var value:Number = Number(row.growth_value);
         return isFinite(value) && value > 0 ? value : 0;
      }

      private function isTeamFlatTalent() : Boolean
      {
         return talent && talent.my_HaloData && talent.my_HaloData.dataObj && String(talent.my_HaloData.dataObj.growth_effect).indexOf("team_") == 0;
      }

      private function isPanelStatTalent() : Boolean
      {
         return ownGrowthValue("attack") > 0 || ownGrowthValue("defense") > 0 || ownGrowthValue("hp") > 0;
      }

      public function getRecoveryTalentMultiplier() : Number
      {
         return 1 + ownGrowthValue("recovery") / 100;
      }

      private function teamTalentFlat(effect:String) : int
      {
         if(this.summonStatSnapshot) return 0;
         var map:GameMap = GameMap.currentMap;
         if(!map || team < 1 || team > 2 || hp <= 0) return previewTeamTalentBonuses ? Math.max(0,int(previewTeamTalentBonuses[effect])) : 0;
         var allies:Vector.<Avatar> = map.getAliveList(team) as Vector.<Avatar>;
         if(!allies) return 0;
         var best:Number = 0;
         for each(var ally:Avatar in allies)
         {
            if(ally && ally.hp > 0) best = Math.max(best,ally.ownGrowthValue(effect));
         }
         return int(best);
      }

      public static function endAbilityAttack(context:Object) : void
      {
         if(!context || currentAbilityAttack() !== context) return;
         abilityContexts.pop();
         var owner:Avatar = context.owner as Avatar;
         var target:Avatar;
         var guard:Object;
         var record:Object;
         var state:Object;
         for each(record in context.targets)
         {
            target = record.target as Avatar;
            if(!target) continue;
            guard = target.abilityState.guard;
            if(guard && context.guards.indexOf(target) >= 0)
            {
               --guard.charges;
               if(guard.charges <= 0) delete target.abilityState.guard;
               if(guard.kind == "kayle" && target.hp > 0 && owner && owner.hp > 0)
               {
                  var guardOwner:Avatar = guard.owner as Avatar;
                  if(guardOwner && guardOwner.hp > 0)
                  {
                     var swordContext:Object = beginAbilityAttack(guardOwner,"response");
                     swordContext.manualDamageMultiplier = guard.manualDamageMultiplier;
                     var swordPresentation:Object = guardOwner.beginParallelVisualBatch();
                     try
                     {
                     for each(var swordTarget:Avatar in guardOwner.abilityEnemies(300,target,3)) guardOwner.abilityHit(swordTarget,1.5,2,"FX_A_1120_MAGIC");
                     }
                     finally { guardOwner.endParallelVisualBatch(swordPresentation); endAbilityAttack(swordContext); }
                  }
               }
            }
            if(record.damage <= 0 || !owner || target.hp <= 0 || owner.getType() != 1 || owner.isManualSummonUnit) continue;
            state = target.abilityState.sap;
            if(state && context.kind == "active")
            {
               delete target.abilityState.sap;
               var sapContext:Object = beginAbilityAttack(target,"response");
               sapContext.manualEffectMultiplier = state.manualEffectMultiplier;
               target.abilityHeal(target,0.6);
               endAbilityAttack(sapContext);
            }
            state = target.abilityState.counter;
            if(state && owner.hp > 0 && (context.kind == "active" || context.kind == "basic") && state.left > 0 && !state.seen[String(owner.abilityIndex)] && owner.line == target.line && Math.abs(owner.pos-target.pos) <= 400)
            {
               --state.left;
               state.seen[String(owner.abilityIndex)] = true;
               var counterContext:Object = beginAbilityAttack(target,"response");
               counterContext.manualDamageMultiplier = state.manualDamageMultiplier;
               counterContext.manualEffectMultiplier = state.manualEffectMultiplier;
               if(target.abilityHit(owner,1,1,"FX_A_1143_PHYSICAL")) target.abilityHeal(target,0.2);
               endAbilityAttack(counterContext);
            }
         }
         if(owner && owner.hp > 0 && context.kind == "active" && owner.abilityState.bond)
         {
            if(owner.abilityState.bond == "demacia") owner.abilityShield(owner,0.2,1);
            else if(owner.abilityState.bond == "harmony") owner.abilityHeal(owner.abilityAlly(),0.2);
            else if(owner.abilityState.bond == "frost")
            {
               for each(target in context.hits.slice(0,2)) if(target.hp>0 && target.team!=owner.team) owner.abilityControl(target,"weak",1,0.1);
            }
         }
         if(owner && owner.hp > 0 && context.kills.length > 0 && owner.abilityState.highlander && (context.kind == "basic" || context.kind == "active"))
         {
            state = owner.abilityState.highlander;
            if(state.left > 0 && owner.skill0 && (owner.skill0 as Object).abilityHasCast && owner.skill0.m_cooldownNum > 0)
            {
               --state.left;
               owner.skill0.m_cooldownNum = Math.max(0,owner.skill0.m_cooldownNum-2);
            }
         }
      }

      private function abilityDirectMultiplier(source:Avatar, damageType:int) : Number
      {
         if(abilityState.alistarGuard104 && damageType != 4) return Math.max(0,Math.round((1-Number(abilityState.alistarGuard104.reduction))*10000000000)/10000000000);
         var context:Object = currentAbilityAttack();
         if(!context || !source || context.owner !== source || damageType < 1 || damageType > 3 || (context.kind != "basic" && context.kind != "active")) return 1;
         var guard:Object = abilityState.guard;
         if(!guard || guard.charges <= 0) return 1;
         if(context.guards.indexOf(this) < 0) context.guards.push(this);
         if(guard.kind == "kayle") return 0;
         var guardFactor:Number = Number(guard.manualEffectMultiplier);
         if(!isFinite(guardFactor) || guardFactor <= 0) guardFactor = 1;
         return Math.max(0,1 - 0.55 * guardFactor);
      }

      public var statisticsOwner104:Avatar;
      public static var statisticsRows104:Array = [];
      public static var statisticsRunning104:Boolean = false;

      public static function resetStatistics104() : void
      {
         clearEffects104();
         statisticsRows104 = [];
         statisticsRunning104 = false;
      }

      public static function statisticsRow104(unit:Avatar) : Object
      {
         if(!unit) return null;
         var seen:Array = [];
         while(unit.statisticsOwner104 && seen.indexOf(unit) < 0)
         {
            seen.push(unit);
            unit = unit.statisticsOwner104;
         }
         for each(var row:Object in statisticsRows104) if(row.unit === unit) return row;
         row = {unit:unit,team:unit.team,name:String(unit.avatarData.name),damage:0,healing:0,taken:0};
         statisticsRows104.push(row);
         return row;
      }

      public static function recordStatistics104(source:Avatar, target:Avatar, damage:Number, healing:Number) : void
      {
         if(!statisticsRunning104 || !target) return;
         var victim:Object = statisticsRow104(target);
         var actor:Object = statisticsRow104(source);
         if(isFinite(damage) && damage > 0)
         {
            victim.taken += damage;
            if(actor && source.team != target.team) actor.damage += damage;
         }
         if(actor && isFinite(healing) && healing > 0) actor.healing += healing;
      }

      private function abilityRecordDamage(source:Avatar, damageType:int, before:int, damageTaken:Number = -1) : void
      {
         var context:Object = currentAbilityAttack();
         var actual:Number = damageTaken >= 0 ? damageTaken : Math.max(0,before-Math.max(0,hp));
         if(abilityState.grey && actual > 0 && damageType != 4)
         {
            var greyFactor:Number = Number(abilityState.grey.manualEffectMultiplier);
            if(!isFinite(greyFactor) || greyFactor <= 0) greyFactor = 1;
            abilityState.grey.value = Math.min(hpMax*0.2*greyFactor,abilityState.grey.value+actual*0.4*greyFactor);
            abilityFeedback("灰色生命："+int(abilityState.grey.value),"FX_S9160_SHIELD",10066329);
         }
         if(!context || !source || context.owner !== source || damageType < 1 || damageType > 3) return;
         var record:Object = null;
         for each(var entry:Object in context.targets) if(entry.target === this) record = entry;
         if(!record) { record = {target:this,damage:0}; context.targets.push(record); }
         record.damage += actual;
         context.damage += actual;
         if(damageType==1) context.sixPhysicalHp105=Number(context.sixPhysicalHp105 || 0)+actual;
         ++context.hitSerial;
         if(context.hits.indexOf(this) < 0) context.hits.push(this);
         if(hp <= 0 && getType() == 1 && !isManualSummonUnit && context.kills.indexOf(this) < 0) context.kills.push(this);
      }

      private static const SIX_IRELIA_IMMUNITIES:Array = ["weak","silence","sunder","curse","stun"];

      private function sixFollowupPassive105(kind:String) : Array
      {
         var passive:Array=sixStarPassive105();
         return passive && passive[1]=="six_"+kind+"_p" ? passive : null;
      }

      private function sixFollowupAlly105(excludeSelf:Boolean) : Avatar
      {
         var best:Avatar=null;
         for each(var unit:Avatar in GameMap.currentMap.getAliveList(team))
         {
            if(!unit || unit.hp<=0 || unit.line!=line || excludeSelf && unit===this) continue;
            if(!best || unit.getDamage()>best.getDamage()) best=unit;
         }
         return best;
      }

      public function sixStarPickRandom105(distance:int, banStand:Boolean) : Avatar
      {
         var pool:Array=[];
         for each(var foe:Avatar in sixStarLane105(distance))
            if(!banStand || foe.getEffectiveActionType()!=3) pool.push(foe);
         return pool.length ? pool[(Random.getRandom(pool.length)+pool.length)%pool.length] as Avatar : null;
      }

      private function sixFollowupHit105(target:Avatar, ratio:Number, kind:int, effect:String) : Boolean
      {
         var attack:Object=currentAbilityAttack();
         var before:int=attack ? int(attack.hitSerial) : 0;
         sixStarHit105(target,ratio,kind,effect);
         return attack && int(attack.hitSerial)>before;
      }

      private function sixFollowupHeal105(target:Avatar, amount:Number, fixed:Boolean = false) : void
      {
         if(target && target.hp>0 && amount>0)
            target.injured(int(amount),1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this,null,"",false,fixed);
      }

      private function sixFollowupExecute105(kind:String, effect:String, sourceSkill:SkillSet) : Boolean
      {
         var action:Array=sourceSkill.getNativeAction();
         var target:Avatar;
         var foe:Avatar;
         var ally:Avatar;
         var anchor:int;
         var attack:Object=currentAbilityAttack();
         if(kind=="six_nami_n")
         {
            ally=sixFollowupAlly105(true);
            if(!ally) return false;
            ally.abilityState.sixNamiBless105={source:this,left:3,ratio:Number(action[5]),weak:Number(action[6]),debuff:false};
            sixFollowupHeal105(ally,getDamage()*Number(action[4]));
            return true;
         }
         var foes:Array=sixStarLane105(Math.abs(sourceSkill.getCastRange()),kind!="six_lee_c");
         if(!foes.length) return false;
         target=foes[0] as Avatar;
         switch(kind)
         {
            case "six_irelia_c":
               anchor=target.pos;
               var group:Array=[];
               for each(foe in foes) if(Math.abs(foe.pos-anchor)<=700) group.push(foe);
               for each(foe in group)
                  if(sixFollowupHit105(foe,Number(action[4]),2,"FX_A_1024_MAGIC"))
                     abilityControl(foe,"sunder",2,sixFollowupDebuff105(Number(action[5])));
               var prior:Number=Number(attack.sixPhysicalHp105 || 0);
               for each(foe in group) sixFollowupHit105(foe,Number(action[6]),1,effect);
               if(hp>0)
               {
                  for each(var name:String in SIX_IRELIA_IMMUNITIES) removeBuff(name);
                  abilityState.sixIreliaImmune105={until:abilitySerial+2,debuff:false};
                  sixFollowupHeal105(this,(Number(attack.sixPhysicalHp105 || 0)-prior)*Number(action[7]));
               }
               break;
            case "six_lee_c":
               anchor=target.pos;
               var end:int=GameMap.currentMap.getFinalPos(target.team,target.line,anchor+(target.team==1 ? 800 : -800));
               sixFollowupHit105(target,Number(action[4]),1,effect);
               if(target.hp>0)
               {
                  abilityControl(target,"stun",1);
                  target.checkMove(false,800,this,-1,true);
                  end=target.pos;
               }
               for each(foe in sixStarLane105())
                  if(foe!==target && foe.pos>=Math.min(anchor,end) && foe.pos<=Math.max(anchor,end))
                     sixFollowupHit105(foe,Number(action[5]),1,effect);
               addBuff("purify",1);
               break;
            case "six_fiora_n":
               if(!abilityDash(target)) return false;
               abilityState.sixFioraCasts105=int(abilityState.sixFioraCasts105)+1;
               attack.sixForceCrit105=int(abilityState.sixFioraCasts105)%2==0 && sixFollowupPassive105("fiora")!=null;
               attack.sixFioraTrue105=Number(action[5]);
               try { sixFollowupHit105(target,Number(action[4]),1,effect); }
               finally { delete attack.sixFioraTrue105; delete attack.sixForceCrit105; }
               addBuff("purify",1);
               attack.sixFioraOverflow105=Number(action[6]);
               try { sixFollowupHeal105(this,Number(attack.damage)); }
               finally { delete attack.sixFioraOverflow105; }
               break;
            case "six_fiora_c":
               for(var strike:int=0;strike<5 && hp>0;++strike)
               {
                  foes=sixStarLane105();
                  if(!foes.length) break;
                  target=foes[(Random.getRandom(foes.length)+foes.length)%foes.length] as Avatar;
                  anchor=target.pos;
                  sixFollowupHit105(target,Number(action[4]),1,effect);
                  for each(foe in foes)
                     if(foe!==target && Math.abs(foe.pos-anchor)<=300)
                        sixFollowupHit105(foe,Number(action[4])*Number(action[5]),1,effect);
               }
               if(hp>0 && Number(attack.damage)>0)
                  addBuff("shield",2,int(Number(attack.damage)*Number(action[6])));
               break;
            case "six_morgana_n":
               if(sixFollowupHit105(target,Number(action[4]),2,effect)) abilityControl(target,"stun",2);
               sixFollowupHeal105(this,Number(attack.damage));
               ally=sixFollowupAlly105(false);
               if(ally) ally.addBuff("purify",2);
               break;
            case "six_morgana_c":
               sixFollowupUnlink105();
               abilityState.sixMorganaLinks105={targets:foes,turns:3,damage:Number(action[5]),effect:effect};
               for each(foe in foes)
               {
                  if(!foe.abilityState.sixMorganaSources105) foe.abilityState.sixMorganaSources105={};
                  foe.abilityState.sixMorganaSources105[abilityIndex]={source:this,ratio:Number(action[4])};
               }
               break;
            default:
               return false;
         }
         return true;
      }

      private function sixFollowupUnlink105() : void
      {
         var link:Object=abilityState.sixMorganaLinks105;
         if(!link) return;
         for each(var foe:Avatar in link.targets)
            if(foe.abilityState.sixMorganaSources105) delete foe.abilityState.sixMorganaSources105[abilityIndex];
         delete abilityState.sixMorganaLinks105;
      }

      private function sixFollowupTurn105() : void
      {
         var grey:Number=Number(abilityState.sixTahmGrey105 || 0);
         if(grey>0)
         {
            delete abilityState.sixTahmGrey105;
            var tahm:Array=sixFollowupPassive105("tahm");
            if(tahm) sixFollowupHeal105(this,grey*Number(tahm[4]));
         }
         var link:Object=abilityState.sixMorganaLinks105;
         if(link && --link.turns<=0)
         {
            sixFollowupUnlink105();
            var attack:Object=beginAbilityAttack(this,"active");
            try
            {
               for each(var foe:Avatar in link.targets)
                  if(sixFollowupHit105(foe,Number(link.damage),2,String(link.effect))) abilityControl(foe,"stun",1);
            }
            finally { endAbilityAttack(attack); }
         }
         if(skillB)
         {
            var row:Object=GlobalData.$mConfig_skill[skillB.skillSetData.id];
            if(row && row.sixStarPolarGrowth105)
            {
               abilityState.sixPolarTurns105=int(abilityState.sixPolarTurns105)+1;
               abilityState.sixPolarGrowth105=Number(row.sixStarPolarGrowth105);
            }
         }
      }

      private function sixFollowupEvent105(event:String, source:Avatar, target:Avatar, overheal:Number) : void
      {
         if(hp<=0) return;
         var attack:Object=currentAbilityAttack();
         if(event=="healed" && source===this && attack && attack.owner===this && attack.sixFioraOverflow105 && overheal>0)
            addBuff("shield",2,int(overheal*Number(attack.sixFioraOverflow105)));
         if(event=="basic_attack" && target && abilityState.sixLeeArmed105)
         {
            var lee:Array=sixFollowupPassive105("lee");
            delete abilityState.sixLeeArmed105;
            if(!lee) return;
            var pulse:Object=beginAbilityAttack(this,"response");
            try
            {
               for each(var foe:Avatar in abilityCandidates(otherTeam,target.line,target.pos,400,-1))
                  if(sixFollowupHit105(foe,Number(lee[4]),2,"FX60_MAGIC"))
                     abilityControl(foe,"weak",1,sixFollowupDebuff105(Number(lee[5])));
            }
            finally { endAbilityAttack(pulse); }
         }
      }

      private static function sixFollowupDebuff105(ratio:Number) : Number
      {
         ratio=Math.max(0,Math.min(.95,ratio));
         return ratio/(1-ratio);
      }

      private function sixFollowupIncoming105(amount:int, source:Avatar, kind:int, dotKind:String) : int
      {
         if(kind!=1 && kind!=2 && kind!=3 && kind!=6 && kind!=7 && kind!=8) return amount;
         var multiplier:Number=1;
         var amp:Number=0;
         if(!dotKind && kind!=6 && kind!=7 && abilityState.sixMorganaSources105)
         {
            for each(var link:Object in abilityState.sixMorganaSources105)
               if(link.source.hp>0) amp=Math.max(amp,Number(link.ratio));
         }
         if(source && source.team!=team && source.line==line)
         {
            var passive:Array=source.sixFollowupPassive105("irelia");
            if(passive)
            {
               var friends:int=0;
               for each(var unit:Avatar in GameMap.currentMap.getAliveList(source.team))
                  if(unit && unit.hp>0 && unit.line==line) ++friends;
               multiplier+=Math.max(0,source.sixStarLane105().length-friends)*Number(passive[4]);
            }
         }
         return Tools.toInt(amount*multiplier*(1+amp));
      }

      private function sixFollowupAfterHit105(target:Avatar, attack:Object, taken:Number) : void
      {
         if(!attack || attack.owner!==this || taken<=0 || attack.sixDerived105 ||
            (attack.kind!="active" && attack.kind!="basic") || attack.skill && attack.skill===skillB) return;
         if(attack.sixNamiWave105 && target.hp>0 && target.getType()==1 && !target.isManualSummonUnit && !target.s2AnnieImmune())
         {
            if(target.buffs["purify"]) target.removeBuff("purify",true);
            else target.abilityState.sixNamiSlow105={until:target.abilitySerial+2,debuff:true};
         }
         var aura:Object=attack.sixNamiTicket105;
         if(!aura)
         {
            aura=abilityState.sixNamiBless105;
            if(!aura || int(aura.left)<=0) return;
            --aura.left;
            attack.sixNamiTicket105=aura;
            attack.sixNamiTargets105=[];
         }
         if(target.hp<=0 || attack.sixNamiTargets105.indexOf(target)>=0) return;
         attack.sixNamiTargets105.push(target);
         attack.sixDerived105=true;
         try
         {
            target.injured(int(aura.source.getDamage()*Number(aura.ratio)),1,DisplayTools.getAttrs("FX60_MAGIC"),3,this,false,this,null,"",true);
            if(target.hp>0) abilityControl(target,"weak",3,sixFollowupDebuff105(Number(aura.weak)));
         }
         finally { delete attack.sixDerived105; }
      }

      private function sixFollowupSpeed105() : Number
      {
         var factor:Number=abilityState && abilityState.sixNamiSlow105 ? .5 : 1;
         if(!GameMap.currentMap || hp<=0) return factor;
         for each(var unit:Avatar in GameMap.currentMap.getAliveList(team))
         {
            if(!unit || unit===this || unit.hp<=0 || unit.line!=line) continue;
            var aura:Array=unit.sixFollowupPassive105("nami");
            if(aura) return factor*Number(aura[4]);
         }
         return factor;
      }


      private function sixStarPassive105() : Array
      {
         var action:Array = skillB && skillB.skills && skillB.skills.length ? skillB.skills[0] : null;
         return action && action[0] == "manual_ability" && String(action[1]).indexOf("six_") == 0 ? action : null;
      }

      private function sixStarLane105(distance:int = 3000, front:Boolean = false, forward:Boolean = false) : Array
      {
         return abilityCandidates(otherTeam,line,pos,distance,-1,false,front ? "front" : "nearest",null,forward);
      }

      private function sixStarStunned105() : Array
      {
         var targets:Array=[];
         for each(var unit:Avatar in sixStarLane105())
            if(unit.hasModBuff("stun")) targets.push(unit);
         return targets;
      }

      private function sixStarLowestEnemy105() : Avatar
      {
         var result:Avatar = null;
         for each(var enemy:Avatar in GameMap.currentMap.getAliveList(otherTeam))
         {
            if(enemy.hp<=0) continue;
            if(!result || enemy.hp/enemy.hpMax < result.hp/result.hpMax ||
               (enemy.hp/enemy.hpMax == result.hp/result.hpMax && enemy.abilityIndex < result.abilityIndex))
               result=enemy;
         }
         return result;
      }

      private function sixReactionPassive105(kind:String) : Array
      {
         var action:Array=sixStarPassive105();
         return action && action[1]=="six_reaction_"+kind+"_p" ? action : null;
      }

      private function sixReactionEvelynnTarget105(targets:Array) : Avatar
      {
         var result:Avatar=null;
         for each(var foe:Avatar in targets)
         {
            if(foe.hp>=foe.hpMax*.4) continue;
            if(!result || foe.hp/foe.hpMax<result.hp/result.hpMax ||
               foe.hp/foe.hpMax==result.hp/result.hpMax && foe.abilityIndex<result.abilityIndex) result=foe;
         }
         return result;
      }

      private function sixReactionExecute105(kind:String, effect:String, sourceSkill:SkillSet) : Boolean
      {
         var action:Array=sourceSkill.getNativeAction();
         if(!action) return false;
         var target:Avatar;
         if(kind=="six_reaction_plant_n")
         {
            var allies:Array=abilityCandidates(team,line,pos,GameMapConfig.LINE_POS,-1);
            var healing:Number=getDamage()*Number(action[4]);
            for each(var ally:Avatar in allies)
            {
               if(ally.hp>=ally.hpMax) ally.addBuff("purify",1,0,0,-1,this);
               else sixFollowupHeal105(ally,healing);
            }
            return allies.length>0;
         }
         if(kind=="six_reaction_evelynn_c")
         {
            var enemies:Array=sixStarLane105();
            target=sixReactionEvelynnTarget105(enemies);
            if(!target) return false;
            sixStarHit105(target,Number(action[4]),2,effect);
            for each(var foe:Avatar in enemies)
               if(foe!==target && sixFollowupHit105(foe,Number(action[5]),2,effect)) abilityControl(foe,"silence",1);
            if(hp>0)
            {
               hp=hpMax;
               queueVitalBar104();
               checkMove(false,GameMapConfig.LINE_POS,null,-1,true);
               addBuff("purify",1,0,0,-1,this);
            }
            return true;
         }
         if(kind=="six_reaction_elise_c")
         {
            var targets:Array=abilityCandidates(otherTeam,line,pos,sourceSkill.getCastRange(),1,false,"ratio");
            if(!targets.length || abilityState.root || buffs.root) return false;
            target=targets[0];
            addBuff("shield",2,hpMax*Number(action[4]),0,-1,this);
            abilityDash(target);
            var before:int=target.hp;
            var missing:Number=1-before/target.hpMax;
            sixStarHit105(target,Number(action[5])+Number(action[6])*Math.min(1,missing/.67),2,effect);
            var lost:Number=Math.max(0,before-Math.max(0,target.hp));
            if(lost>0 && hp>0)
            {
               sixFollowupHeal105(this,lost,true);
               if(target.hp<=0 && skillB) { skillB.cooldown(); skillB.cooldown(); }
            }
            return true;
         }
         return false;
      }

      private function sixReactionBurnChanged105() : void
      {
         if(hp<=0) return;
         var nativeBurn:Buff=buffs.burn as Buff;
         var layers:int=nativeBurn && nativeBurn.round>0 && nativeBurn.value>0 ?
            Math.max(1,int(abilityState.sixReactionBurnLayers105)) : 0;
         var pending:Number=layers ? Tools.toInt(nativeBurn.value)*nativeBurn.round : 0;
         var dot:Object;
         var raw:Number;
         for each(dot in manualSkillDots)
         {
            if(!dot || dot.kind!="burn" || dot.round<=0) continue;
            raw=dot.bookRemaining===undefined ? Tools.toInt(Number(dot.apTick)+Number(dot.hpMaxFraction)*hpMax)*dot.round :
               Number(dot.bookRemaining);
            if(raw>0) { ++layers; pending+=raw; }
         }
         for each(dot in abyssDots104)
            if(dot.kind=="burn" && dot.left>0 && dot.amount>0) { ++layers; pending+=dot.amount*dot.left; }
         if(layers<4) return;
         for each(var observer:Avatar in abilityAllEnemies())
         {
            var passive:Array=observer.skillB ? observer.sixReactionPassive105("annie") : null;
            if(!passive) continue;
            removeBuff("burn");
            for(var key:String in manualSkillDots)
            {
               dot=manualSkillDots[key];
               if(!dot || dot.kind!="burn") continue;
               var visual:Buff=dot.visual as Buff;
               if(visual && m_buff && visual.displayObject && visual.displayObject.parent===m_buff)
                  m_buff.removeChild(visual.displayObject);
               delete manualSkillDots[key];
            }
            var cast:Object=beginAbilityAttack(observer,"passive");
            try
            {
               injured(Tools.toInt(pending*Number(passive[4])),1,DisplayTools.getAttrs(String(passive[3])),3,
                  observer,false,observer,null,"",true);
               observer.abilityControl(this,"stun",1);
            }
            finally { endAbilityAttack(cast); }
            break;
         }
      }

      private function sixReactionDefense105(kind:String) : Number
      {
         var raw:Number=kind=="dePh" ? dePh : deMa;
         return Math.max(0,raw*(1+getManualBattleStack("defense"))+Number(abilityState["sixReactionDefense105_"+kind] || 0));
      }

      private function sixReactionStun105() : void
      {
         for each(var observer:Avatar in abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,-1))
         {
            var passive:Array=observer.skillB ? observer.sixReactionPassive105("thresh") : null;
            if(!passive || hp<=0) continue;
            for each(var stat:String in ["dePh","deMa"])
            {
               var key:String="sixReactionDefense105_"+stat;
               var amount:Number=sixReactionDefense105(stat)*Number(passive[4]);
               abilityState[key]=Number(abilityState[key] || 0)-amount;
               observer.abilityState[key]=Number(observer.abilityState[key] || 0)+amount;
            }
            var cast:Object=beginAbilityAttack(observer,"passive");
            try { observer.abilityControl(this,"curse",1); }
            finally { endAbilityAttack(cast); }
         }
      }

      private function sixReactionDamageTaken105() : void
      {
         delete abilityState.sixReactionMfStacks105;
         if(hp<=0 || hp>=hpMax*.35 || !skillB || !sixReactionPassive105("elise")) return;
         if(abilityState.sixReactionEliseUsed105 && skillB.m_cooldownNum>=0) return;
         abilityState.sixReactionEliseUsed105=true;
         abilityState.sixReactionElise105={until:abilitySerial+1,skip:true};
         skillB.m_cooldownNum=skillB.skillSetData.cooldown;
         addBuff("purify",1,0,0,-1,this);
      }

      private function sixReactionIncoming105(amount:int, source:Avatar, kind:int) : int
      {
         if(kind==4)
         {
            var wound:Object=abilityState.sixReactionMfWound105;
            return wound ? int(amount*(1-Number(wound.value))) : amount;
         }
         if(!source || source.team==team || !source.skillB) return amount;
         var passive:Array=source.sixReactionPassive105("mf");
         return passive ? int(amount*(1+int(source.abilityState.sixReactionMfStacks105)*Number(passive[5]))) : amount;
      }

      private function sixReactionMfDealt105(target:Avatar, amount:Number) : void
      {
         if(amount<=0 || hp<=0 || target.team==team) return;
         var passive:Array=sixReactionPassive105("mf");
         if(!passive) return;
         var strength:Number=Math.min(1,int(abilityState.sixReactionMfStacks105)*Number(passive[6]));
         var wound:Object=target.abilityState.sixReactionMfWound105;
         if(strength>0 && target.hp>0 && (!wound || strength>=Number(wound.value)))
            target.abilityState.sixReactionMfWound105={until:target.abilitySerial+1,value:strength};
         var cast:Object=beginAbilityAttack(this,"passive");
         cast.sixReactionMfHeal105=true;
         try { sixFollowupHeal105(this,amount*Number(passive[4]),true); }
         finally { endAbilityAttack(cast); }
         var surplus:Number=Number(cast.sixReactionMfOverflow105 || 0);
         if(surplus<=0 || buffs.curse) return;
         if(buffs.evil) { removeBuff("evil"); return; }
         var shield:Buff=buffs.sixReactionMfShield105 as Buff;
         if(!shield)
         {
            shield=new Buff("shield",0,0);
            shield.source=this;
            buffs.sixReactionMfShield105=shield;
         }
         shield.value+=surplus;
         queueVitalBar104();
      }

      public function sixReactionConfigurePlant105(skillId:String) : void
      {
         skill0=new SkillSet(skillId,this,1);
         skill1=null;
         skill2=null;
         skillB=null;
         manualAttackRangeOverride=550;
      }

      private function sixReactionZyraDeath105() : void
      {
         var passive:Array=sixReactionPassive105("zyra");
         if(!passive) return;
         var ratio:Number=Number(passive[4]);
         if(skill0 && skill0.skills)
            for each(var action:Array in skill0.skills)
               if(action[0]=="summon" && action[2]=="A_2326_5") { ratio=Number(action[1]); break; }
         for(var i:int=0;i<4;i++)
         {
            var plant:Avatar=new Avatar(GlobalData.modDefinitionId("A_2326_5","summoned"),{lv:lv,slv:1});
            plant.goFight(team,line,0,false);
            if(!plant.inheritSummonPanel(this,ratio)) break;
            plant.sixReactionConfigurePlant105("S_985104001_5");
            plant.addBuff("summon",99);
            GameMap.currentMap.addAvatar(plant,team,line,pos,false);
         }
      }

      private function sixBatchPassive105(kind:String) : Array
      {
         var action:Array=sixStarPassive105();
         return action && action[1]=="six_batch_"+kind+"_p" ? action : null;
      }

      private function sixBatchJinxStacks105() : Array
      {
         var stacks:Array=abilityState.sixBatchJinx105 as Array;
         if(!stacks) return [];
         for(var i:int=stacks.length-1;i>=0;--i)
            if(int(stacks[i])<abilitySerial) stacks.splice(i,1);
         return stacks;
      }

      private function sixBatchKayleStage105() : int
      {
         return GameMap.currentMap && sixBatchPassive105("kayle") ?
            Math.min(4,int(GameMap.currentMap.roundNum/(isLeader ? 7 : 8))) : 0;
      }

      private function sixBatchNear105(center:Avatar, radius:int) : Array
      {
         return abilityCandidates(otherTeam,center.line,center.pos,radius,-1,false,"nearest",[center]);
      }

      private function sixBatchZiggsTarget105() : Avatar
      {
         var target:Avatar=null;
         for each(var foe:Avatar in abilityAllEnemies())
            if(foe.getType()==1 && !foe.isManualSummonUnit && (!target || foe.hpMax>target.hpMax ||
               foe.hpMax==target.hpMax && foe.abilityIndex<target.abilityIndex)) target=foe;
         return target;
      }

      public function sixBatchConfigureSummon105(sand:Boolean, clone:Boolean) : void
      {
         if(!sand && !clone) return;
         skill1=null;
         skill2=null;
         skillB=null;
         if(sand)
         {
            skill0=null;
            abilityState.sixBatchSand105=true;
         }
      }

      private function sixBatchExecute105(kind:String, effect:String, sourceSkill:SkillSet) : Boolean
      {
         var action:Array=sourceSkill.getNativeAction();
         if(!action) return false;
         var context:Object=currentAbilityAttack();
         var target:Avatar=null;
         var foe:Avatar;
         var neighbors:Array;
         if(kind=="six_batch_kayle_c")
         {
            // No dispel flag: this protection lasts through the stated owner turns.
            abilityState.sixBatchKayleGuard105={until:abilitySerial+(sixBatchKayleStage105()==4 ? 2 : 1),value:Number(action[4])};
            abilityState.sixBatchKayleHit105=2000;
            return true;
         }
         if(kind=="six_batch_shaco_box")
         {
            if(!context || context.sixBatchShacoPos105==null) return false;
            var box:Avatar=new Avatar(GlobalData.modDefinitionId("A_2019_5","summoned"),{lv:lv,slv:1});
            box.goFight(team,int(context.sixBatchShacoLine105),0,false);
            if(!box.inheritSummonPanel(this,Number(action[4]))) return false;
            box.addBuff("summon",3);
            GameMap.currentMap.addAvatar(box,team,int(context.sixBatchShacoLine105),int(context.sixBatchShacoPos105),false);
            box.abilityFeedback(box.avatarData.name,effect);
            return true;
         }
         if(kind=="six_batch_jinx_c")
         {
            target=sixStarLowestEnemy105();
            if(!target) return false;
            neighbors=sixBatchNear105(target,500);
            var attack:Number=Tools.toInt(getDamage()*(1+checkTalent(1)));
            var damage:Number=attack*Number(action[4])+(target.hpMax-target.hp)*Number(action[5]);
            context.sixBatchJinxRocket105=true;
            try
            {
               sixStarHit105(target,damage/Math.max(1,attack),1,effect);
               for each(foe in neighbors)
                  sixStarHit105(foe,damage*Number(action[6])/Math.max(1,Tools.toInt(getDamage()*(1+checkTalent(1)))),1,effect);
            }
            finally { delete context.sixBatchJinxRocket105; }
            return true;
         }
         if(kind=="six_batch_tf_n")
         {
            var globalFoes:Array=abilityAllEnemies();
            globalFoes.sort(function(a:Avatar,b:Avatar):Number {
               return int(a.line!=line)-int(b.line!=line) || Math.abs(a.pos-pos)-Math.abs(b.pos-pos) || a.abilityIndex-b.abilityIndex;
            });
            for each(foe in globalFoes.slice(0,4))
               if(sixFollowupHit105(foe,Number(action[4]),2,effect))
                  abilityControl(foe,"weak",2,sixFollowupDebuff105(Number(action[5])));
            return globalFoes.length>0;
         }
         if(kind=="six_batch_ziggs_c")
         {
            target=sixBatchZiggsTarget105();
            if(!target) return false;
            neighbors=sixBatchNear105(target,400).slice(0,3);
            sixStarHit105(target,trueSkillCoefficient104(Number(action[4])),3,effect);
            for each(foe in neighbors) sixStarHit105(foe,trueSkillCoefficient104(Number(action[5])),3,effect);
            return true;
         }
         var targets:Array=sixStarLane105(GameMapConfig.LINE_POS,true);
         if(kind=="six_batch_tf_c")
         {
            if(hp>=hpMax*.9) return false;
            addBuff("purify",2);
            addBuff("shield",2,hpMax*Number(action[5]));
            addBuff("steel",2,Number(action[6]));
            var previousStrong:Buff=buffs.strong as Buff;
            addBuff("strong",2,Number(action[7]));
            abilityState.sixBatchTfMove105={until:abilitySerial+2,value:Number(action[8]),
               strong:buffs.strong!==previousStrong ? buffs.strong : null,debuff:false};
            sixFollowupHeal105(this,(hpMax-hp)*Number(action[9]));
            if(targets.length && sixFollowupHit105(targets[0],Number(action[4]),2,effect))
               abilityControl(targets[0],"stun",1);
            return true;
         }
         if(!targets.length) return false;
         if(kind=="six_batch_jinx_n")
         {
            var repeats:int=1+sixBatchJinxStacks105().length;
            for(var index:int=0;index<repeats && hp>0;index++)
            {
               targets=sixStarLane105(GameMapConfig.LINE_POS,true);
               if(!targets.length) break;
               target=targets[0];
               neighbors=sixBatchNear105(target,350);
               sixStarHit105(target,Number(action[4]),1,effect);
               for each(foe in neighbors) sixStarHit105(foe,Number(action[5]),1,effect);
            }
         }
         else if(kind=="six_batch_ziggs_n")
         {
            target=targets[0];
            neighbors=sixBatchNear105(target,400);
            if(sixFollowupHit105(target,Number(action[4]),2,effect))
            {
               abilityControl(target,"weak",2,sixFollowupDebuff105(Number(action[6])));
               abilityControl(target,"sunder",2,sixFollowupDebuff105(Number(action[7])));
            }
            for each(foe in neighbors) sixStarHit105(foe,Number(action[5]),2,effect);
         }
         else return false;
         return true;
      }

      private function sixBatchDeath105(source:Avatar) : void
      {
         if(hp>0 || abilityState.sixBatchDeath105 || !GameMap.currentMap) return;
         abilityState.sixBatchDeath105=true;
         if(skillB) sixReactionZyraDeath105();
         for each(var observer:Avatar in abilityAllEnemies())
         {
            var sameLane:Boolean=observer.line==line;
            var context:Object=source===observer ? currentAbilityAttack() : null;
            if(observer.skillB && observer.sixBatchPassive105("jinx") &&
               (sameLane || context && context.owner===observer && context.sixBatchJinxRocket105))
            {
               var stacks:Array=observer.sixBatchJinxStacks105();
               stacks.push(observer.abilitySerial+3);
               observer.abilityState.sixBatchJinx105=stacks;
            }
            var lissandra:Array=sameLane && observer.skillB ? observer.sixBatchPassive105("lissandra") : null;
            if(lissandra)
            {
               var response:Object=beginAbilityAttack(observer,"passive");
               try
               {
                  for each(var foe:Avatar in observer.sixBatchNear105(this,300))
                     observer.sixStarHit105(foe,Number(lissandra[4]),2,String(lissandra[3]));
               }
               finally { endAbilityAttack(response); }
            }
         }
      }

      private function sixBatchCurse105() : void
      {
         for each(var observer:Avatar in abilityAllEnemies())
         {
            var passive:Array=observer.skillB ? observer.sixBatchPassive105("shaco") : null;
            if(!passive || hp<=0) continue;
            var response:Object=beginAbilityAttack(observer,"passive");
            try
            {
               if(observer.sixFollowupHit105(this,Number(passive[4]),2,String(passive[3])) && hp>0)
                  addBuff("poison",2,observer.getDamage()*Number(passive[5]),0,-1,observer);
            }
            finally { endAbilityAttack(response); }
         }
      }

      private function sixBatchIncoming105(amount:int, source:Avatar, kind:int, dotKind:String) : int
      {
         if(kind==4)
         {
            var wound:Object=abilityState.sixBatchZiggsWound105;
            return wound ? int(amount*(1-Number(wound.value))) : amount;
         }
         if(!source || source.team==team) return amount;
         var yasuo:Array=skillB ? sixBatchPassive105("yasuo") : null;
         if(yasuo && kind>=1 && kind<=3 && !dotKind && hp>0 && shieldValue104()<=0 &&
            (!abilityState.sixBatchYasuoShield105 || skillB.m_cooldownNum<0))
         {
            var guardContext:Object=beginAbilityAttack(this,"passive");
            try { addBuff("shield",1,hpMax*Number(yasuo[5]),0,-1,this); }
            finally { endAbilityAttack(guardContext); }
            if(shieldValue104()>0)
            {
               abilityState.sixBatchYasuoShield105=true;
               skillB.m_cooldownNum=skillB.skillSetData.cooldown;
            }
         }
         var guard:Object=abilityState.sixBatchKayleGuard105;
         if(guard && int(guard.until)>=abilitySerial)
            amount=int(Math.round(amount*(1-Number(guard.value))*1e8)/1e8);
         var syndra:Array=source.skillB ? source.sixBatchPassive105("syndra") : null;
         if(syndra && GameMap.currentMap)
            amount=int(amount*(1+int(GameMap.currentMap.roundNum/10)*Number(syndra[4])));
         return amount;
      }

      private function sixBatchAfterDamage105(target:Avatar, taken:Number) : void
      {
         if(taken<=0 || hp<=0 || target.team==team || !skillB) return;
         var ziggs:Array=sixBatchPassive105("ziggs");
         if(ziggs && target.hp>0)
            target.abilityState.sixBatchZiggsWound105={until:target.abilitySerial+2,value:Number(ziggs[4]),debuff:true};
         var passive:Array=sixBatchPassive105("tf");
         var attack:Object=currentAbilityAttack();
         if(!passive || attack && attack.owner===this && attack.sixBatchTfProc105) return;
         var key:String="sixBatchTfHits105_"+abilityIndex;
         var count:int=(int(target.abilityState[key])+1)%4;
         target.abilityState[key]=count;
         if(count!=0 || target.hp<=0) return;
         var response:Object=beginAbilityAttack(this,"passive");
         response.sixBatchTfProc105=true;
         try
         {
            for each(var name:String in ["strong","steel","armor","hitup","fleeup","critup","toughup","book_penetration","bless"])
            {
               var buff:Buff=target.buffs[name] as Buff;
               if(!buff) continue;
               target.removeBuff(name);
               addBuff(name,buff.round,buff.value,0,-1,this);
               return;
            }
            abilityControl(target,"curse",1);
            sixStarHit105(target,trueSkillCoefficient104(Number(passive[4])),3,String(passive[3]));
         }
         finally { endAbilityAttack(response); }
      }

      private function sixBatchSpeed105() : Number
      {
         var jinx:Array=skillB ? sixBatchPassive105("jinx") : null;
         var result:Number=jinx ? 1+sixBatchJinxStacks105().length*Number(jinx[4]) : 1;
         var move:Object=abilityState.sixBatchTfMove105;
         if(move)
         {
            result*=1+Number(move.value);
            if(move.strong && move.strong===buffs.strong) result/=1+Number(move.strong.value);
         }
         return result;
      }

      private function sixBatchKayleAttack105(aim:Avatar, stage:int) : int
      {
         var passive:Array=sixBatchPassive105("kayle");
         var targets:Array=sixStarLane105();
         var positions:Array=[];
         var target:Avatar;
         var total:int=0;
         var main:Number=stage>=3 ? trueSkillCoefficient104(Number(passive[5])) : Number(passive[4]);
         var splash:Number=trueSkillCoefficient104(Number(passive[6]));
         for each(target in targets) positions.push(target.pos);
         var attack:Object=beginAbilityAttack(this,"basic");
         try
         {
            for each(target in targets)
            {
               var before:int=target.hp;
               if(sixFollowupHit105(target,main,
                  stage>=3 ? 3 : avatarData.damageType,String(passive[3])))
               {
                  var lost:int=Math.max(0,before-target.hp);
                  total+=lost;
                  applyBookAttackEffects(target,lost);
               }
            }
            if(stage>=3)
               for(var i:int=0;i<targets.length;i++)
               {
                  target=targets[i];
                  for(var j:int=0;j<positions.length && target.hp>0;j++)
                     if(i!=j && Math.abs(positions[i]-positions[j])<=200)
                     {
                        before=target.hp;
                        sixStarHit105(target,splash,3,String(passive[3]));
                        total+=Math.max(0,before-target.hp);
                     }
               }
         }
         finally
         {
            endAbilityAttack(attack);
            emitModEvent("basic_attack",this,aim);
         }
         return total;
      }

      private function sixStarCanCast105(kind:String, distance:int) : Boolean
      {
         switch(kind)
         {
            case "six_reaction_plant_n": return true;
            case "six_reaction_evelynn_c": return sixReactionEvelynnTarget105(sixStarLane105())!=null;
            case "six_reaction_elise_c":
               return !abilityState.root && !buffs.root && sixStarLane105(distance).length>0;
            case "six_batch_kayle_c": return true;
            case "six_batch_tf_c": return hp<hpMax*.9;
            case "six_batch_tf_n":
            case "six_batch_jinx_c": return abilityAllEnemies().length>0;
            case "six_batch_ziggs_c": return sixBatchZiggsTarget105()!=null;
            case "six_batch_shaco_box":
            case "six_batch_jinx_n":
            case "six_batch_ziggs_n": return sixStarLane105(distance).length>0;
         }
         switch(kind)
         {
            case "six_shen_n":
            case "six_yi_c":
               return true;
            case "six_nami_n":
               return sixFollowupAlly105(true)!=null;
            case "six_fiora_n":
               return !abilityState.root && sixStarLane105(distance).length>0;
            case "six_fiora_c":
            case "six_lee_c":
            case "six_irelia_c":
            case "six_morgana_n":
            case "six_morgana_c":
               return sixStarLane105(distance).length>0;
            case "six_caitlyn_c":
               return sixStarLowestEnemy105() != null;
            case "six_kennen_p":
               return sixStarStunned105().length >= 3;
            case "six_yi_n":
            case "six_gangplank_c":
            case "six_blitz_c":
            case "six_akali_c":
            case "six_ahri_c":
            case "six_caitlyn_n":
            case "six_talon_n":
               return sixStarLane105(distance,false,kind=="six_talon_n").length > 0;
         }
         return false;
      }

      private function sixStarHit105(target:Avatar, ratio:Number, kind:int, effect:String) : void
      {
         if(!target || target.hp <= 0 || hp <= 0) return;
         var selected:Vector.<Avatar> = new Vector.<Avatar>();
         selected.push(target);
         attackAimList(selected,kind,ratio,0,effect,false,null,GameMapConfig.LINE_POS+1);
      }

      private function sixStarExecute105(kind:String, effect:String, sourceSkill:SkillSet) : Boolean
      {
         if(kind.indexOf("six_reaction_")==0) return sixReactionExecute105(kind,effect,sourceSkill);
         if(kind.indexOf("six_batch_")==0) return sixBatchExecute105(kind,effect,sourceSkill);
         if(["six_irelia_c","six_lee_c","six_fiora_n","six_fiora_c","six_nami_n","six_morgana_n","six_morgana_c"].indexOf(kind)>=0)
            return sixFollowupExecute105(kind,effect,sourceSkill);
         var action:Array = sourceSkill.getNativeAction();
         var ratio:Number = Number(action[4]);
         var target:Avatar;
         var primary:Avatar;
         var foes:Array;
         var i:int;
         var anchor:int;
         if(kind=="six_yi_c")
         {
            removeBuff("weak");
            addBuff("strong",2,ratio);
            abilityState.highlander={until:abilitySerial+2,left:0,extra:Number(action[5]),debuff:false};
            return true;
         }
         if(kind=="six_shen_n")
         {
            abilityState.sixShen105={charges:3,ratio:ratio,debuff:false};
            return true;
         }
         if(kind=="six_caitlyn_c")
         {
            primary=sixStarLowestEnemy105();
            if(!primary) return false;
            sixStarHit105(primary,ratio,1,effect);
            return true;
         }
         if(kind=="six_kennen_p")
         {
            foes=sixStarStunned105();
            if(foes.length<3) return false;
            for each(target in foes) sixStarHit105(target,ratio,2,effect);
            return true;
         }

         foes=sixStarLane105(Math.abs(sourceSkill.getCastRange()),
             kind=="six_yi_n" || kind=="six_gangplank_c" || kind=="six_ahri_c",kind=="six_talon_n");
         if(!foes.length) return false;
         primary=foes[0] as Avatar;
         switch(kind)
         {
            case "six_yi_n":
               for each(target in foes.slice(0,4)) sixStarHit105(target,ratio,1,effect);
               break;
            case "six_gangplank_c":
               anchor=primary.pos;
               currentAbilityAttack().sixCritTrue105=true;
               for each(target in foes)
                  if(Math.abs(target.pos-anchor)<=300) sixStarHit105(target,ratio,1,effect);
               break;
            case "six_blitz_c":
               for each(target in foes)
               {
                  target.dispelShieldForSkill();
                  target.removeBuff("purify");
                  abilityControl(target,"silence",1);
                  sixStarHit105(target,ratio,2,effect);
               }
               break;
            case "six_akali_c":
            case "six_ahri_c":
               for each(target in foes)
                  if(target.getDamage()>primary.getDamage()) primary=target;
               if(kind=="six_akali_c")
               {
                  abilityControl(primary,"stun",1);
                  sixStarHit105(primary,ratio,2,effect);
               }
               else
               {
                  checkMove(false,300);
                  primary.checkMove(true,500,this,-1,true);
                  sixStarHit105(primary,ratio,2,effect);
                  i=0;
                  for each(target in foes)
                  {
                     if(target===primary) continue;
                     sixStarHit105(target,Number(action[5]),2,effect);
                     if(++i==2) break;
                  }
               }
               break;
            case "six_talon_n":
               for(i=0;i<2;i++) for each(target in foes) sixStarHit105(target,Number(action[4+i]),1,effect);
               break;
            case "six_caitlyn_n":
               checkMove(false,500);
               sixStarHit105(primary,ratio,2,effect);
               if(primary.hp>0) abilityState.sixCaitlyn105={target:primary,ratio:Number(action[5]),effect:effect,debuff:false};
               break;
            default:
               return false;
         }
         return true;
      }

      public function sixStarConfigureTurret105() : void
      {
         abilityState.sixTurret105=true;
         manualAttackRangeOverride=1000;
         skill0=skill1=skill2=skillB=null;
         manualActionTypeOverride=1;
      }

      public function sixStarShenTarget105() : Avatar
      {
         var selected:Avatar=null;
         var sameLane:Boolean=false;
         for each(var ally:Avatar in GameMap.currentMap.getAliveList(team))
         {
            if(ally===this || ally.hp<=0) continue;
            if(ally.line==line) sameLane=true;
            if(!selected || ally.hp<selected.hp) selected=ally;
         }
         return sameLane ? selected : null;
      }

      private function sixStarTurnStart105() : void
      {
         if(abilityState.sixTurret105 && hp>0)
            injured(int(hpMax*.3),1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this);
         var shot:Object=abilityState.sixCaitlyn105;
         if(!shot) return;
         delete abilityState.sixCaitlyn105;
         if(hp<=0 || !shot.target || shot.target.hp<=0) return;
         var attack:Object=beginAbilityAttack(this,"active");
         try { sixStarHit105(shot.target,Number(shot.ratio),1,String(shot.effect)); }
         finally { endAbilityAttack(attack); }
      }

      public function sixStarSkillBegin105(attack:Object, sourceSkill:SkillSet) : void
      {
         if(sourceSkill && sourceSkill === skillB) return;
         if(sourceSkill)
         {
            var row:Object=GlobalData.$mConfig_skill[sourceSkill.skillSetData.id];
            if(row && row.sixStarLeech105) attack.sixLeech105=true;
            if(row && row.sixStarNamiWave105) attack.sixNamiWave105=true;
            if(row && row.sixStarBatchShacoBox105)
            {
               attack.sixBatchShacoLine105=line;
               attack.sixBatchShacoPos105=pos;
            }
         }
         if(!abilityState.sixFire105) return;
         attack.sixFire105 = true;
         delete abilityState.sixFire105;
      }

      public function sixStarSkillFinished105(attack:Object, sourceSkill:SkillSet) : void
      {
         if(hp<=0 || sourceSkill === skillB) return;
         var row:Object=GlobalData.$mConfig_skill[sourceSkill.skillSetData.id];
         if(row && row.sixStarBatchSandHeal105 && manualSummonFamilies)
         {
            for each(var sand:Avatar in manualSummonFamilies["manual-1124-soldier"])
               if(sand && sand.hp>0)
               {
                  sand.hp=sand.hpMax;
                  sand.queueVitalBar104(GameMap.actionDelay);
               }
         }
         if(sourceSkill===skill0 && skillB && sixBatchPassive105("gabriel"))
         {
            var friends:int=abilityCandidates(team,line,pos,GameMapConfig.LINE_POS,-1,false,"nearest",[this]).length;
            sourceSkill.abilityCooldownOverride=Math.max(0,sourceSkill.skillSetData.cooldown-friends);
         }
         if(row && row.sixStarLeech105 && Number(attack.sixDrain105)>0)
            injured(int(attack.sixDrain105),1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this);
         var passive:Array=sixStarPassive105();
         if(!passive) return;
         for(var cast:int=0;cast<int(attack.sixKatarinaRecasts105) && hp>0;++cast)
            sixStarRecastKatarina105();
         switch(passive[1])
         {
            case "six_lee_p":
               abilityState.sixLeeArmed105=true;
               break;
            case "six_morgana_p":
               addBuff("purify",2);
               addBuff("shield",2,int(hpMax*Number(passive[4])));
               break;
            case "six_shen_p":
               addBuff("shield",2,int(hpMax*Number(passive[4])));
               addBuff("steel",2,Number(passive[5]));
               addBuff("taunt",2);
               break;
            case "six_gangplank_p":
               if(sourceSkill===skill1) abilityState.sixFire105=true;
               break;
            case "six_wukong_p":
               if(sourceSkill!==skill1) break;
               for each(var clone:Avatar in abilityState.summons_wukong)
               {
                  if(!clone || clone.hp<=0) continue;
                  clone.skill1=new SkillSet(sourceSkill.skillSetData.id,clone,1,true);
                  try { clone.skill1.useSkill(); }
                  finally { clone.skill1=null; }
               }
               break;
         }
      }

      private function sixStarRecastKatarina105() : void
      {
         abilityState.sixRecast105=true;
         try { if(skill0) skill0.useSkill(); }
         finally { delete abilityState.sixRecast105; }
      }

      private function sixStarCombatEvent105(event:String, target:Avatar, amount:Number, overheal:Number) : void
      {
         if(hp<=0) return;
         var phase:Object=abilityState.highlander;
         if(event=="kill" && phase && phase.extra)
         {
            ++phase.until;
            if(buffs["strong"]) ++buffs["strong"].round;
         }
         var passive:Array=sixStarPassive105();
         if(!passive) return;
         var kind:String=String(passive[1]);
         var ratio:Number=Number(passive[4]);
         var attack:Object=currentAbilityAttack();
         if(event=="kill" && kind=="six_katarina_p" && !abilityState.sixRecast105)
         {
            addBuff("strong",2,ratio);
            if(attack && attack.owner===this && attack.kind=="active" && attack.skill)
               attack.sixKatarinaRecasts105=int(attack.sixKatarinaRecasts105)+1;
            else sixStarRecastKatarina105();
         }
         else if(event=="basic_attack" && kind=="six_wukong_p")
         {
            for each(var clone:Avatar in abilityState.summons_wukong)
            {
               if(!clone || clone.hp<=0) continue;
               var cloneTargets:Array;
               var victim:Avatar=target && target.hp>0 && target.line==clone.line ? target : null;
               if(!victim)
               {
                  cloneTargets=clone.sixStarLane105();
                  victim=cloneTargets.length ? cloneTargets[0] as Avatar : null;
               }
               if(victim)
               {
                  var one:Vector.<Avatar> =new Vector.<Avatar>();
                  one.push(victim);
                  clone.attackAimList(one,-1,1,0,null,false,null,GameMapConfig.LINE_POS+1);
               }
            }
         }
         else if(event=="healed" && kind=="six_ahri_p" && hp>=hpMax && amount==0 && overheal>0)
         {
            addBuff("purify",1);
            addBuff("hitup",1,ratio);
            addBuff("fleeup",1,ratio);
         }
         else if(event=="hit" && target && target.hp>0 && attack && attack.owner===this && !attack.sixDerived105)
         {
            if(kind=="six_jarvan_p" && buffs["strong"])
            {
               abilityControl(target,"sunder",1,ratio);
               abilityControl(target,"weak",1,ratio);
            }
            else if(kind=="six_gangplank_p" && attack.sixFire105)
            {
               delete attack.sixFire105;
               target.addManualSkillDot(id+":six_fire","burn",getDamage()*ratio,0,2,this,1);
            }
            else if(kind=="six_darius_p")
               sixStarBleed105(target,ratio,Number(passive[5]));
            else if(kind=="six_talon_p" && attack.kind=="active" && attack.skill!==skillB)
            {
               var key:String="sixTalonHits_"+abilityIndex;
               var hits:int=(int(target.abilityState[key])+1)%3;
               target.abilityState[key]=hits;
               if(!hits) target.addManualSkillDot(id+":six_talon","bleed",getDamage()*ratio,0,3,this,1);
            }
         }
      }

      private function sixStarBleed105(target:Avatar, ratio:Number, fury:Number) : void
      {
         var prefix:String=id+":six_darius:";
         var layers:Array=[];
         for(var key:String in target.manualSkillDots)
            if(key.indexOf(prefix)==0) layers.push(key);
         var index:int=0;
         while(index<4 && layers.indexOf(prefix+index)>=0) ++index;
         var next:String=prefix+index;
         if(target.yasuoImmune104("bleed") || target.s2AnnieImmune() || target.hasModBuff("purify"))
         {
            target.addManualSkillDot(next,"bleed",getDamage()*ratio,0,3,this,1);
            return;
         }
         target.addManualSkillDot(next,"bleed",getDamage()*ratio,0,3,this,1);
         for each(key in layers) target.manualSkillDots[key].round=3;
         if(layers.length>=4 && !abilityState.sixBloodrage105)
         {
            abilityState.sixBloodrage105=true;
            addManualBattleStack("attack",fury,1);
            addManualBattleStack("defense",fury,1);
         }
      }

      private function sixStarCriticalDamage105(target:Avatar, raw:int, share:Number) : Array
      {
         var converted:Array=countDamage(this,target,Tools.toInt(raw*trueSkillCoefficient104()),3,share);
         converted[2]=3;
         return converted;
      }

      private function sixStarDirectInjury105(target:Avatar, damage:Array, crit:Number, options:*, kind:int,
            visualSource:Avatar, appliedBuff:Buff, raw:int, share:Number) : int
      {
         var attack:Object=currentAbilityAttack();
         var before:int=target.hp;
         var effective:int=damage.length>2 ? int(damage[2]) : kind;
         var result:int=target.injured(damage[0],crit,options,effective,visualSource,damage[1],this,appliedBuff);
         if(kind<1 || kind>3 || !attack || attack.owner!==this || attack.sixDerived105) return result;
         if(attack.sixLeech105)
            attack.sixDrain105=Number(attack.sixDrain105 || 0)+Math.max(0,before-Math.max(0,target.hp));
         if(target.hp<=0 || hp<=0 || attack.skill===skillB) return result;
         var bonus:int=0;
         var bonusType:int=3;
         var fiora:Boolean=Boolean(attack.sixFioraTrue105);
         if(fiora)
         {
            bonus=int(target.hpMax*Number(attack.sixFioraTrue105));
         }
         else if(attack.sixShenStrike105)
         {
            bonusType=1;
            bonus=int(countDamage(this,target,int(hpMax*Number(attack.sixShenStrike105)),1,1)[0]);
         }
         else if((attack.kind=="basic" || attack.kind=="active") && abilityState.highlander && abilityState.highlander.extra)
         {
            var sign:Number=AvatarData.damageRate(avatarData.signType,target.avatarData.signType);
            bonus=int(raw*share*crit*sign*Number(abilityState.highlander.extra));
         }
         if(bonus>0)
         {
            attack.sixDerived105=true;
            try
            {
               target.injured(bonus,bonusType==1 || fiora ? crit : 1,DisplayTools.getAttrs("FX60_SLASH"),
                  bonusType,this,false,this,null,"",bonusType==3 && !fiora);
            }
            finally { delete attack.sixDerived105; }
         }
         return result;
      }


      private function abilityEnemies(distance:Number, center:Avatar = null, maximum:int = 1, heroOnly:Boolean = false, order:String = "nearest", excluded:Array = null, forward:Boolean = false) : Array
      {
         if(center == null)
         {
            var context:Object = currentAbilityAttack();
            if(context && context.owner === this && context.kind == "active" && context.skill)
            {
               var configured:int = context.skill.getCastRange();
               if(configured > 0) distance = configured;
               var rangeAction:Array = context.skill.getNativeAction();
               if(rangeAction && rangeAction[0] == "manual_ability" && rangeAction[1] == "jayce_n") distance = abilityState.form && abilityState.form.hammer ? 1500 : GameMapConfig.LINE_POS;
            }
         }
         if(center != null || maximum != 1) distance = skillAreaRadius(distance);
         center = center || this;
         return abilityCandidates(otherTeam,center.line,center.pos,distance,maximum,heroOnly,order,excluded,forward);
      }

      private function abilityCandidates(whichTeam:int, lane:int, position:Number, distance:Number, maximum:int, heroOnly:Boolean = false, order:String = "nearest", excluded:Array = null, forward:Boolean = false) : Array
      {
         var result:Array = [];
         if(!GameMap.currentMap) return result;
         var list:Vector.<Avatar> = GameMap.currentMap.getAliveList(whichTeam) as Vector.<Avatar>;
         for each(var candidate:Avatar in list)
         {
            if(!candidate || candidate.hp <= 0 || candidate.line != lane || Math.abs(candidate.pos-position) > distance) continue;
            if(heroOnly && (candidate.getType() != 1 || candidate.isManualSummonUnit)) continue;
            if(excluded && excluded.indexOf(candidate) >= 0) continue;
            if(forward && (team == 1 ? candidate.pos > position : candidate.pos < position)) continue;
            result.push(candidate);
         }
         result.sort(function(a:Avatar,b:Avatar):Number
         {
            if(order == "ratio") return a.hp/a.hpMax-b.hp/b.hpMax || a.abilityIndex-b.abilityIndex;
            if(order == "front") return (whichTeam == 1 ? a.pos-b.pos : b.pos-a.pos) || a.abilityIndex-b.abilityIndex;
            var delta:Number = Math.abs(a.pos-position)-Math.abs(b.pos-position);
            if(order == "farthest") delta = -delta;
            return delta || a.abilityIndex-b.abilityIndex;
         });
         return maximum < 0 ? result : result.slice(0,maximum);
      }

      private function abilityAlly(distance:Number = 3001, order:String = "ratio", excludeSelf:Boolean = false) : Avatar
      {
         var list:Array = abilityCandidates(team,line,pos,distance,1,true,order,excludeSelf ? [this] : null);
         return list.length ? list[0] as Avatar : null;
      }

      private function abilityMarkedTarget(mark:String, distance:Number, order:String = "nearest") : Avatar
      {
         var context:Object = currentAbilityAttack();
         if(context && context.owner === this && context.skill) distance = context.skill.getCastRange();
         var list:Array = abilityCandidates(otherTeam,line,pos,distance,-1,true,order);
         for each(var target:Avatar in list) if(target.abilityHasMark(this,mark)) return target;
         return list.length ? list[0] as Avatar : null;
      }

      private function abilityHasMark(owner:Avatar, kind:String) : Boolean
      {
         var mark:Object = abilityState["mark_"+kind+"_"+owner.abilityIndex];
         return mark && int(mark.until) >= abilitySerial;
      }

      private function abilityMark(target:Avatar, kind:String, duration:int, scale:Number = 1) : void
      {
         if(target && target.hp > 0 && !target.s2AnnieImmune())
         {
            target.abilityState["mark_"+kind+"_"+abilityIndex] = {until:target.abilitySerial+duration,owner:this,debuff:true,scale:scale};
            target.s2AnnieStatus("mark");
         }
      }

      private function abilityHit(target:Avatar, coefficient:Number, kind:int, effect:String, sharedTotal:Number = 0, visualSource:Avatar = null) : Boolean
      {
         if(!target || target.hp <= 0 || hp <= 0) return false;
         var context:Object = currentAbilityAttack();
         var hitCount:int = context ? int(context.hitSerial) : 0;
         var one:Vector.<Avatar> = new Vector.<Avatar>(); one.push(target);
         // The profile multiplier belongs to this manual action's damage,
         // not to its healing, shield, debuff or a nested normal skill.
         var manualFactor:Number = context && context.owner === this ? Number(context.manualDamageMultiplier) : 1;
         if(!isFinite(manualFactor) || manualFactor <= 0) manualFactor = 1;
         manualFactor *= heroSkillOutputRate104();
         coefficient *= manualFactor;
         if(sharedTotal > 0) sharedTotal *= manualFactor;
         if(kind == 3) coefficient = trueSkillCoefficient104(coefficient);
         var total:Number = sharedTotal > 0 ? sharedTotal : coefficient;
         var q:Number = sharedTotal > 0 ? coefficient/sharedTotal : 1;
         attackAimList(one,kind,total,0,effect,false,null,-1,q,visualSource);
         return context && (int(context.hitSerial) > hitCount);
      }

      public function heroSkillOutputRate104() : Number
      {
         var rate:Object = GlobalData.$mConfig_simple.hero_skill_output_rate_104;
         return getType() == 1 && rate != null ? Number(rate)*equipmentOutputRate104() : 1;
      }

      public function poisonSkillOutputRate104() : Number
      {
         var row:Object = GlobalData.$mConfig_avatar ? GlobalData.$mConfig_avatar[avatarData.id] : null;
         var pack:String = row ? row.builtin_pack_104 : null;
         var rate:Number = pack ? Number(GlobalData.$mConfig_simple.hero_skill_output_rate_104)*equipmentOutputRate104() : heroSkillOutputRate104();
         return pack == "nine" ? rate * 2 / 3 : rate;
      }

      private function abilityHeal(target:Avatar, coefficient:Number) : void
      {
         if(!target || target.hp <= 0) return;
         flushParallelVisualBatch();
         var one:Vector.<Avatar> = new Vector.<Avatar>(); one.push(target);
         attackAimList(one,4,coefficient*heroSkillOutputRate104(),0,"FX60_HEAL");
      }

      private function abilityShield(target:Avatar, coefficient:Number, duration:int = 2, healthOnly:Boolean = false) : void
      {
         if(!target || target.hp <= 0) return;
         coefficient *= purpleBondMultiplier()*heroSkillOutputRate104();
         target.addBuff("shield",duration,Tools.toInt((healthOnly ? getHpMax() : getDamage()+0.1*getHpMax())*coefficient),0,-1,ratioDamage104() ? this : null);
      }

      private function abilityControl(target:Avatar, kind:String, duration:int, value:Number = 0) : void
      {
         if(!target || target.hp <= 0) return;
         if(target.s2AnnieImmune()) return;
         if(target.abilityState.channel && ["stun","silence","root","pull","push"].indexOf(kind)>=0) return;
         if(kind == "root")
         {
            if(target.buffs["purify"]) { target.removeBuff("purify",true); return; }
            target.abilityState.root = {until:target.abilitySerial+duration,debuff:true};
            target.addBuff("root",duration);
            return;
         }
         target.addBuff(kind,duration,value);
      }

      private function abilityDash(target:Avatar, enemySide:Boolean = false) : Boolean
      {
         if(!target || target.hp <= 0 || abilityState.root) return false;
         var destination:int = target.pos+(team == 1 ? 125 : -125)*(enemySide ? -1 : 1);
         reline(target.line,Math.max(0,Math.min(GameMapConfig.LINE_POS,destination)));
         return true;
      }

      private function abilityPull(target:Avatar, center:Avatar, amount:int) : void
      {
         prepareParallelVisualTarget(target,false);
         if(target && target.hp > 0 && center) target.checkMove(true,amount,center,-1,true);
      }

      private function abilityIsolated(target:Avatar) : Boolean
      {
         if(!target) return false;
         return abilityCandidates(target.team,target.line,target.pos,300,-1,true,"nearest",[target]).length == 0;
      }

      private function abilitySummon(aid:String, count:int, ratio:Number, turns:int, key:String, focus:Avatar = null, clone:Boolean = false) : void
      {
         var summonRow:Object=null;
         if(clone && key=="wukong")
         {
            var summonerAttack:Object=currentAbilityAttack();
            if(summonerAttack && summonerAttack.skill)
               summonRow=GlobalData.$mConfig_skill[summonerAttack.skill.skillSetData.id];
         }
         if(summonRow && summonRow.sixStarClone105) ratio=1;
         else ratio *= activeManualEffectMultiplier();
         if(!Avatar.isValidSummonMultiplier(ratio)) return;
         var previous:Array = abilityState["summons_"+key] as Array;
         if(previous) for each(var old:Avatar in previous) if(old && old.hp > 0) { old.hp = 0; old.deadFast(); }
         var units:Array = [];
         for(var i:int=0;i<count;i++)
         {
            var unit:Avatar = new Avatar(GlobalData.modDefinitionId(clone ? avatarData.id : aid,"summoned"),{lv:lv,slv:1});
            unit.goFight(team,line,0,false);
            if(!unit.inheritSummonPanel(this,ratio)) return;
            unit.speed = 220; unit.range = 350; unit.skill0 = null; unit.skill1 = null; unit.skill2 = null; unit.skillB = null;
            unit.manualActionTypeOverride = 1;
            unit.addBuff("summon",turns);
            if(clone) unit.addBuff("taunt",1);
            if(focus) unit.manualFocusTarget = focus;
            GameMap.currentMap.addAvatar(unit,team,line,Math.max(0,Math.min(GameMapConfig.LINE_POS,pos+(team == 1 ? -1 : 1)*(125+100*i))),false);
            units.push(unit);
         }
         abilityState["summons_"+key] = units;
      }

      public var summonStatSnapshot:Boolean = false;

      public function getSummonPanelSnapshot() : Object
      {
         return {"hpMax":getHpMax(),
                 "ap":Tools.toInt(getDamage() * (1 + checkTalent(1))),
                 "dePh":Tools.toInt(getDePh() * (1 + checkTalent(2))),
                 "deMa":Tools.toInt(getDeMa() * (1 + checkTalent(3))),
                 "hit":getHit(),"flee":getFlee(),"crit":getCrit(),"tough":getTough()};
      }

      private function scaledSummonStat(value:Number, ratio:Number, minimum:int) : int
      {
         if(!isFinite(value)) return minimum;
         return int(Math.min(2147483647,Math.max(minimum,Math.floor(value * ratio))));
      }

      public function inheritSummonPanel(owner:Avatar, apRatio:Number, hpRatio:Number = -1, dePhRatio:Number = -1, deMaRatio:Number = -1, secondaryRatio:Number = -1) : Boolean
      {
         if(hpRatio == -1) hpRatio = apRatio;
         if(dePhRatio == -1) dePhRatio = apRatio;
         if(deMaRatio == -1) deMaRatio = apRatio;
         if(secondaryRatio == -1) secondaryRatio = apRatio;
         if(!owner || !isValidSummonMultiplier(apRatio) || !isValidSummonMultiplier(hpRatio) || !isValidSummonMultiplier(dePhRatio) || !isValidSummonMultiplier(deMaRatio) || !isValidSummonMultiplier(secondaryRatio)) return false;
         var panel:Object = owner.abyssSummonPanel104(owner.getSummonPanelSnapshot());
         abyssReduction104 = owner.abyssReduction104;
         statisticsOwner104 = owner;
         hpMax = scaledSummonStat(Number(panel.hpMax),hpRatio,1);
         hp = hpMax;
         ap = scaledSummonStat(Number(panel.ap),apRatio,1);
         dePh = scaledSummonStat(Number(panel.dePh),dePhRatio,0);
         deMa = scaledSummonStat(Number(panel.deMa),deMaRatio,0);
         hit = scaledSummonStat(Number(panel.hit),secondaryRatio,0);
         flee = scaledSummonStat(Number(panel.flee),secondaryRatio,0);
         crit = scaledSummonStat(Number(panel.crit),secondaryRatio,0);
         tough = scaledSummonStat(Number(panel.tough),secondaryRatio,0);
         abilityEntryAttack = ap;
         // The owner's live talent/aura contribution is already in this snapshot.
         summonStatSnapshot = true;
         return true;
      }

      public static function isValidSummonMultiplier(ratio:Number) : Boolean
      {
         return isFinite(ratio) && ratio >= 0.01 && ratio <= 100;
      }

      private function abilityClearStates(debuffs:Boolean) : void
      {
         for(var key:String in abilityState)
         {
            var state:Object = abilityState[key];
            if(state && !(state is Number) && !(state is Boolean) && !(state is String) && !(state is Avatar) && !(state is Array) && state.debuff === debuffs) delete abilityState[key];
         }
      }

      private function abilityBombExplode(bomb:Object) : void
      {
         fxPulse104("bomb");
         var owner:Avatar = bomb.owner as Avatar;
         if(!owner || owner.hp <= 0) return;
         var context:Object = beginAbilityAttack(owner,"active");
         abyssRestoreContext104(context,bomb.abyssRelicContext104);
         context.manualDamageMultiplier = bomb.manualDamageMultiplier;
         var targets:Array = owner.abilityCandidates(owner.otherTeam,line,pos,250,4);
         if(hp > 0 && targets.indexOf(this) < 0) { targets.unshift(this); targets = targets.slice(0,4); }
         var bombPresentation:Object = owner.beginParallelVisualBatch();
         try
         {
         for each(var target:Avatar in targets) owner.abilityHit(target,Number(bomb.coefficient),2,"FX_A_1098_MAGIC");
         }
         finally { owner.endParallelVisualBatch(bombPresentation); endAbilityAttack(context); }
      }

      private function abilityDeath() : void
      {
         if(abilityState.deathHandled) return;
         abilityState.deathHandled = true;
         sixBatchDeath105(null);
         for(var key:String in abilityState)
         {
            var state:Object = abilityState[key];
            if(key.indexOf("bomb_") == 0) { delete abilityState[key]; if(abilityState.bombConsumeOwner !== state.owner) abilityBombExplode(state); }
            else if(key.indexOf("malz_") == 0 && state.hops == 0 && state.ticks > 0)
            {
               delete abilityState[key];
               var owner:Avatar = state.owner as Avatar;
               if(owner)
               {
                  var next:Array = owner.abilityCandidates(team,line,pos,300,1,false,"nearest",[this]);
                  if(next.length)
                  {
                     var infected:Avatar = next[0];
                     if(infected.s2AnnieImmune()) continue;
                     if(infected.buffs.purify) {infected.removeBuff("purify",true); continue;}
                     state.hops = 1; state.until = infected.abilitySerial+1; infected.abilityState[key] = state;
                     infected.s2AnnieStatus("poison");
                  }
               }
            }
         }
      }

      private function abilityTurnStart() : Boolean
      {
         ++abilitySerial;
         if(buffs.sixReactionMfShield105 && Number(buffs.sixReactionMfShield105.value)>0)
            abilityState.sixReactionMfStacks105=int(abilityState.sixReactionMfStacks105)+1;
         var key:String;
         var state:Object;
         var owner:Avatar;
         for(key in abilityState)
         {
            state = abilityState[key];
            if(!state || state is Number || state is Boolean || state is String || state is Avatar || state is Array) continue;
            if(key.indexOf("bomb_") == 0 && abilitySerial >= state.until) { delete abilityState[key]; abilityBombExplode(state); }
            else if(key.indexOf("malz_") == 0 && abilitySerial >= state.until)
            {
               --state.ticks;
               state.until = abilitySerial+1;
               injured(int(state.tickDamage),1,DisplayTools.getAttrs("FX_A_1103_MAGIC"),6,state.owner,false,state.owner,null,"phantasm");
               if(hp <= 0) { dead(); return true; }
               if(state.ticks <= 0) delete abilityState[key];
            }
            else if(key == "grey" && abilitySerial >= state.until)
            {
               delete abilityState.grey;
               if(hp > 0 && state.value > 0) { var greyShield:int = int(state.value * getRecoveryTalentMultiplier()*heroSkillOutputRate104()); addBuff("shield",2,greyShield); abilityFeedback("灰色生命转护盾："+greyShield,"FX_S9160_SHIELD"); }
            }
            else if(state.until != undefined && abilitySerial > state.until) delete abilityState[key];
         }
         state = abilityState.zone;
         if(state && hp > 0)
         {
            var zoneContext:Object = beginAbilityAttack(this,"active");
         abyssRestoreContext104(zoneContext,state.abyssRelicContext104);
            zoneContext.manualDamageMultiplier = state.manualDamageMultiplier;
            zoneContext.manualEffectMultiplier = state.manualEffectMultiplier;
            for each(var enemy:Avatar in abilityCandidates(otherTeam,state.line,state.pos,350,3))
            {
               if(abilityHit(enemy,1.2,1,"FX_A_1011_PHYSICAL")) abilityControl(enemy,"weak",1,0.2);
            }
            endAbilityAttack(zoneContext);
            if(--state.left <= 0) delete abilityState.zone;
         }
         state = abilityState.channel;
         if(state)
         {
            delete abilityState.channel;
            if(hp > 0 && !buffs.stun && !buffs.silence && pos == state.pos && line == state.line)
            {
               var channelContext:Object = beginAbilityAttack(this,"active");
         abyssRestoreContext104(channelContext,state.abyssRelicContext104);
               channelContext.manualDamageMultiplier = state.manualDamageMultiplier;
               channelContext.manualEffectMultiplier = state.manualEffectMultiplier;
               var channelPresentation:Object = beginParallelVisualBatch();
               try
               {
               for each(enemy in abilityEnemies(400,null,3)) if(abilityHit(enemy,3.6,2,"FX_A_1073_MAGIC")) abilityControl(enemy,"weak",2,0.3);
               }
               finally { endParallelVisualBatch(channelPresentation); endAbilityAttack(channelContext); }
               return true;
            }
         }
         return hp <= 0 || Boolean(skin2.eggUntil);
      }
      public static function skillAreaRadius(value:Number) : int
      {
         var scale:Number = Number(GlobalData.$mConfig_simple.skill_effect_radius_scale);
         return Math.round(value*(isFinite(scale) && scale > 0 ? scale : 1));
      }

      private function abilityFeedback(label:String, effect:String = "", color:uint = 16764006) : void
      {
         var layer:GameMapLayer = GameMapLayer.gl;
         if(!layer || !fightRes || !fightRes.parent) return;
         layer.delayCall(layer.infoLayer.popTextForAvatar,GameMap.actionDelay,label,this,color,22,1);
         if(effect.length > 0)
         {
            var attributes:Object = DisplayTools.getAttrs(effect);
            if(attributes)
            {
               attributes = Tools.clone(attributes);
               attributes.a1 = this;
               attributes.par = layer.effectLayer;
               layer.delayCall(DisplayTools.addEffects,GameMap.actionDelay,attributes);
            }
         }
      }

      private function nativeAbilityNumber(sourceSkill:*, kind:String, key:String, fallback:Number) : Number
      {
         var row:Object = sourceSkill && sourceSkill.skillSetData && GlobalData.$mConfig_skill ? GlobalData.$mConfig_skill[sourceSkill.skillSetData.id] : null;
         var parameters:Object = row && row.modNativeSource ? row.nativeAbilityParameters : null;
         var values:Object = parameters ? parameters[kind] : null;
         if(!values || !values.hasOwnProperty(key) || typeof values[key] != "number" || !isFinite(Number(values[key]))) return fallback;
         return Number(values[key]);
      }






















      // BEGIN DRAGONMANCER KAISA 104
      // Dragonmancer Kai'Sa keeps per-caster volley growth and per-root target marks.
      public var kaisaRoot104:Avatar;
      public var kaisaCast104:Number = 0;
      private var kaisaMarks104:Object = {};
      private var kaisaHunting104:Boolean = false;
      private var kaisaBurst104:Boolean = false;
      private var kaisaPlasmaIcons104:Object = {};

      private function kaisaIs104() : Boolean
      {
         var row:Object = GlobalData.$mConfig_avatar ? GlobalData.$mConfig_avatar[avatarData.id] : null;
         return row && row.dragonmancerKaisa104 === true;
      }
      private function kaisaLane104(lane:int) : Array
      {
         return abilityCandidates(otherTeam,lane,GameMapConfig.LINE_POS/2,GameMapConfig.LINE_POS,-1,false,"front");
      }
      private function kaisaTarget104() : Avatar
      {
         if(!kaisaIs104() || kaisaRoot104 || !isLeader || hp<=0 || !GameMap.currentMap) return null;
         var single:Boolean=kaisaSingleLane104();
         for each(var unit:Avatar in GameMap.currentMap.getAliveList(otherTeam))
            if(unit.hp>0 && !GameMap.currentMap.isEnd(unit.line) && (unit.line!=line || single) && unit.getType()==1 && !unit.isManualSummonUnit && unit.buffs.stun) return unit;
         return null;
      }
      private function kaisaSingleLane104() : Boolean
      {
         var map:GameMap=GameMap.currentMap;
         if(!map || map.isEnd() || !map.winnerList || map.isEnd(line)) return false;
         var remaining:int=0;
         for(var lane:int=0;lane<map.winnerList.length;lane++) if(!map.isEnd(lane)) ++remaining;
         return remaining==1;
      }
      private function kaisaCanCast104(kind:String) : Boolean
      {
         if(!kaisaIs104() || hp<=0) return false;
         if(kind=="dragon_kaisa_n") return kaisaLane104(line).length>0;
         if(kind=="dragon_kaisa_c") return skill0 && !kaisaHunting104 && kaisaTarget104()!=null;
         return false;
      }
      private function kaisaTryCaptain104() : Boolean
      {
         if(!skill1 || skill1.m_cooldownNum>=0 || !kaisaCanCast104("dragon_kaisa_c")) return false;
         var enabled:Boolean=false;
         for each(var action:Array in skill1.skills) if(action[0]=="manual_ability" && action[1]=="dragon_kaisa_c") enabled=true;
         if(!enabled) return false;
         return skill1.checkUse();
      }
      private static function kaisaNotifyStun104(stunned:Avatar) : void
      {
         if(!GameMap.currentMap || !stunned || stunned.hp<=0 || !stunned.buffs.stun || stunned.getType()!=1 || stunned.isManualSummonUnit) return;
         var watchers:Vector.<Avatar> = (GameMap.currentMap.getAliveList(stunned.otherTeam) as Vector.<Avatar>).concat();
         for each(var watcher:Avatar in watchers) if(watcher) watcher.kaisaTryCaptain104();
      }
      private function kaisaExecute104(kind:String, sourceSkill:*) : Boolean
      {
         if(!kaisaCanCast104(kind)) return false;
         if(kind=="dragon_kaisa_c") return kaisaHunt104();
         return kaisaVolley104(sourceSkill || skill0);
      }
      private function kaisaVolley104(sourceSkill:*) : Boolean
      {
         var castLane:int=line;
         if(!sourceSkill || !sourceSkill.skills || !kaisaLane104(castLane).length) return false;
         var count:Number=3+2*kaisaCast104;
         ++kaisaCast104;
         var coefficient:Number=Number(sourceSkill.skills[0][4]);
         var globalRate:Number=Number(GlobalData.$mConfig_simple.hero_skill_output_rate_104);
         if(!isFinite(globalRate) || globalRate<=0) globalRate=1;
         var seen:Array=[];
         var abyssVolleyHits104:Array=[];
         for(var shot:Number=0;shot<count && hp>0;shot++)
         {
            var live:Array=kaisaLane104(castLane);
            if(!live.length) break;
            var target:Avatar=null;
            for each(var candidate:Avatar in live) if(seen.indexOf(candidate)<0) {target=candidate;break;}
            if(!target) {seen=[];target=live[0];}
            seen.push(target);
            kaisaProjectile104(target,shot);
            // Each missile owns a full settlement boundary. In particular,
            // endAbilityAttack handles retaliation before reacquiring the next.
            var context:Object=beginAbilityAttack(this,"active");
            context.skill=sourceSkill;
            context.manualDamageMultiplier=sourceSkill.getNativeSetting("manualDamageMultiplier",1);
            context.abyssHits104=abyssVolleyHits104;
            try
            {
               var hit:Boolean=abilityHit(target,coefficient/globalRate,2,"FX_KAISA_MISSILE104");
               var sunder:Number=(kaisaRoot104 || this).skinBondNumber104("kaisa_q_sunder");
               if(hit && hp>0 && target.hp>0 && sunder>0 && sunder<1)
                  abilityControl(target,"sunder",1,sunder/(1-sunder));
            }
            finally {endAbilityAttack(context);}
            GameMap.actionDelay+=0.08;
         }
         return true;
      }
      private function kaisaHunt104() : Boolean
      {
         var target:Avatar=kaisaTarget104();
         if(!target || kaisaHunting104) return false;
         var front:Array=kaisaLane104(target.line);
         if(!front.length) return false;
         var oldLine:int=line;
         var oldPos:int=pos;
         kaisaHunting104=true;
         try
         {
            var clone:Avatar=new Avatar(GlobalData.modDefinitionId(avatarData.id,"summoned"),{lv:lv,slv:skill0.lv});
            clone.goFight(team,oldLine,0,false);
            if(!clone.inheritSummonPanel(this,1)) return false;
            clone.kaisaRoot104=kaisaRoot104 || this;
            clone.kaisaCast104=0;
            clone.skill0=new SkillSet(skill0.skillSetData.id,clone,skill0.lv);
            clone.skillB=skillB ? new SkillSet(skillB.skillSetData.id,clone,skillB.lv) : null;
            clone.skill1=null;
            clone.skill2=null;
            clone.speed=speed;
            clone.range=getRange();
            clone.addBuff("summon",7);
            kaisaProtect104(clone);
            var destination:int=int(front[0].pos)+(team==1 ? 500 : -500);
            var landingDelay:Number=GameMap.actionDelay+2;
            reline(target.line,Math.max(0,Math.min(GameMapConfig.LINE_POS,destination)));
            // Add after moving the caster, so native spacing doesn't push the
            // clone away from the position just vacated by its own body.
            GameMap.currentMap.addAvatar(clone,team,oldLine,oldPos,false);
            if(clone.m_icon) clone.m_icon.color=0x83EADA;
            // reline refreshes its visual at +1.4s, then scales back in.
            // Read the launch position only after that landing has completed.
            GameMap.actionDelay=Math.max(GameMap.actionDelay,landingDelay);
            // Run the real normal-skill path (including its cast events),
            // bypassing only readiness and preserving its pre-existing timer.
            var savedCooldown:int=skill0.m_cooldownNum;
            try {skill0.useSkill();}
            finally {skill0.m_cooldownNum=savedCooldown;}
            return true;
         }
         finally {kaisaHunting104=false;}
      }
      private function kaisaProtect104(newClone:Avatar) : void
      {
         var recipients:Array=[this,newClone];
         for each(var unit:Avatar in GameMap.currentMap.getAliveList(team))
            if(unit.hp>0 && unit.kaisaRoot104===this && recipients.indexOf(unit)<0) recipients.push(unit);
         for each(var recipient:Avatar in recipients)
         {
            if(!recipient || recipient.hp<=0) continue;
            // Cleanse first so an existing curse cannot reject the shield.
            recipient.addBuff("purify",3,0,0,-1,this);
            recipient.addBuff("shield",3,Tools.toInt(recipient.getHpMax()*.6),0,-1,this);
         }
      }
      private function kaisaEvent104(event:String,source:Avatar,target:Avatar) : void
      {
         if(event!="hit" || source!==this || !kaisaIs104() || kaisaBurst104 || !target || target.hp<=0 || target.team==team || !skillB) return;
         var enabled:Boolean=false;
         for each(var action:Array in skillB.skills) if(action[0]=="manual_ability" && action[1]=="dragon_kaisa_p") enabled=true;
         if(!enabled) return;
         var context:Object=currentAbilityAttack();
         if(!context || context.owner!==this || (context.kind!="basic" && context.kind!="active")) return;
         var root:Avatar=kaisaRoot104 || this;
         var key:String=String(root.abilityIndex);
         target.kaisaMarks104[key]=int(target.kaisaMarks104[key])+1;
         if(int(target.kaisaMarks104[key])<5)
         {
            target.kaisaQueuePlasma104(key,int(target.kaisaMarks104[key]));
            return;
         }
         target.kaisaMarks104[key]=int(target.kaisaMarks104[key])-5;
         target.kaisaQueuePlasma104(key,int(target.kaisaMarks104[key]));
         kaisaBurst104=true;
         var burst:Object=beginAbilityAttack(this,"passive");
         try
         {
            target.addBuff("curse",1,0,0,-1,this);
            var raw:int=Tools.toInt(target.getHpMax()*.2);
            // Fixed maximum-health true damage bypasses the AP/armor/RPS
            // calculation and its historical true-AP coefficient.
            target.injured(raw,1,null,3,this,false,this);
            if(hp>0) injured(Tools.toInt(getHpMax()*.05),1,null,4,this,false,this);
         }
         finally {endAbilityAttack(burst);kaisaBurst104=false;}
      }
      private function kaisaQueuePlasma104(key:String, stacks:int) : void
      {
         GameMapLayer.gl.delayCall(kaisaShowPlasma104,GameMap.actionDelay,key,stacks,GameMap.currentMap);
      }
      private function kaisaShowPlasma104(key:String, stacks:int, battle:GameMap) : void
      {
         if(GameMap.currentMap!==battle || !m_fightRes) return;
         var old:Image=kaisaPlasmaIcons104[key] as Image;
         if(old && old.parent) old.removeFromParent(true);
         delete kaisaPlasmaIcons104[key];
         if(stacks>=1 && stacks<=4)
         {
            var texture:starling.textures.Texture=GlobalData.$assetManager.getTexture("MOD_KAISA_PLASMA104_"+stacks);
            if(texture)
            {
               var mark:Image=new Image(texture);
               mark.touchable=false;
               mark.pivotX=texture.width*.5;mark.pivotY=texture.height*.5;
               kaisaPlasmaIcons104[key]=mark;
               m_fightRes.addChild(mark);
            }
         }
         var active:Array=[];
         for each(var image:Image in kaisaPlasmaIcons104) if(image.parent===m_fightRes) active.push(image);
         // The native battle card is 94 units wide. Keep one mark readable
         // across its lower edge, with the V below the card's sign badge.
         var width:Number=Math.min(82,86/Math.max(1,active.length));
         for(var index:int=0;index<active.length;index++)
         {
            var icon:Image=active[index] as Image;
            icon.scaleX=icon.scaleY=width/icon.texture.width;
            icon.x=(index-(active.length-1)*.5)*width;
            icon.y=40;
         }
      }
      private function kaisaClearPlasma104() : void
      {
         for each(var image:Image in kaisaPlasmaIcons104) if(image.parent) image.removeFromParent(true);
         kaisaPlasmaIcons104={};
      }
      private function kaisaProjectile104(target:Avatar, shot:Number) : void
      {
         var layer:GameMapLayer=GameMapLayer.gl;
         if(GameMapLayer.isFastest || !layer || !m_fightRes || !target.m_fightRes) return;
         var texture:starling.textures.Texture=GlobalData.$assetManager.getTexture("MOD_KAISA_MISSILE104");
         if(!texture) return;
         var owner:Avatar=this;
         var battle:GameMap=GameMap.currentMap;
         layer.delayCall(function():void
         {
         if(GameMap.currentMap!==battle || !owner.m_fightRes || !target.m_fightRes) return;
         var parent:Sprite=layer.effectLayer;
         var start:Point=parent.globalToLocal(owner.m_fightRes.localToGlobal(new Point(0,-24)));
         var finish:Point=parent.globalToLocal(target.m_fightRes.localToGlobal(new Point(0,-12)));
         var fan:Number=(shot%3-1)*115+(int(shot/3)%2 ? 35 : -35);
         var control:Point=new Point((start.x+finish.x)*.5+fan,Math.min(start.y,finish.y)-90-Math.abs(fan)*.4);
         var sprite:Sprite=new Sprite();
         sprite.touchable=false;
         var trails:Array=[];
         for(var i:int=0;i<12;i++)
         {
            var trail:Quad=new Quad(1,3,0x33E5D5);
            trail.touchable=false;sprite.addChild(trail);trails.push(trail);
         }
         var missile:Image=new Image(texture);
         missile.pivotX=texture.width*.88;missile.pivotY=texture.height*.5;
         missile.scaleX=missile.scaleY=100/texture.width;missile.touchable=false;sprite.addChild(missile);
         var state:Object={progress:0};
         var time:Number=.35;
         var tween:Tween=new Tween(state,time,"linear");
         tween.animate("progress",1);
         tween.onUpdate=function():void
         {
            if(GameMap.currentMap!==battle) {sprite.removeFromParent(true);return;}
            var t:Number=state.progress;
            var inv:Number=1-t;
            missile.x=inv*inv*start.x+2*inv*t*control.x+t*t*finish.x;
            missile.y=inv*inv*start.y+2*inv*t*control.y+t*t*finish.y;
            missile.rotation=Math.atan2(2*inv*(control.y-start.y)+2*t*(finish.y-control.y),2*inv*(control.x-start.x)+2*t*(finish.x-control.x));
            for(var j:int=0;j<trails.length;j++)
            {
               var a:Number=Math.max(0,t-(j+1)*.014);
               var b:Number=Math.max(0,t-j*.014);
               var x0:Number=(1-a)*(1-a)*start.x+2*(1-a)*a*control.x+a*a*finish.x;
               var y0:Number=(1-a)*(1-a)*start.y+2*(1-a)*a*control.y+a*a*finish.y;
               var x1:Number=(1-b)*(1-b)*start.x+2*(1-b)*b*control.x+b*b*finish.x;
               var y1:Number=(1-b)*(1-b)*start.y+2*(1-b)*b*control.y+b*b*finish.y;
               var q:Quad=trails[j] as Quad;
               q.x=x0;q.y=y0;q.width=Math.max(.1,Point.distance(new Point(x0,y0),new Point(x1,y1)));
               q.height=Math.max(.3,3*(1-j/12));q.rotation=Math.atan2(y1-y0,x1-x0);q.alpha=.45*(1-j/12);
            }
         };
         tween.onComplete=function():void {sprite.removeFromParent(true);};
         parent.addChild(sprite);
         layer.addTween(tween);
         },GameMap.actionDelay);
      }


      // END DRAGONMANCER KAISA 104


      // BEGIN NIGHTBRINGER YASUO 104
      // Nightbringer's protection is not a removable generic buff.
      private var yasuoNightRounds104:int = -1;
      private var yasuoVampRounds104:int = -1;
      private var yasuoCritBonus104:int = 0;
      private var yasuoShieldSerial104:int = 0;
      private var yasuoCritBurst104:Boolean = false;

      private function yasuoIs104() : Boolean
      {
         var row:Object=GlobalData.$mConfig_avatar ? GlobalData.$mConfig_avatar[avatarData.id] : null;
         return row && row.nightbringerYasuo104===true;
      }
      private function yasuoPassive104() : Boolean
      {
         if(!yasuoIs104() || !skillB) return false;
         for each(var action:Array in skillB.skills)
            if(action[0]=="manual_ability" && action[1]=="night_yasuo_p") return true;
         return false;
      }
      private function yasuoStart104() : void
      {
         yasuoResetVisuals104();
         // Snapshot the attribute, not the probability calculated against toughness.
         yasuoCritBonus104=0;
         if(yasuoPassive104()) yasuoCritBonus104=getCrit();
      }
      private function yasuoNight104() : Boolean
      {
         return yasuoNightRounds104>=0;
      }
      private function yasuoCastSilenced104() : Boolean
      {
         return yasuoIs104() && hp>0 && !buffs.stun && skinBondNumber104("yasuo_c_silenced")>0;
      }
      private function yasuoImmune104(kind:String) : Boolean
      {
         return yasuoNight104() && ["stun","silence","curse","poison","burn"].indexOf(kind)>=0;
      }
      private function yasuoCleanse104() : void
      {
         for each(var kind:String in ["stun","silence","curse","poison","burn"]) removeBuff(kind);
         var keys:Array=[];
         for(var key:String in manualSkillDots)
            if(manualSkillDots[key] && ["poison","burn"].indexOf(manualSkillDots[key].kind)>=0) keys.push(key);
         for each(key in keys)
         {
            var visual:Buff=manualSkillDots[key].visual as Buff;
            if(visual && visual.displayObject && m_buff && visual.displayObject.parent==m_buff)
               m_buff.removeChild(visual.displayObject);
            delete manualSkillDots[key];
         }
      }
      private function yasuoLane104() : Array
      {
         return abilityCandidates(otherTeam,line,GameMapConfig.LINE_POS/2,GameMapConfig.LINE_POS,-1,false,"front");
      }
      private function yasuoCanCast104(kind:String) : Boolean
      {
         return yasuoIs104() && hp>0 && kind!="night_yasuo_p" && yasuoLane104().length>0;
      }
      private function yasuoExecute104(kind:String, sourceSkill:*) : Boolean
      {
         if(!sourceSkill || !yasuoCanCast104(kind)) return false;
         var targets:Array=yasuoLane104();
         var target:Avatar=targets[0];
         if(kind=="night_yasuo_c")
         {
            // Remove only the five named effects; unrelated debuffs remain.
            yasuoCleanse104();
            yasuoNightRounds104=2;
            yasuoVampRounds104=2;
            addBuff("bless",1,0,0,-1,this);
            abilityFeedback("融入黑夜","",0xFF6944);
            yasuoQueueNight104(true);
            var destination:int=target.pos+(team==1 ? 200 : -200);
            var landing:Number=GameMap.actionDelay+2;
            reline(line,Math.max(0,Math.min(GameMapConfig.LINE_POS,destination)));
            GameMap.actionDelay=Math.max(GameMap.actionDelay,landing);
            for(var strike:int=0;strike<3 && hp>0 && target.hp>0;strike++)
            {
               yasuoHit104(target,Number(sourceSkill.skills[0][4+strike])*skinBondNumber104("yasuo_c_damage",1),sourceSkill,strike==2 ? "night_finish" : "night_slash");
               GameMap.actionDelay+=strike==2 ? .22 : .12;
            }
            return true;
         }
         addPurifyCharges(1);
         if(!abilityState.root && !buffs.root) GameMap.actionDelay+=checkMove(true,400,null,-1,true);
         var coefficient:Number=Number(sourceSkill.skills[0][4]);
         var weakPercent:Number=Number(sourceSkill.skills[0][5]);
         var launch:int=pos;
         var castLane:int=line;
         var direction:int=team==1 ? -1 : 1;
         var speed:Number=2400;
         var points:Array=[{pos:launch,at:GameMap.actionDelay}];
         var previous:int=launch;
         var timeline:Number=GameMap.actionDelay;
         var knockEnd:Number=timeline;
         // One travelling wave, one hit per original target. Distances and front
         // designation are sampled before displacement so it cannot hit twice.
         var plan:Array=[];
         for(var index:int=0;index<targets.length;index++)
         {
            target=targets[index];
            if((target.pos-launch)*direction>=0) plan.push({unit:target,pos:target.pos,front:index==0});
         }
         var wave:Object=beginAbilityAttack(this,"active");
         wave.skill=sourceSkill;
         wave.manualDamageMultiplier=sourceSkill.getNativeSetting("manualDamageMultiplier",1);
         try
         {
         for each(var contact:Object in plan)
         {
            if(hp<=0) break;
            target=contact.unit;
            if(target.hp<=0 || target.line!=castLane || target.team!=otherTeam) continue;
            timeline+=Math.abs(int(contact.pos)-previous)/speed;
            GameMap.actionDelay=timeline;
            points.push({pos:int(contact.pos),at:timeline});
            var hit:Boolean=yasuoHit104(target,coefficient*(contact.front ? 1 : .6),sourceSkill,"night_contact",true);
            if(hit && contact.front && target.hp>0 && hp>0) abilityControl(target,"stun",1);
            if(hit && !contact.front && target.hp>0 && hp>0 && weakPercent>0 && weakPercent<1)
               abilityControl(target,"weak",1,weakPercent/(1-weakPercent));
            if(target.hp>0 && hp>0)
               knockEnd=Math.max(knockEnd,GameMap.actionDelay+target.checkMove(false,300,this,-1,true));
            // A revival/counter presentation may pause the battle clock. Record
            // the pause in the flight path rather than desynchronizing impacts.
            timeline=Math.max(timeline,GameMap.actionDelay);
            points.push({pos:int(contact.pos),at:timeline});
            previous=int(contact.pos);
         }
         var finish:int=team==1 ? 0 : GameMapConfig.LINE_POS;
         timeline+=Math.abs(finish-previous)/speed;
         points.push({pos:finish,at:timeline});
         yasuoWhirlwind104(castLane,offset,points);
         GameMap.actionDelay=Math.max(timeline,knockEnd);
         }
         finally {endAbilityAttack(wave);}
         return true;
      }
      private function yasuoHit104(target:Avatar, coefficient:Number, sourceSkill:*, effect:String, shared:Boolean = false) : Boolean
      {
         var rate:Number=Number(GlobalData.$mConfig_simple.hero_skill_output_rate_104);
         if(!isFinite(rate) || rate<=0) rate=1;
         var context:Object=shared ? null : beginAbilityAttack(this,"active");
         if(context)
         {
            context.skill=sourceSkill;
            context.manualDamageMultiplier=sourceSkill.getNativeSetting("manualDamageMultiplier",1);
         }
         var hit:Boolean=false;
         try
         {
            if(effect!="night_contact") yasuoEffect104(effect,target);
            hit=abilityHit(target,coefficient/rate,1,effect=="night_contact" ? "FX_NIGHT_YASUO_CONTACT104" : "FX_NIGHT_YASUO104");
         }
         finally {if(context) endAbilityAttack(context);}
         return hit;
      }
      private function yasuoEvent104(event:String, source:Avatar, target:Avatar, amount:Number) : void
      {
         if(source!==this || hp<=0 || !target || target.team==team) return;
         if(event=="hit" && yasuoVampRounds104>=0 && amount>0)
            // Use actual HP damage directly, bypassing AP/precision heal scaling.
            injured(Tools.toInt(amount),1,null,4,this,false,this,null,"",false,true);
         if(event!="crit" || !yasuoPassive104()) return;
         // Each entry is an ordinary shield Buff with its own native timer.
         // It never replaces or refreshes another entry, including allied shields.
         if(buffs.curse) return;
         if(buffs.evil) {removeBuff("evil",true);return;}
         var amountShield:int=Tools.toInt((getHpMax()*.05+getDamage()*.25)*getRecoveryTalentMultiplier()*precisionRecovery105(this));
         if(amountShield<=0) return;
         var shield:Buff=new Buff("shield",2,amountShield);
         shield.source=this;
         buffs["yasuoShield104_"+(++yasuoShieldSerial104)]=shield;
         queueVitalBar104();
         // Use one persistent guard indicator rather than overlapping N copies.
         abilityFeedback("黑夜剑心：护盾+"+amountShield,"",0xFFB064);
      }
      private function shieldValue104() : Number
      {
         var result:Number=0;
         for each(var shield:Buff in buffs) if(shield && shield.type=="shield") result+=Math.max(0,shield.value);
         return result;
      }
      private function removeIndependentShields104() : void
      {
         var keys:Array=[];
         for(var key:String in buffs)
            if(key.indexOf("yasuoShield104_")==0 || key=="sixReactionMfShield105") keys.push(key);
         for each(key in keys) removeBuff(key);
      }
      private function yasuoDamage104(amount:Number, source:Avatar, derived:Boolean = false) : Number
      {
         if(yasuoNight104()) amount=Tools.toInt(amount*.2);
         return amount;
      }
      private function yasuoCritical104(target:Avatar, settledDamage:Number) : void
      {
         if(!yasuoPassive104() || yasuoCritBurst104 || hp<=0 || !target || target.hp<=0 || target.team==team) return;
         var amount:int=Tools.toInt(settledDamage*skinBondNumber104("yasuo_crit_true",.35));
         if(amount<=0) return;
         yasuoCritBurst104=true;
         var context:Object=beginAbilityAttack(this,"passive");
         try
         {
            // The base already contains crit, armor, outgoing amplification and
            // the global final multiplier. Only the new true hit's target-side
            // mitigation and shields apply; neither crit nor global scaling repeats.
            target.injured(amount,1,null,3,this,false,this,null,"",true);
         }
         finally {endAbilityAttack(context);yasuoCritBurst104=false;}
      }
      private function yasuoEffect104(kind:String, target:Avatar) : void
      {
         fxPulse104(kind,target);
      }

      private var yasuoNightShown104:Boolean=false;
      private var yasuoNightVisual104:Sprite;
      private var yasuoNightParts104:Array=[];
      private var yasuoNightAge104:Number=0;

      private function yasuoResetVisuals104() : void
      {
         if(yasuoNightVisual104) yasuoNightVisual104.removeFromParent(true);
         yasuoNightVisual104=null;yasuoNightParts104=[];yasuoNightAge104=0;yasuoNightShown104=false;
      }
      private function yasuoQueueNight104(show:Boolean) : void
      {
         if(!GameMapLayer.gl || !GameMap.currentMap) return;
         GameMapLayer.gl.delayCall(yasuoShowNight104,GameMap.actionDelay,show,GameMap.currentMap);
      }
      private function yasuoShowNight104(show:Boolean, battle:GameMap) : void
      {
         if(GameMap.currentMap!==battle) return;
         if(!show) {yasuoResetVisuals104();return;}
         yasuoNightShown104=true;yasuoNightAge104=0;
      }
      private static function yasuoAdvanceEffects104(elapsed:Number) : void
      {
         if(!GameMap.currentMap) return;
         for each(var side:int in [1,2])
            for each(var unit:Avatar in GameMap.currentMap.getAliveList(side))
               if(unit.yasuoNightShown104 || unit.yasuoNightVisual104) unit.yasuoUpdateNight104(elapsed);
      }
      private function yasuoUpdateNight104(elapsed:Number) : void
      {
         if(!yasuoNightShown104 || hp<=0 || GameMapLayer.isFastest || !m_buff)
         {
            if(yasuoNightVisual104) yasuoNightVisual104.removeFromParent(true);
            yasuoNightVisual104=null;yasuoNightParts104=[];
            return;
         }
         var row:Object=GlobalData.$mConfig_avatar[avatarData.id];
         var layout:Object=row ? row.nightBuffLayout104 : null;
         if(!layout || !layout.slots) return;
         var texture:starling.textures.Texture=GlobalData.$assetManager.getTexture("MOD_NIGHT_YASUO_BUFF104_0");
         if(!texture) return;
         if(!yasuoNightVisual104)
         {
            yasuoNightVisual104=new Sprite();yasuoNightVisual104.touchable=false;
            // Same m_buff layer, original e703 coordinates and authored scales.
            // Imported PNGs have the native rotated Symbol 39 canvas dimensions.
            m_buff.addChild(yasuoNightVisual104);
            for each(var slot:Object in layout.slots)
            {
               var particle:Image=new Image(texture);
               particle.touchable=false;particle.pivotX=texture.width*.5;particle.pivotY=texture.height*.5;
               yasuoNightVisual104.addChild(particle);yasuoNightParts104.push(particle);
            }
         }
         yasuoNightAge104+=Math.max(0,elapsed);
         for(var i:int=0;i<yasuoNightParts104.length;i++)
         {
            var config:Object=layout.slots[i];
            var frame:Number=(yasuoNightAge104%Number(config.cycle))/Number(config.cycle)*int(config.frames);
            var keys:Array=config.keys;
            var current:Object=keys[0];var next:Object=keys[0];
            for(var k:int=0;k<keys.length;k++)
               if(frame>=Number(keys[k].at)) {current=keys[k];next=keys[(k+1)%keys.length];}
            particle=yasuoNightParts104[i] as Image;
            particle.visible=current.visible===true;
            if(!particle.visible) continue;
            var stop:Number=Number(next.at)>Number(current.at) ? Number(next.at) : Number(config.frames);
            var t:Number=Math.max(0,Math.min(1,(frame-Number(current.at))/Math.max(.001,stop-Number(current.at))));
            if(next.visible!==true) t=0;
            var rise:Number=Number(current.y)+(Number(next.y)-Number(current.y))*t;
            var stretch:Number=Number(current.stretch)+(Number(next.stretch)-Number(current.stretch))*t;
            var alpha:Number=Number(current.alpha)+(Number(next.alpha)-Number(current.alpha))*t;
            texture=GlobalData.$assetManager.getTexture("MOD_NIGHT_YASUO_BUFF104_"+(int(frame/int(config.frames)*4)%4));
            if(texture) particle.texture=texture;
            particle.x=Number(config.x);particle.y=Number(config.y)+rise*Number(config.scaleY);
            particle.scaleX=Number(config.scaleX);particle.scaleY=Number(config.scaleY)*stretch;
            particle.alpha=Number(config.alpha)*alpha;
         }
      }
      private function yasuoWhirlwind104(castLane:int, castOffset:Number, points:Array) : void
      {
         var layer:GameMapLayer=GameMapLayer.gl;
         if(GameMapLayer.isFastest || !layer || !points || points.length<2) return;
         var battle:GameMap=GameMap.currentMap;
         layer.delayCall(function():void
         {
            if(GameMap.currentMap!==battle) return;
            var texture:starling.textures.Texture=GlobalData.$assetManager.getTexture("MOD_NIGHT_YASUO_VORTEX104_0");
            if(!texture) return;
            var image:Image=new Image(texture);image.touchable=false;
            image.pivotX=texture.width*.5;image.pivotY=texture.height*.5;
            // Same 96-unit effect footprint as the project's native VFX atlas.
            image.scaleX=image.scaleY=96/texture.width;
            var parent:Sprite=layer.effectLayer;parent.addChild(image);
            var start:Number=Number(points[0].at);
            var duration:Number=Math.max(.01,Number(points[points.length-1].at)-start);
            var state:Object={elapsed:0,cancelled:false};
            var animation:Tween=new Tween(state,duration,"linear");
            animation.animate("elapsed",duration);
            animation.onUpdate=function():void
            {
               if(state.cancelled) return;
               if(GameMap.currentMap!==battle)
               {state.cancelled=true;image.removeFromParent(true);return;}
               var clock:Number=start+Number(state.elapsed);
               var index:int=0;
               while(index<points.length-2 && clock>=Number(points[index+1].at)) ++index;
               var a:Object=points[index];var b:Object=points[index+1];
               var t:Number=Math.max(0,Math.min(1,(clock-Number(a.at))/Math.max(.001,Number(b.at)-Number(a.at))));
               var position:Number=Number(a.pos)+(Number(b.pos)-Number(a.pos))*t;
               var origin:Point=parent.globalToLocal(layer.getLineSpr(castLane).localToGlobal(
                  new Point(GameMapConfig.offsetToPixel(castOffset),GameMapConfig.posToPixel(position))));
               image.x=origin.x;image.y=origin.y;
               texture=GlobalData.$assetManager.getTexture("MOD_NIGHT_YASUO_VORTEX104_"+(int(Number(state.elapsed)*12)%4));
               if(texture) image.texture=texture;
            };
            animation.onComplete=function():void {if(!state.cancelled) image.removeFromParent(true);};
            animation.onUpdate();layer.addTween(animation);
         },Number(points[0].at));
      }

      // END NIGHTBRINGER YASUO 104

      public function abilityCanCast(kind:String, distance:int, sourceSkill:* = null) : Boolean
      {
         if(hp <= 0 || !GameMap.currentMap) return false;
         if(kind.indexOf("six_")==0) return sixStarCanCast105(kind,distance);
         if(kind.indexOf("night_yasuo_")==0) return yasuoCanCast104(kind);
         if(kind.indexOf("dragon_kaisa_")==0) return kaisaCanCast104(kind);
         if(kind.indexOf("skin2_")==0) return skin2CanCast(kind,sourceSkill);
         var center:Avatar;
         switch(kind)
         {
            case "nurse_n":
            case "nurse_c": return true;
            case "cat_c": return GameMap.currentMap.getAliveList(otherTeam).length > 0;
            case "polar_c": return GameMap.currentMap.getAliveList(otherTeam).length > 0;
            case "santa_c": return GameMap.currentMap.getAliveList(otherTeam).length > 0;
            case "kayle_c": return abilityAlly(nativeAbilityNumber(sourceSkill,kind,"can_0",600)) != null;
            case "yi_c":
            case "orianna_n":
            case "alistar_c":
            case "tahm_c": return true;
            case "nunu_c": return abilityEnemies(skillAreaRadius(nativeAbilityNumber(sourceSkill,kind,"can_0",400))).length > 0;
            case "illaoi_c": return abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"can_0",350),null,nativeAbilityNumber(sourceSkill,kind,"can_1",3)).length > 0;
            case "orianna_c":
               center = abilityState.ball as Avatar;
               if(!center || center.hp <= 0 || center.line != line) center = this;
               return abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"can_1",350),center,nativeAbilityNumber(sourceSkill,kind,"can_2",3)).length > 0;
            case "jayce_n": distance = abilityState.form && abilityState.form.hammer ? nativeAbilityNumber(sourceSkill,kind,"can_0",1500) : GameMapConfig.LINE_POS; break;
            case "elise_c":
            case "nidalee_c":
            case "caitlyn_c":
            case "khazix_c":
            case "jinx_c": return abilityEnemies(distance,null,nativeAbilityNumber(sourceSkill,kind,"can_0",1),true).length > 0;
            case "maokai_c":
            case "riven_c": return abilityEnemies(distance,null,nativeAbilityNumber(sourceSkill,kind,"can_0",1),false,"nearest",null,true).length > 0;
            case "aoxing_c":
               for(var lane:int = 0; lane < 3; lane++)
                  if(abilityCandidates(otherTeam,lane,pos,nativeAbilityNumber(sourceSkill,kind,"can_2",3001),nativeAbilityNumber(sourceSkill,kind,"can_3",1)).length > 0) return true;
               return false;
         }
         return abilityEnemies(distance).length > 0;
      }

      // BEGIN SKIN REVISION V2
      private function skin2Initialize() : void
      {
         if(s2Family()==1203) {skin2.initialHp=hpMax;skin2.initialAttack=ap;}
      }
      // Approved skin revision: state is owned by each combat incarnation.
      private var skin2:Object = {};
      private static var skin2Depth:int = 0;
      private static var skin2AnnieChainDepth:int = 0;
      private static var skin2AnnieChain:Array = [];

      private function s2AnnieCore() : Object
      {
         if(s2Family()!=1221 || !skillB || !skillB.skillSetData) return null;
         var row:Object=GlobalData.$mConfig_skill[skillB.skillSetData.id];
         return row ? row.annie_core_105 : null;
      }
      private function s2AnnieImmune() : Boolean
      {
         return skin2.anniePurifyUntil!=null && manualOwnerActionSerial<int(skin2.anniePurifyUntil);
      }
      private function s2AnnieCompanion(key:String) : Number
      {
         if(!skill0 || !skill0.skillSetData) return 0;
         var row:Object=GlobalData.$mConfig_skill[skill0.skillSetData.id];
         var spec:Object=row ? row.annie_companion_105 : null;
         if(!spec || !spec.keys || !spec.values) return 0;
         var index:int=spec.keys.indexOf(key);
         return index<0 ? 0 : Number(spec.values[index]);
      }
      private function s2AnnieStatus(kind:String) : void
      {
         var spec:Object=s2AnnieCore();
         if(!spec || hp<=0 || !GameMap.currentMap) return;
         if(Buff.LIST_DEBUFF.indexOf(kind)<0 && ["cold","wanted","charmed","exposed","airborne","contract","windmark","bleed","mark","bomb"].indexOf(kind)<0) return;
         if(skin2.annieCoreNext!=null && manualOwnerActionSerial<int(skin2.annieCoreNext)) return;
         if(skin2AnnieChainDepth==0) skin2AnnieChain=[];
         if(skin2AnnieChain.indexOf(this)>=0) return;
         skin2AnnieChain.push(this);++skin2AnnieChainDepth;
         // Same owner-turn convention as SkillSet: cooldown 1 has one waiting
         // turn, then becomes ready on the following turn. Original passive
         // events do not read or spend this independent cooldown.
         skin2.annieCoreNext=manualOwnerActionSerial+int(spec.cooldown)+1;
         var context:Object=beginAbilityAttack(this,"passive");
         try
         {
            var unit:Avatar;
            for each(unit in GameMap.currentMap.getAliveList(team))
            {
               unit.removeAllDebuff();
               unit.skin2.anniePurifyUntil=Math.max(Number(unit.skin2.anniePurifyUntil || 0),unit.manualOwnerActionSerial+int(spec.purify_rounds));
            }
            abilityFeedback("不讲道理","FX_S9150_PURIFY",10526975);
            for each(unit in GameMap.currentMap.getAliveList(otherTeam))
            {
               unit.addBuff("sunder",int(spec.debuff_rounds),Number(spec.sunder)/(1-Number(spec.sunder)),0,-1,this);
               unit.addBuff("weak",int(spec.debuff_rounds),Number(spec.weak)/(1-Number(spec.weak)),0,-1,this);
               unit.addManualSkillDot("annie_core_105_"+abilityIndex,"poison",Tools.toInt(getDamage()*Number(spec.poison_ap)),0,int(spec.debuff_rounds),this,6,true);
               if(spec.stun_enabled) unit.addBuff("stun",int(spec.control_rounds),0,0,-1,this);
               unit.addBuff("silence",int(spec.control_rounds),0,0,-1,this);
            }
         }
         finally
         {
            endAbilityAttack(context);--skin2AnnieChainDepth;
            if(skin2AnnieChainDepth==0) skin2AnnieChain=[];
         }
      }

      private function s2Family() : int
      {
         var row:Object = GlobalData.$mConfig_avatar[avatarData.id];
         return row ? int(row.skin_revision_v2_104 || 0) : 0;
      }
      private function s2Value(skill:*, key:String) : Number
      {
         if(!skill || !skill.skillSetData) return 0;
         var row:Object = GlobalData.$mConfig_skill[skill.skillSetData.id];
         if(!row || !row.skin_v2_keys) return 0;
         var index:int = row.skin_v2_keys.indexOf(key);
         return index < 0 ? 0 : Number(skill.skills[0][4+index]);
      }
      private function s2Lane(friendly:Boolean = false, order:String = "front") : Array
      {
         return abilityCandidates(friendly ? team : otherTeam,line,pos,GameMapConfig.LINE_POS,-1,false,order);
      }
      private function s2Pick(order:String = "front", friendly:Boolean = false, excludeSelf:Boolean = false) : Avatar
      {
         var list:Array = s2Lane(friendly,order == "attack" ? "front" : order);
         if(order == "attack") list.sort(function(a:Avatar,b:Avatar):Number {return b.getDamage()-a.getDamage() || a.abilityIndex-b.abilityIndex;});
         if(!friendly) for each(var focused:Avatar in list) if(s2LiveMark(focused,"charmed") && focused.skin2.charmed.owner.team==team) return focused;
         for each(var unit:Avatar in list) if(!excludeSelf || unit !== this) return unit;
         return null;
      }

      private function sixBatchVayneTarget105(targets:Array) : Avatar
      {
         var key:String="rings_"+abilityIndex;
         var rear:Array=targets.concat().reverse();
         for each(var unit:Avatar in rear)
            if(unit.skin2[key] && int(unit.skin2[key].count)>0) return unit;
         return rear.length ? rear[0] : null;
      }
      public function skin2Focus(list:Vector.<Avatar>) : Vector.<Avatar>
      {
         if(!list || list.length<2) return list;
         for each(var target:Avatar in list) if(target.team!=team && s2LiveMark(target,"charmed") && target.skin2.charmed.owner.team==team)
         {
            var result:Vector.<Avatar> =list.concat();var index:int=result.indexOf(target);result.splice(index,1);result.unshift(target);return result;
         }
         return list;
      }
      public function skin2PoisonTick(target:Avatar) : void
      {
         if(s2Family()!=1209 || hp<=0 || !skin2.eggs) return;
         for(var i:int=0;i<skin2.eggs.length;i++) if(skin2.eggs[i].ready<=manualOwnerActionSerial && skin2.eggs[i].line==target.line && Math.abs(skin2.eggs[i].pos-target.pos)<=300)
         {s2ExplodeEgg(i);break;}
      }
      private function s2LiveMark(target:Avatar, name:String) : Boolean
      {
         var mark:Object = target ? target.skin2[name] : null;
         return mark && mark.owner && mark.owner.hp > 0 && mark.owner.manualOwnerActionSerial <= mark.expires;
      }
      private function s2Mark(target:Avatar, name:String, duration:int) : void
      {
         if(target && target.s2AnnieImmune()) return;
         if(target && target.buffs.purify) {target.removeBuff("purify",true);return;}
         if(target && target.hp > 0)
         {
            {target.skin2[name] = {owner:this,skill:skin2.castSkill || skillB,expires:manualOwnerActionSerial+duration};fxPulse104(name,target);}
            target.s2AnnieStatus(name);
         }
      }
      private function s2ColdMoveFactor() : Number
      {
         if(!s2LiveMark(this,"cold")) return 1;
         var mark:Object=skin2.cold;
         return Math.max(0,1-mark.owner.s2Value(mark.skill,"slow"));
      }
      private function skin2ClearDebuffs() : void
      {
         for each(var key:String in ["cold","wanted","charmed","exposed","airborne","contract","windmark"]) delete skin2[key];
      }
      private function s2Heal(target:Avatar, coefficient:Number) : void
      {
         if(target && target.hp > 0 && hp > 0) target.injured(Tools.toInt(getDamage()*coefficient),1,null,4,this,false,this);
      }
      private function s2Shield(target:Avatar, coefficient:Number, duration:int = 2) : void
      {
         if(target && target.hp > 0 && hp > 0) target.addBuff("shield",duration,Tools.toInt(getDamage()*coefficient),0,-1,this);
      }
      private function s2Hit(target:Avatar, coefficient:Number, kind:int = 2, rings:Boolean = false) : Boolean
      {
         if(!target || hp <= 0 || target.hp <= 0) return false;
         fxStrike104(target);
         var previous:Object = skin2.ringHit; skin2.ringHit = rings;
         var context:Object = currentAbilityAttack();
         var created:Object = context && context.owner === this ? null : beginAbilityAttack(this,"passive");
         try { return abilityHit(target,coefficient/Math.max(0.000001,heroSkillOutputRate104()),kind,""); }
         finally {skin2.ringHit = previous; if(created) endAbilityAttack(created);}
      }
      private function s2Dispel(target:Avatar, all:Boolean = false) : int
      {
         if(!target || target.hp <= 0) return 0;
         var count:int = 0; var stolen:Number = 0; var keys:Array=[];
         for(var key:String in target.buffs) if(Buff.LIST_BUFF.indexOf(key)>=0) keys.push(key);
         if(target.shieldValue104()>0 && keys.indexOf("shield")<0) keys.push("shield");
         keys.sort();
         for each(key in keys)
         {
            if(key == "shield") stolen = target.shieldValue104();
            target.removeBuff(key); ++count; if(!all) break;
         }
         if(count)fxPulse104("cleanse",target);
         if(count && s2Family()==1214)
         {
            var ally:Avatar=s2Pick("ratio",true);
            if(ally) ally.addBuff("shield",2,stolen>0 ? Math.min(stolen,s2Value(skillB,"stealCap")*getDamage()) : s2Value(skillB,"shield")*getDamage(),0,-1,this);
         }
         return count;
      }
      private function s2Pet() : Avatar
      {
         var units:Array=skin2.pets as Array;
         if(units) for each(var pet:Avatar in units) if(pet && pet.hp>0) return pet;
         return null;
      }
      private function s2BearStrike(skill:*) : void
      {
         for each(var target:Avatar in s2Lane()) s2Hit(target,s2Value(skill,"hit"));
         abilityControl(s2Pick(),"stun",1);
      }
      private function s2Egg(target:Avatar, mature:Boolean = false) : void
      {
         if(!target) return;
         if(!skin2.eggs) skin2.eggs=[];
         var eggs:Array=skin2.eggs;
         if(eggs.length>=6)
         {
            if(eggs[0].ready<=manualOwnerActionSerial) s2ExplodeEgg(0);
            else eggs.shift();
         }
         eggs.push({line:target.line,pos:target.pos,ready:manualOwnerActionSerial+(mature ? 0 : 1)});
         abilityFeedback(mature ? "彩蛋成熟" : "种下彩蛋");
      }
      private function s2ExplodeEgg(index:int) : void
      {
         var egg:Object=skin2.eggs.splice(index,1)[0];
         fxPulse104("egg_ready",null,egg.line,egg.pos);
         var targets:Array=abilityCandidates(otherTeam,egg.line,egg.pos,3001,2);
         for each(var target:Avatar in targets) s2Hit(target,s2Value(skillB,"hit"));
         s2Shield(s2Pick("ratio",true),s2Value(skillB,"shield"));
      }
      public function skin2CanCast(kind:String, sourceSkill:* = null) : Boolean
      {
         var parts:Array=kind.split("_"); var family:int=int(parts[1]);var slot:int=int(parts[2]);
         if(slot==2 || hp<=0 || skin2.eggUntil) return false;
         if(family==1219 && slot==1)
         {
            var row:Object=sourceSkill ? GlobalData.$mConfig_skill[sourceSkill.skillSetData.id] : null;
            if(row && row.skin_v2_bond_size>=4)
            {
               for each(var marked:Avatar in s2Lane()) if(s2LiveMark(marked,"windmark") || s2LiveMark(marked,"airborne")) return true;
               return false;
            }
            for each(var target:Avatar in abilityAllEnemies()) if(s2LiveMark(target,"airborne") && target.getType()==1 && !target.isManualSummonUnit) return true;
            return false;
         }
         if(family==1228 && slot==0) return s2Lane(true).length>0;
         return s2Lane().length>0;
      }
      private function executeSkin2(kind:String, skill:*) : Boolean
      {
         var family:int=int(kind.split("_")[1]);var slot:int=int(kind.split("_")[2]);
         if(slot==2) return false;
         var target:Avatar=s2Pick(); var ally:Avatar;var unit:Avatar;var targets:Array=s2Lane();var allies:Array=s2Lane(true,"ratio");
         var value:Number;var before:Number;var i:int;var stage:int;var count:int;var row:Object;
         row=GlobalData.$mConfig_skill[skill.skillSetData.id];
         if(!target && !(family==1228 && slot==0) && !(family==1219 && slot==1 && !(row.skin_v2_bond_size>=4))) return false;
         var previous:Object=skin2.castSkill;skin2.castSkill=skill;
         try
         {
         if(family==1219 && row.skin_v2_bond_size>=4)
         {
            if(slot==0)
            {
               for each(unit in targets) {var marked:Boolean=s2LiveMark(unit,"windmark");s2Hit(unit,s2Value(skill,"hit"),1);if(marked) {abilityControl(unit,"stun",1);if(unit.buffs.stun)s2Mark(unit,"airborne",1);}s2Mark(unit,"windmark",2);}
               s2Shield(this,s2Value(skillB,"shield"));
            }
            else for(i=0;i<3;i++) {for each(unit in targets) if(s2LiveMark(unit,"windmark") || s2LiveMark(unit,"airborne"))s2Hit(unit,s2Value(skill,"hit"),1);s2Heal(this,s2Value(skill,"bondHeal"));}
            return true;
         }
         if(slot==0)
         {
            switch(family)
            {
               case 1201:
                  if(s2Hit(target,s2Value(skill,"hit"),1)) abilityControl(target,"silence",1);
                  s2Shield(this,s2Value(skill,"shield"));break;
               case 1203:
                  var cursed:Boolean=target.buffs.curse && s2LiveMark(target,"contract") && target.skin2.contract.owner===this;
                  abilityControl(target,"curse",2);if(target.buffs.curse) s2Mark(target,"contract",2);
                  s2Hit(target,s2Value(skill,"hit"));if(cursed) s2Heal(this,s2Value(skill,"heal"));break;
               case 1204:
                  target=s2Pick("farthest");abilityPull(target,this,GameMapConfig.LINE_POS);
                  if(s2Hit(target,s2Value(skill,"hit"),1)) {abilityControl(target,"stun",1);s2Mark(target,"exposed",2);}break;
               case 1206:
                  if(skill.getNativeSetting("sixStarBatchRear105")) target=sixBatchVayneTarget105(targets);
                  else for each(unit in targets) if(unit.skin2["rings_"+abilityIndex]) {target=unit;break;}
                  for(i=0;i<2;i++) s2Hit(target,s2Value(skill,"hit"),1,true);break;
               case 1207:
                  for each(unit in targets.slice(0,2)) s2Hit(unit,s2Value(skill,"hit"));
                  for each(unit in allies.slice(0,2)) s2Heal(unit,s2Value(skill,"heal"));break;
               case 1209:
                  s2Hit(target,s2Value(skill,"hit"));
                  if(target.hp>0) {target.addBuff("poison",2,getDamage()*s2Value(skill,"poison"),0,-1,this);s2Egg(target);}break;
               case 1210:
                  stage=int(skin2.dance || 0);skin2.dance=(stage+1)%3;
                  if(stage==0) {abilityDash(target);s2Shield(this,s2Value(skillB,"shield"));}
                  before=Number(currentAbilityAttack().damage);
                  for(i=0;i<(stage==2 ? 3 : 2);i++)
                     for each(unit in (stage==2 && skin2.awake ? targets : [target])) s2Hit(unit,s2Value(skill,stage==2 ? "third" : "hit"),1);
                  if(stage==1) s2Heal(this,Math.max(0,Number(currentAbilityAttack().damage)-before)*s2Value(skillB,"leech")/Math.max(1,getDamage()));
                  if(stage==2) {abilityControl(target,"stun",1);if(!skin2.awake) s2Retreat();}break;
               case 1211:
                  target=s2Pick("attack");s2Hit(target,s2Value(skill,"hit"),1);s2Mark(target,"wanted",1);
                  skin2.trap=true;break;
               case 1213:
                  s2Shield(this,s2Value(skill,"shield"),1);s2Hit(target,s2Value(skill,"hit"));
                  if(!skin2.ball || skin2.ball.hp<=0 || skin2.ball.line!=line) {ally=s2Pick("attack",true,true);skin2.ball=ally || this;fxTransfer104("ball",skin2.ball);skin2.ballTurn=manualOwnerActionSerial;}
                  else if(skin2.ball===this && manualOwnerActionSerial>int(skin2.ballTurn)) s2ReturnBall(target,true);
                  break;
               case 1214:
                  count=-1;
                  for each(unit in targets) {var good:int=0;for(var key:String in unit.buffs) if(Buff.LIST_BUFF.indexOf(key)>=0) ++good;if(good>count) {target=unit;count=good;}}
                  s2Hit(target,s2Value(skill,"hit"));s2Dispel(target);break;
               case 1215:
                  target=skin2.sonic as Avatar;
                  if(target && target.hp>0 && target.line==line)
                  {
                     abilityDash(target);s2Hit(target,s2Value(skill,"second")*(1+s2Value(skill,"executeBonus")*(1-target.hp/target.hpMax)),1);skin2.sonic=null;
                     ally=skin2.ward as Avatar;if(ally && ally.hp>0 && ally.line==line) reline(line,Math.max(0,Math.min(GameMapConfig.LINE_POS,ally.pos+(team==1 ? -125 : 125))));
                     s2Shield(this,s2Value(skillB,"shield"));
                  }
                  else
                  {
                     skin2.sonic=null;skin2.ward=null;target=s2Pick();
                     if(s2Hit(target,s2Value(skill,"first"),1))
                     {skin2.sonic=target;ally=s2Pick("ratio",true,true) || this;skin2.ward=ally;s2Shield(ally,s2Value(skillB,"shield"));}
                  }break;
               case 1216:
                  for each(unit in targets.slice(0,2)) {s2Hit(unit,s2Value(skill,s2LiveMark(unit,"cold") ? "cold" : "hit"));s2Mark(unit,"cold",2);}break;
               case 1218:
                  before=Number(currentAbilityAttack().damage);
                  for each(unit in targets.slice(0,2)) s2Hit(unit,s2Value(skill,"hit"));
                  s2Heal(this,Math.max(0,Number(currentAbilityAttack().damage)-before)*s2Value(skill,"leech")/Math.max(1,getDamage()));
                  if(skin2.crows) skill.abilityCooldownOverride=0;break;
               case 1219:
                  if(int(skin2.wind || 0)>=2)
                  {
                     skin2.wind=0;
                     for each(unit in targets) if(s2Hit(unit,s2Value(skill,"wind"),1)) {abilityControl(unit,"stun",1);if(unit.buffs.stun)s2Mark(unit,"airborne",1);}
                     s2Shield(this,s2Value(skillB,"shield"));skin2.windGuard=true;
                  }
                  else {s2Hit(target,s2Value(skill,"hit"),1);skin2.wind=int(skin2.wind || 0)+1;}break;
               case 1221:
                  s2Hit(target,s2Value(skill,"hit"));if(targets.length>1) s2Hit(targets[1],s2Value(skill,"splash"));
                  unit=s2Pet();if(unit) {unit.skin2.command=true;unit.manualFocusTarget=target;}break;
               case 1228:
                  if(allies.length && allies[0].hp/allies[0].hpMax<.6)
                  {
                     for each(unit in allies.slice(0,2)) {s2Heal(unit,s2Value(skill,"heal"));for(key in unit.buffs) if(Buff.LIST_DEBUFF.indexOf(key)>=0) {unit.removeBuff(key);break;}}
                  }
                  else for each(unit in allies) s2Shield(unit,s2Value(skill,"shield"));break;
               case 1140:
                  if(skin2.phase) {skin2.phase=false;s2Hit(target,Number(skin2.phaseValue),2,true);if(target && target.hp<=0)target=s2Pick();}
                  s2Hit(target,s2Value(skill,"hit"),2,true);if(target && target.hp<=0) target=s2Pick();s2Hit(target,s2Value(skill,"hit"),2,true);break;
            }
         }
         else
         {
            switch(family)
            {
               case 1201:
                  target=s2Pick("ratio");s2Hit(target,s2Value(skill,"hit")*(1+s2Value(skill,"executeBonus")*(1-target.hp/target.hpMax)),3);
                  if(target.hp<=0 && target.getType()==1 && !target.isManualSummonUnit) for each(unit in allies) unit.addBuff("purify",1);break;
               case 1203:
                  for each(unit in targets) {s2Hit(unit,s2Value(skill,"hit"));abilityControl(unit,"curse",2);if(unit.buffs.curse)s2Mark(unit,"contract",2);}
                  addBuff("shield",2,hpMax*s2Value(skill,"hpShield"),0,-1,this);break;
               case 1204:
                  for each(unit in allies) {unit.addBuff("purify",1);s2Shield(unit,s2Value(skill,"shield"));}
                  for each(unit in targets) {s2Hit(unit,s2Value(skill,"hit"));if(s2LiveMark(unit,"exposed") && unit.skin2.exposed.owner===this) abilityControl(unit,"silence",1);}break;
               case 1206:
                  removeAllDebuff();addBuff("strong",2,s2Value(skill,"attackBuff"));addBuff("fleeup",2,s2Value(skill,"dodgeBuff"));target=s2Pick("ratio");
                  if(skill.getNativeSetting("sixStarBatchRear105"))
                  {
                     addBuff("bless",-1);
                     target=sixBatchVayneTarget105(targets);
                     for(i=0;i<2;i++) s2Hit(target,s2Value(skill,"hit"),1,true);
                     if(s2Hit(target,s2Value(skill,"hit"),1,true) && target.hp>0 && !target.abilityState.channel)
                     {
                        target.checkMove(false,800,this,-1,true);
                        if(target.pos==(target.team==1 ? GameMapConfig.LINE_POS : 0))
                        {
                           sixStarHit105(target,trueSkillCoefficient104(6),3,"FX60_MAGIC");
                           abilityControl(target,"curse",1);
                           abilityControl(target,"stun",1);
                        }
                     }
                     break;
                  }
                  var ringKey:String="rings_"+abilityIndex;
                  count=target.skin2[ringKey] ? int(target.skin2[ringKey].count) : 0;
                  for each(unit in targets)
                  {
                     var rings:int=unit.skin2[ringKey] ? int(unit.skin2[ringKey].count) : 0;
                     if(rings>count) {target=unit;count=rings;}
                  }
                  for(i=0;i<3;i++) s2Hit(target,s2Value(skill,"hit"),1,true);break;
               case 1207:
                  target=s2Pick("attack");abilityControl(target,"stun",1);if(target.buffs.stun)s2Mark(target,"charmed",1);
                  s2Hit(target,s2Value(skill,"hit"));break;
               case 1209:
                  if(!skin2.eggs) skin2.eggs=[];
                  for each(unit in targets.slice(0,3))
                  {
                     var found:Boolean=false;
                     for each(var egg:Object in skin2.eggs) if(egg.line==unit.line && Math.abs(egg.pos-unit.pos)<125) {egg.ready=manualOwnerActionSerial;found=true;break;}
                     if(!found) s2Egg(unit);
                  }
                  for(i=skin2.eggs.length-1;i>=0;i--) if(skin2.eggs[i].line==line && skin2.eggs[i].ready<=manualOwnerActionSerial) s2ExplodeEgg(i);break;
               case 1210:
                  addBuff("strong",2,s2Value(skill,"attackBuff"));skin2.awake={end:manualOwnerActionSerial+2,skill:skill};
                  for each(unit in targets) s2Hit(unit,s2Value(skill,"entry"),1);break;
               case 1211:
                  target=null;
                  for each(unit in abilityAllEnemies()) if(s2LiveMark(unit,"wanted") && unit.skin2.wanted.owner===this && (!target || unit.hp/unit.hpMax<target.hp/target.hpMax)) target=unit;
                  target=target || s2Pick("ratio");s2Hit(target,s2Value(skill,"hit"),1);
                  if(target.hp<=0 && target.getType()==1 && !target.isManualSummonUnit) skill.abilityCooldownOverride=Math.max(0,skill.skillSetData.cooldown-1);break;
               case 1213:
                  for each(unit in targets) s2Hit(unit,s2Value(skill,"hit"));
                  if(int(skin2.shotUntil || -1)>=manualOwnerActionSerial) {skin2.shotUntil=-1;s2Hit(s2Pick("ratio"),s2Value(skill,"shot"));}
                  for each(unit in allies) unit.addBuff("strong",2,s2Value(skill,"attackBuff"));break;
               case 1214:
                  for each(unit in targets) {s2Hit(unit,s2Value(skill,"hit"));count=s2Dispel(unit,true);abilityControl(unit,"curse",2);if(count)s2Hit(unit,s2Value(skill,"bonus"),3);}break;
               case 1215:
                  target=skin2.sonic && skin2.sonic.hp>0 ? skin2.sonic : s2Pick();
                  var collisions:Array=abilityCandidates(otherTeam,target.line,target.pos,500,2,false,"nearest",[target]);
                  s2Hit(target,s2Value(skill,"hit"),1);if(target.hp>0) target.checkMove(false,350,this,-1,true);
                  for each(unit in collisions) {s2Hit(unit,s2Value(skill,"collision"),1);abilityControl(unit,"stun",1);}break;
               case 1216:
                  skin2.frost={next:manualOwnerActionSerial+1,skill:skill,lane:line,end:manualOwnerActionSerial+2};
                  for each(unit in targets) {s2Hit(unit,s2Value(skill,"hit"));s2Mark(unit,"cold",2);}break;
               case 1218:
                  skin2.crows={left:2,skill:skill,start:manualOwnerActionSerial};skin2.crowGuard=false;
                  for each(unit in targets) {abilityControl(unit,"stun",1);s2Hit(unit,skin2.lastHurt==manualOwnerActionSerial-1 ? s2Value(skill,"hit") : s2Value(skillB,"entry"));}break;
               case 1219:
                  target=null;for each(unit in abilityAllEnemies()) if(s2LiveMark(unit,"airborne") && unit.getType()==1 && !unit.isManualSummonUnit) {target=unit;break;}
                  if(!target) return false;
                  reline(target.line,Math.max(0,Math.min(GameMapConfig.LINE_POS,target.pos+(team==1 ? 125 : -125))));
                  for each(unit in s2Lane()) if(s2LiveMark(unit,"airborne")) for(i=0;i<3;i++) s2Hit(unit,s2Value(skill,"hit"),1);
                  skin2.windReturn=true;skin2.penetrationEnd=manualOwnerActionSerial+2;break;
               case 1221:
                  unit=s2Pet();
                  if(unit) s2Heal(unit,unit.hpMax*s2Value(skill,"petHeal")/Math.max(1,getDamage()));
                  else
                  {
                     abilitySummon(String(row.skin_v2_summon_id),1,s2Value(skill,"petPanel"),9999,"skin2bear");skin2.pets=abilityState.summons_skin2bear;
                     unit=s2Pet();if(unit) {unit.skin2.bearOwner=this;unit.skin2.initialHp=unit.hpMax;unit.skin2.initialAttack=unit.getDamage();}
                  }
                  s2BearStrike(skill);break;
               case 1228:
                  for each(unit in targets) {abilityControl(unit,"stun",1);s2Hit(unit,s2Value(skill,"hit"));}
                  for each(unit in allies) {unit.addBuff("purify",2);unit.addBuff("strong",2,s2Value(skill,"attackBuff"));}break;
               case 1227:
                  for each(unit in targets) s2Hit(unit,s2Value(skill,"hit"));
                  for each(unit in allies) s2Heal(unit,s2Value(skill,"heal"));
                  var snake:Avatar=null;
                  for each(unit in GameMap.currentMap.getAliveList(team)) if(unit.statisticsOwner104===this && unit.isManualSummonUnit) {snake=unit;break;}
                  if(snake) {for each(unit in targets) if(unit.buffs.curse) s2Hit(unit,s2Value(skill,"snake"));for each(unit in allies)s2Shield(unit,s2Value(skill,"shield"));s2Heal(snake,snake.hpMax*s2Value(skill,"petHeal")/Math.max(1,getDamage()));}break;
               case 1140:
                  var ghost:Object=skin2.previous || skin2.record;
                  if(ghost)
                  {
                     fxPulse104("time",null,line,pos);removeAllDebuff();
                     // A recorded lane may finish after a transfer; keep the current
                     // fight position then, while preserving the recorded-loss heal.
                     if(ghost.line>=0 && !GameMap.currentMap.isEnd(ghost.line)) {fxPulse104("time",null,ghost.line,ghost.pos);reline(ghost.line,ghost.pos);}
                     var loss:Number=Math.max(0,Number(skin2.lost || 0)-Number(ghost.lost || 0));
                     s2Heal(this,Math.min(hpMax*s2Value(skill,"rewindCap"),loss*s2Value(skill,"rewind"))/Math.max(1,getDamage()));
                  }
                  for each(unit in s2Lane().slice(0,2)) s2Hit(unit,s2Value(skill,"hit"),2,true);
                  skin2.phase=true;skin2.phaseValue=s2Value(skill,"phase");break;
            }
         }
         row=GlobalData.$mConfig_skill[skill.skillSetData.id];
         if(row.skin_v2_bond)
         {
            if(slot==0)
            {
               if(family==1206) s2Hit(target,s2Value(skill,"hit"),1,true);
               else if(family==1210 && stage==2) {addBuff("purify",1);s2Shield(this,s2Value(skill,"bondShield"));}
               else if(family==1211) s2Dispel(target);
               else if(family==1213 && skin2.ball) s2Shield(skin2.ball,s2Value(skill,"bondShield"));
               else if(family==1221 && s2Pet()) s2Pet().skin2.commandSplash=true;
               else if(family==1201) s2Shield(s2Pick("ratio",true,true),s2Value(skill,"bondShield"));
            }
         }
         return true;
         }
         finally {skin2.castSkill=previous;}
      }
      private function s2Retreat() : void
      {
         var ally:Avatar=s2Pick("front",true,true);
         reline(line,Math.max(0,Math.min(GameMapConfig.LINE_POS,(ally ? ally.pos : pos)+(team==1 ? 150 : -150))));
      }
      private function s2ReturnBall(target:Avatar, solo:Boolean = false) : void
      {
         if(skin2.ballReturn==manualOwnerActionSerial || !skin2.ball) return;
         var holder:Avatar=skin2.ball;holder.fxTransfer104("ball",this);fxPulse104("ball",holder);fxPulse104("shot",this);skin2.ball=null;skin2.ballReturn=manualOwnerActionSerial;
         s2Hit(target,s2Value(skillB,"hit")*(solo ? .5 : 1));s2Heal(holder,s2Value(skillB,"heal")*(solo ? .5 : 1));
         skin2.shotUntil=manualOwnerActionSerial+2;abilityFeedback("射门机会");
      }
      private function skin2Event(event:String, source:Avatar, target:Avatar, amount:Number, overheal:Number) : void
      {
         if(!GameMap.currentMap || skin2Depth>=8) return;
         var family:int=s2Family();var unit:Avatar;var state:Object;var i:int;var key:String;var count:int;
         if(event=="turn_start")
         {
            if(family==1140) {skin2.previous=skin2.record;skin2.record={line:line,pos:pos,lost:Number(skin2.lost || 0)};}
            if(family==1203 && int(skin2.growth || 0)<10)
            {
               for each(unit in s2Lane()) if(unit.getType()==1 && !unit.isManualSummonUnit && unit.buffs.curse && s2LiveMark(unit,"contract") && unit.skin2.contract.owner===this)
               {
                  fxPulse104("growth");skin2.growth=int(skin2.growth || 0)+1;ap+=Number(skin2.initialAttack)*s2Value(skillB,"attackGrowth");hpMax+=int(Number(skin2.initialHp)*s2Value(skillB,"hpGrowth"));hp+=int(Number(skin2.initialHp)*s2Value(skillB,"hpGrowth"));break;
               }
            }
            if(skin2.eggUntil && manualOwnerActionSerial>=int(skin2.eggUntil))
            {
               fxPulse104("rebirth");delete skin2.eggUntil;hp=Math.max(hp,int(hpMax*s2Value(skillB,"rebornHp")));
               for each(unit in s2Lane()) if(s2LiveMark(unit,"cold")) {s2Hit(unit,s2Value(skillB,"hit"));abilityControl(unit,"stun",1);}
            }
            if(skin2.frost && manualOwnerActionSerial==skin2.frost.next)
               for each(unit in abilityCandidates(otherTeam,skin2.frost.lane,pos,3001,-1)) {s2Hit(unit,s2Value(skin2.frost.skill,"hit"));s2Mark(unit,"cold",2);}
            if(skin2.crows && manualOwnerActionSerial>skin2.crows.start)
            {
               if(buffs.stun || buffs.silence) delete skin2.crows;
               else {for each(unit in s2Lane())s2Hit(unit,s2Value(skin2.crows.skill,"hit"));if(--skin2.crows.left<=0) delete skin2.crows;}
            }
            for each(unit in GameMap.currentMap.getAliveList(otherTeam)) if(unit.s2Family()==1211 && unit.skin2.trap && unit.line==line && Math.abs(unit.pos-pos)<=300 && getType()==1 && !isManualSummonUnit)
            {unit.skin2.trap=false;unit.abilityControl(this,"root",1);unit.s2Hit(this,unit.s2Value(unit.skillB,"hit"),1);}
         }
         if(event=="turn_end")
         {
            if(family==1201) {skin2.guarding=s2Pick("ratio",true,true);skin2.guardUsed=false;}
            if(skin2.windReturn) {skin2.windReturn=false;skin2.wind=2;}
            if(skin2.awake && manualOwnerActionSerial>=skin2.awake.end)
            {
               state=skin2.awake;delete skin2.awake;
               for each(unit in s2Lane())s2Hit(unit,s2Value(state.skill,"exit")*(1+s2Value(state.skill,"executeBonus")*(1-unit.hp/unit.hpMax)),1);
               s2Retreat();
            }
            if(skin2.bearOwner && skin2.bearOwner.hp>0 && int(skin2.bearGrowth || 0)<6)
            {fxPulse104("bear");skin2.bearGrowth=int(skin2.bearGrowth || 0)+1;ap+=Number(skin2.initialAttack)*skin2.bearOwner.s2AnnieCompanion("petGrowth");hpMax+=int(Number(skin2.initialHp)*skin2.bearOwner.s2AnnieCompanion("petGrowth"));hp+=int(Number(skin2.initialHp)*skin2.bearOwner.s2AnnieCompanion("petGrowth"));}
         }
         if(event=="damage_taken" && source && source.team!=team)
         {
            skin2.lost=Number(skin2.lost || 0)+Math.max(0,amount);
            if(source.getType()==1 && !source.isManualSummonUnit) skin2.lastHurt=manualOwnerActionSerial;
         }
         if(event=="hit" && target && skin2Depth==0)
         {
            ++skin2Depth;
            try
            {
               if((family==1206 || family==1140) && (skin2.ringHit || !skin2.castSkill && currentAbilityAttack() && currentAbilityAttack().kind=="basic"))
               {
                  key="rings_"+abilityIndex;state=target.skin2[key] || {count:0,round:-1,triggers:0};target.skin2[key]=state;
                  if(state.round!=manualOwnerActionSerial) {state.round=manualOwnerActionSerial;state.triggers=0;}
                  state.count=Math.min(3,int(state.count)+1);
                  if(state.count>=3 && state.triggers<2)
                  {fxPulse104(family==1206 ? "rings" : "time_rings",target);state.count=0;++state.triggers;s2Hit(target,s2Value(skillB,"hit"),family==1206 ? 3 : 2);if(family==1206)s2Heal(this,s2Value(skillB,"heal"));else s2Shield(this,s2Value(skillB,"shield"),1);}
               }
               if(skin2.command && skin2.bearOwner && skin2.bearOwner.hp>0)
               {skin2.command=false;unit=skin2.bearOwner;unit.s2Hit(target,unit.s2AnnieCompanion("command"));if(skin2.commandSplash) {skin2.commandSplash=false;for each(var other:Avatar in unit.s2Lane()) if(other!==target) {unit.s2Hit(other,unit.s2AnnieCompanion("command"));break;}}}
               var context:Object=currentAbilityAttack();
               if(context && context.kind=="active") for each(unit in GameMap.currentMap.getAliveList(team)) if(unit!==this && unit.s2Family()==1213 && unit.skin2.ball===this) unit.s2ReturnBall(target);
            }
            finally {--skin2Depth;}
         }
         if(event=="heal_done" && family==1207 && target && overheal>0 && skin2Depth==0)
         {target.addBuff("shield",2,overheal*s2Value(skillB,"overflow"),0,-1,this);}
         if(event=="death")
         {
            if(s2LiveMark(this,"exposed")) {unit=skin2.exposed.owner;delete skin2.exposed;unit.s2Heal(unit.s2Pick("ratio",true),unit.s2Value(unit.skillB,"heal"));}
            if(s2LiveMark(this,"charmed") && skin2Depth==0)
            {
               ++skin2Depth;unit=skin2.charmed.owner;delete skin2.charmed;
               try {for each(var friend:Avatar in unit.s2Lane(true))unit.s2Heal(friend,unit.s2Value(unit.skillB,"heal"));unit.s2Hit(unit.s2Pick("ratio"),unit.s2Value(unit.skillB,"hit"));}
               finally {--skin2Depth;}
            }
            for each(unit in GameMap.currentMap.getAliveList(otherTeam)) if(unit.s2Family()==1206 && skin2["rings_"+unit.abilityIndex])
            {var next:Avatar=unit.s2Pick("ratio");if(next) next.skin2["rings_"+unit.abilityIndex]=skin2["rings_"+unit.abilityIndex];}
         }
         if(event=="kill" && family==1218 && skin2.crows && !skin2.crowGuard && target && target.getType()==1 && !target.isManualSummonUnit)
         {skin2.crowGuard=true;s2Shield(this,s2Value(skillB,"shield"));}
      }
      private function skin2Incoming(amount:Number, source:Avatar, kind:int) : Number
      {
         if(!GameMap.currentMap) return amount;
         var context:Object=currentAbilityAttack();var active:Boolean=source && context && context.kind=="active" && context.owner===source;
         var unit:Avatar;var state:Object;var family:int=s2Family();
         if(kind==4)
         {
            for each(unit in GameMap.currentMap.getAliveList(team)) if(unit.s2Family()==1228 && unit.line==line && hp/hpMax<.6) {amount*=1+unit.s2Value(unit.skillB,"healAmp");break;}
            return amount;
         }
         if(skin2Depth>0) return amount;
         if(!source || source.team==team || kind<1 || kind>3) return amount;
         if(active)
         {
            if(s2LiveMark(this,"exposed")) {unit=skin2.exposed.owner;amount*=1+unit.s2Value(skin2.exposed.skill,"exposedAmp");}
            if(s2LiveMark(source,"exposed"))
            {unit=source.skin2.exposed.owner;delete source.skin2.exposed;unit.s2Shield(this,unit.s2Value(unit.skillB,"shield"),1);}
            if(family==1221 && s2Pet() && skin2.bearShieldTurn!=manualOwnerActionSerial)
            {skin2.bearShieldTurn=manualOwnerActionSerial;s2Shield(this,s2AnnieCompanion("shield"),1);}
            if(family==1219 && skin2.windGuard && buffs.shield && source.range>300)
            {skin2.windGuard=false;removeBuff("shield");return 0;}
            for each(unit in GameMap.currentMap.getAliveList(team))
            {
               if(unit.line!=line) continue;
               if(unit.s2Family()==1228)
               {var weak:Boolean=false;for each(var ally:Avatar in unit.s2Lane(true)) if(ally.hp/ally.hpMax<.6)weak=true;if(!weak) {amount*=1-unit.s2Value(unit.skillB,"damageReduction");break;}}
            }
            for each(unit in GameMap.currentMap.getAliveList(team)) if(unit.s2Family()==1201 && unit.line==line && !unit.skin2.guardUsed)
            {
               if(unit.skin2.guarding===this && unit!==this)
               {
                  unit.fxPulse104("guard",this);unit.skin2.guardUsed=true;var transfer:Number=amount*unit.s2Value(unit.skillB,"transfer");amount-=transfer;
                  ++skin2Depth;try {unit.injured(int(transfer*(1-unit.s2Value(unit.skillB,"transferReduction"))),1,null,8,source,false,source);}finally {--skin2Depth;}
                  unit.s2Shield(this,unit.s2Value(unit.skillB,"shield"),1);break;
               }
               if(unit===this && unit.s2Lane(true).length==1) {unit.skin2.guardUsed=true;amount*=1-unit.s2Value(unit.skillB,"soloReduction");break;}
            }
         }
         for each(unit in GameMap.currentMap.getAliveList(team)) if(unit.s2Family()==1216 && unit.skin2.frost && unit.skin2.frost.lane==source.line && unit.manualOwnerActionSerial<unit.skin2.frost.end && unit.s2LiveMark(source,"cold")) {amount*=1-unit.s2Value(unit.skin2.frost.skill,"frostReduction");break;}
         return amount;
      }
      private function skin2Lethal() : void
      {
         if(hp>0 || s2Family()!=1216 || skin2.reborn) return;
         skin2.reborn=true;skin2.eggUntil=manualOwnerActionSerial+2;
         hp=Math.max(1,int(hpMax*s2Value(skillB,"eggHp")));fxPulse104("rebirth");abilityFeedback("冰晶重生");
      }
      private function skin2Moved() : void
      {
         if(!GameMap.currentMap || hp<=0 || getType()!=1 || isManualSummonUnit) return;
         for each(var unit:Avatar in GameMap.currentMap.getAliveList(otherTeam))
            if(unit.s2Family()==1211 && unit.skin2.trap && unit.line==line && Math.abs(unit.pos-pos)<=300)
            {unit.skin2.trap=false;unit.abilityControl(this,"root",1);unit.s2Hit(this,unit.s2Value(unit.skillB,"hit"),1);}
      }

      // END SKIN REVISION V2

      // BEGIN BATTLE EFFECTS 104
      private static function fxProfile104(kind:String) : Array
      {
         switch(kind)
         {
            case "night_wave": return [{id:"c1",at:"flight",delay:0,scale:1.1,life:.32},{id:"c0",at:"target",delay:.28,scale:.9,life:.4}];
            case "night_slash": return [{id:"c0",at:"target",delay:0,scale:.9,life:.3,rotation:-.6},{id:"c1",at:"target",delay:.06,scale:.7,life:.3,rotation:.6}];
            case "night_finish": return [{id:"c1",at:"target",delay:0,scale:1.4,life:.45,rotation:1.5},{id:"c8",at:"target",delay:.1,scale:1.2,life:.5}];
            case "1201": return [{"id":"c0","at":"target","delay":0,"scale":0.9,"life":0.65},{"id":"c8","at":"target","delay":0.12,"scale":0.65,"life":0.65}];
            case "1203": return [{"id":"c4","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c10","at":"target","delay":0.24,"scale":0.75,"life":0.65},{"id":"c10","at":"target","delay":0.32,"scale":0.55,"life":0.65}];
            case "1204": return [{"id":"c15","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c15","at":"target","delay":0.24,"scale":0.75,"life":0.65}];
            case "1206": return [{"id":"c7","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c9","at":"target","delay":0.24,"scale":0.65,"life":0.65}];
            case "1207": return [{"id":"c24","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c22","at":"target","delay":0.24,"scale":0.8,"life":0.65}];
            case "1209": return [{"id":"c11","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c11","at":"target","delay":0.24,"scale":0.7,"life":0.65}];
            case "1210": return [{"id":"c2","at":"target","delay":0,"scale":0.9,"life":0.65,"rotation":-0.45},{"id":"c1","at":"target","delay":0.12,"scale":0.8,"life":0.65,"rotation":0.55}];
            case "1211": return [{"id":"c7","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c8","at":"target","delay":0.24,"scale":0.8,"life":0.65}];
            case "1213": return [{"id":"c4","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c8","at":"target","delay":0.24,"scale":0.85,"life":0.65}];
            case "1214": return [{"id":"c7","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c31","at":"target","delay":0.24,"scale":1.0,"life":0.65},{"id":"c10","at":"target","delay":0.3,"scale":0.45,"life":0.65}];
            case "1215": return [{"id":"c4","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c15","at":"target","delay":0.24,"scale":0.85,"life":0.65}];
            case "1216": return [{"id":"c4","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c9","at":"target","delay":0.24,"scale":0.9,"life":0.65}];
            case "1218": return [{"id":"c20","at":"flight","delay":0,"scale":0.5,"life":0.28},{"id":"c10","at":"target","delay":0.2,"scale":0.8,"life":0.65}];
            case "1219": return [{"id":"c1","at":"flight","delay":0,"scale":0.7,"life":0.2},{"id":"c0","at":"target","delay":0.15,"scale":0.85,"life":0.65},{"id":"c1","at":"target","delay":0.28,"scale":0.7,"life":0.65}];
            case "1221": return [{"id":"c5","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c29","at":"target","delay":0.24,"scale":0.75,"life":0.65}];
            case "1228": return [{"id":"c12","at":"source","delay":0,"scale":0.8,"life":0.65},{"id":"c15","at":"flight","delay":0,"scale":0.65,"life":0.28},{"id":"c9","at":"target","delay":0.28,"scale":0.6,"life":0.65}];
            case "1227": return [{"id":"c6","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c14","at":"target","delay":0.24,"scale":0.85,"life":0.65}];
            case "1140": return [{"id":"c26","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c26","at":"target","delay":0.24,"scale":0.9,"life":0.65}];
            case "rings": return [{"id":"c13","at":"target","delay":0,"scale":0.8,"life":0.65},{"id":"c9","at":"target","delay":0.12,"scale":1.15,"life":0.65},{"id":"c0","at":"target","delay":0.2,"scale":0.65,"life":0.65}];
            case "time_rings": return [{"id":"c26","at":"target","delay":0,"scale":1.05,"life":0.65,"rotation":-0.8},{"id":"c12","at":"target","delay":0.12,"scale":1.1,"life":0.65}];
            case "egg_ready": return [{"id":"c17","at":"target","delay":0,"scale":0.65,"life":0.4,"rise":-12},{"id":"c14","at":"target","delay":0,"scale":0.8,"life":0.65},{"id":"c11","at":"target","delay":0.08,"scale":1.0,"life":0.65},{"id":"c22","at":"target","delay":0.18,"scale":0.7,"life":0.65}];
            case "time": return [{"id":"c12","at":"target","delay":0,"scale":1.15,"life":0.8,"spin":-3},{"id":"c26","at":"target","delay":0.12,"scale":0.8,"life":0.65,"spin":-4},{"id":"c26","at":"target","delay":0.2,"scale":0.6,"life":0.65}];
            case "guard": return [{"id":"c13","at":"target","delay":0,"scale":1.0,"life":0.7},{"id":"c31","at":"target","delay":0.1,"scale":0.75,"life":0.65}];
            case "rebirth": return [{"id":"c21","at":"target","delay":0,"scale":1.15,"life":0.85},{"id":"c9","at":"target","delay":0.15,"scale":1.0,"life":0.65},{"id":"c9","at":"target","delay":0.3,"scale":1.1,"life":0.65}];
            case "crows": return [{"id":"c20","at":"target","delay":0,"scale":1.2,"life":0.9,"spin":3},{"id":"c10","at":"target","delay":0.1,"scale":0.85,"life":0.65},{"id":"c20","at":"target","delay":0.22,"scale":0.9,"life":0.65,"spin":-3}];
            case "cold": return [{"id":"c9","at":"target","delay":0,"scale":0.8,"life":0.65},{"id":"c9","at":"target","delay":0.12,"scale":0.7,"life":0.65}];
            case "cleanse": return [{"id":"c14","at":"target","delay":0,"scale":0.8,"life":0.65},{"id":"c31","at":"target","delay":0.12,"scale":0.8,"life":0.65}];
            case "growth": return [{"id":"c10","at":"target","delay":0,"scale":0.65,"life":0.7,"rise":-30},{"id":"c12","at":"target","delay":0.15,"scale":0.75,"life":0.65}];
            case "bear": return [{"id":"c29","at":"target","delay":0,"scale":0.8,"life":0.8},{"id":"c8","at":"target","delay":0.18,"scale":0.65,"life":0.65}];
            case "bomb": return [{"id":"c8","at":"target","delay":0,"scale":1,"life":0.65},{"id":"c8","at":"target","delay":0.14,"scale":0.9,"life":0.65}];
            case "ball": return [{"id":"c19","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c12","at":"target","delay":0.24,"scale":0.55,"life":0.65}];
            case "shot": return [{"id":"c30","at":"target","delay":0,"scale":0.65,"life":0.65},{"id":"c8","at":"target","delay":0.12,"scale":0.75,"life":0.65}];
            case "wanted": return [{"id":"c7","at":"target","delay":0,"scale":0.75,"life":0.6}];
            case "exposed": return [{"id":"c15","at":"target","delay":0,"scale":0.7,"life":0.65},{"id":"c8","at":"target","delay":0.1,"scale":0.6,"life":0.65}];
            case "charmed": return [{"id":"c24","at":"target","delay":0,"scale":0.8,"life":0.7},{"id":"c22","at":"target","delay":0.15,"scale":0.55,"life":0.65}];
            case "contract": return [{"id":"c10","at":"target","delay":0,"scale":0.7,"life":0.65},{"id":"c10","at":"target","delay":0.12,"scale":0.45,"life":0.65}];
            case "airborne": return [{"id":"c1","at":"target","delay":0,"scale":0.9,"life":0.65,"rise":-45},{"id":"c30","at":"target","delay":0.1,"scale":0.8,"life":0.65,"rise":-30}];
            case "windmark": return [{"id":"c1","at":"target","delay":0,"scale":0.8,"life":0.65},{"id":"c0","at":"target","delay":0.1,"scale":0.65,"life":0.65}];
            case "sonic": return [{"id":"c12","at":"target","delay":0,"scale":0.7,"life":0.65},{"id":"c12","at":"target","delay":0.15,"scale":1.05,"life":0.65}];
            case "sap": return [{"id":"c14","at":"target","delay":0,"scale":0.75,"life":0.65},{"id":"c11","at":"target","delay":0.1,"scale":0.45,"life":0.65}];
            case "1201_ult": return [{"id":"c3","at":"target","delay":0,"scale":1.1,"life":0.65},{"id":"c8","at":"target","delay":0.12,"scale":0.8,"life":0.65}];
            case "1203_ult": return [{"id":"c10","at":"target","delay":0,"scale":1.05,"life":0.65},{"id":"c10","at":"target","delay":0.18,"scale":0.8,"life":0.65}];
            case "1204_ult": return [{"id":"c15","at":"target","delay":0,"scale":1,"life":0.65},{"id":"c15","at":"target","delay":0.14,"scale":0.85,"life":0.65}];
            case "1207_ult": return [{"id":"c24","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c22","at":"target","delay":0.24,"scale":1.15,"life":0.65}];
            case "1210_ult": return [{"id":"c1","at":"flight","delay":0,"scale":1.1,"life":0.22},{"id":"c0","at":"target","delay":0.22,"scale":1.2,"life":0.65}];
            case "1211_ult": return [{"id":"c7","at":"flight","delay":0,"scale":0.55,"life":0.24},{"id":"c8","at":"target","delay":0.24,"scale":1.1,"life":0.65}];
            case "1216_ult": return [{"id":"c9","at":"target","delay":0,"scale":1.15,"life":0.9},{"id":"c12","at":"target","delay":0.18,"scale":1,"life":0.65}];
            case "1218_ult": return [{"id":"c20","at":"target","delay":0,"scale":1.3,"life":0.9,"spin":2},{"id":"c10","at":"target","delay":0.2,"scale":1.0,"life":0.65}];
            case "1221_ult": return [{"id":"c29","at":"target","delay":0,"scale":1.1,"life":0.85},{"id":"c8","at":"target","delay":0.18,"scale":0.9,"life":0.65}];
            case "1140_ult": return [{"id":"c12","at":"target","delay":0,"scale":1.3,"life":0.8,"spin":-3},{"id":"c26","at":"target","delay":0.15,"scale":1.15,"life":0.65,"spin":-4}];
         }
         return [];
      }
      private function fxState104() : Array
      {
         var result:Array=[];var key:String;var state:Object;var unit:Avatar;var kind:String;var count:int;
         if(hp<=0) return result;
         if(yasuoIs104() && shieldValue104()>0) result.push({key:"nightShield104",kind:"guard",target:this});
         for each(key in ["wanted","exposed","charmed","cold","airborne","contract","windmark"])
            if(s2LiveMark(this,key)) result.push({key:key,kind:key,target:this});
         for(key in skin2)
         {
            if(key.indexOf("rings_")==0 && skin2[key].count>0)
            {
               unit=null;
               for each(var actor:Avatar in GameMap.currentMap.getAliveList(otherTeam)) if(key=="rings_"+actor.abilityIndex) {unit=actor;break;}
               if(unit)result.push({key:key,kind:unit.s2Family()==1140 ? "time_rings" : "rings",target:this,count:skin2[key].count});
            }
         }
         if(skin2.sonic && skin2.sonic.hp>0 && skin2.sonic.line==line) result.push({key:"sonic",kind:"sonic",target:skin2.sonic});
         if(skin2.sonic && skin2.sonic.hp>0 && skin2.ward && skin2.ward.hp>0 && skin2.ward.line==line)result.push({key:"ward",kind:"guard",target:skin2.ward});
         if(skin2.ball && skin2.ball.hp>0 && skin2.ball.line==line) result.push({key:"ball",kind:"ball",target:skin2.ball,link:this});
         if(skin2.guarding && skin2.guarding.hp>0 && skin2.guarding.line==line && !skin2.guardUsed) result.push({key:"guarding",kind:"guard",target:skin2.guarding,link:this});
         if(skin2.shotUntil!=undefined && skin2.shotUntil>=manualOwnerActionSerial) result.push({key:"shot",kind:"shot",target:this});
         if(skin2.phase) result.push({key:"phase",kind:"phase",target:this});
         if(skin2.penetrationEnd && skin2.penetrationEnd>=manualOwnerActionSerial)result.push({key:"penetration",kind:"phase",target:this});
         if(skin2.awake) result.push({key:"awake",kind:"awake",target:this});
         if(skin2.eggUntil) result.push({key:"rebirth",kind:"rebirth",target:this,body:true});
         if(skin2.crows) result.push({key:"crows",kind:"crows",target:this,body:true});
         if(skin2.growth) result.push({key:"growth",kind:"growth",target:this,count:skin2.growth});
         if(skin2.bearGrowth) result.push({key:"bearGrowth",kind:"bear",target:this,count:skin2.bearGrowth});
         if(skin2.command) result.push({key:"command",kind:"command",target:this});
         if(s2Family()==1210) result.push({key:"dance",kind:"dance",target:this,count:int(skin2.dance||0)+1});
         if(skin2.wind) result.push({key:"wind",kind:"windmark",target:this,count:skin2.wind});
         if(skin2.windGuard && buffs.shield) result.push({key:"windGuard",kind:"guard",target:this});
         if(skin2.trap) result.push({key:"trap",kind:"trap",lane:line,pos:pos,ground:true});
         if(skin2.eggs) for(var i:int=0;i<skin2.eggs.length;i++)
         {
            state=skin2.eggs[i];result.push({key:"egg"+i,kind:state.ready<=manualOwnerActionSerial ? "egg_ready" : "egg",lane:state.line,pos:state.pos,ground:true});
         }
         if(skin2.frost && manualOwnerActionSerial<skin2.frost.end) result.push({key:"frost",kind:"cold",lane:skin2.frost.lane,pos:GameMapConfig.LINE_POS/2,span:GameMapConfig.LINE_POS,ground:true});
         state=skin2.previous || skin2.record;
         if(s2Family()==1140 && state) result.push({key:"record",kind:"time",lane:state.line,pos:state.pos,ground:true});
         if(s2Family()==1228)
         {
            var weak:Boolean=false;for each(unit in s2Lane(true)) if(unit.hp/unit.hpMax<.6)weak=true;
            result.push({key:"aura",kind:weak ? "aura_heal" : "aura_guard",target:this,body:true});
         }
         for(key in abilityState)
         {
            state=abilityState[key];kind="";
            if(!state) continue;
            if(typeof state=="object" && !(state is Avatar) && state.until!=undefined && abilitySerial>state.until) continue;
            if(key.indexOf("mark_hunt_")==0)kind="hunt";
            else if(key.indexOf("mark_moon_")==0)kind="moon";
            else if(key.indexOf("mark_aim_")==0)kind="wanted";
            else if(key.indexOf("bomb_")==0)kind="bomb";
            else if(key.indexOf("malz_")==0)kind="infection";
            else if(key=="guard" && state.charges>0)kind="guard";
            else if(key=="counter" && state.left>0)kind="counter";
            else if(key=="sap")kind="sap";
            else if(key=="root")kind="root";
            else if(key=="alistarGuard104")kind="guard";
            else if(key=="sixBatchKayleGuard105")kind="guard";
            else if(key=="sixReactionElise105")kind="guard";
            else if(key=="reviewDashReady104")kind="phase";
            else if(key=="grey")kind="grey";
            else if(key=="highlander")kind="phase";
            else if(key=="thunder" || key=="polarCount" || key=="sixFire105")kind="charge";
            else if(key=="evilStacks" || key=="santaStacks")kind="growth";
            else if(key=="form" && state.hammer)kind="hammer";
            if(kind.length)result.push({key:key,kind:kind,target:this,count:(key=="thunder" || key=="polarCount" || key=="evilStacks" || key=="santaStacks" || key=="sixFire105") ? int(state) : 0});
         }
         if(abilityState.channel) result.push({key:"channel",kind:"channel",lane:abilityState.channel.line,pos:abilityState.channel.pos,span:800,ground:true});
         if(abilityState.zone) result.push({key:"zone",kind:"zone",lane:abilityState.zone.line,pos:abilityState.zone.pos,span:700,ground:true});
         if(abilityState.ball && abilityState.ball.hp>0 && abilityState.ball.line==line) result.push({key:"magicBall",kind:"ball",target:abilityState.ball,link:this});
         if(skillB && sixBatchPassive105("jinx") && (count=sixBatchJinxStacks105().length)>0)
            result.push({key:"sixBatchJinx105",kind:"charge",target:this,count:count});
         if(skillB && (count=sixBatchKayleStage105())>0)
            result.push({key:"sixBatchKayle105",kind:"growth",target:this,count:count});
         if(skillB && sixBatchPassive105("syndra") && GameMap.currentMap &&
            (count=int(GameMap.currentMap.roundNum/10))>0)
            result.push({key:"sixBatchSyndra105",kind:"growth",target:this,count:count});
         if((count=int(abilityState.sixReactionMfStacks105))>0)
            result.push({key:"sixReactionMfStacks105",kind:"charge",target:this,count:count});
         if(manualBattleStacks) for(key in manualBattleStacks) if(Number(manualBattleStacks[key])>0) {result.push({key:"battleGrowth",kind:"growth",target:this});break;}
         count=0;if(manualTimedStacks)for each(state in manualTimedStacks)if(state.expiresAt>=manualOwnerActionSerial)++count;
         if(count)result.push({key:"timedGrowth",kind:"charge",target:this,count:count});
         if(isManualSummonUnit && statisticsOwner104 && statisticsOwner104.hp>0) result.push({key:"summon",kind:"summon",target:this});
         return result;
      }
      // Original project-painted atlases, animated in the battle clock. No legacy effect resources.
      private static var fxAtlases104:Array = [];
      private static var fxBitmaps104:Array = [];
      private static var fxTextures104:Object = {};
      private static var fxLoading104:Boolean = false;
      private static var fxLoadFailed104:Boolean = false;
      private static var fxTime104:Number = 0;
      private static var fxNodes104:Object = {};
      private static var fxMap104:Object;
      private static var fxLayer104:Sprite;
      private static var fxPoll104:Number = 0;
      private static var fxPulseCount104:int = 0;
      private static var fxEpoch104:int = 0;

      public static function clearEffects104() : void
      {
         ++fxEpoch104;
         if(fxLayer104)fxLayer104.removeFromParent(true);
         fxLayer104=null;fxMap104=null;fxNodes104={};fxPoll104=0;fxPulseCount104=0;
      }
      private static function fxEnsure104() : Boolean
      {
         fxLoad104();
         if(!fxAtlases104[0] || !fxAtlases104[1])return false;
         var layer:GameMapLayer=GameMapLayer.gl;
         if(!layer || !GameMap.currentMap)return false;
         if(fxMap104!==GameMap.currentMap || !fxLayer104 || !fxLayer104.parent)
         {
            clearEffects104();fxMap104=GameMap.currentMap;
            fxLayer104=new Sprite();fxLayer104.touchable=false;fxLayer104.name="nativeSkillEffects104";
            layer.effectLayer.addChildAt(fxLayer104,0);
         }
         return true;
      }
      private static function fxOrigin104(unit:Avatar) : Point
      {
         if(!unit || !unit.m_fightRes || !unit.m_fightRes.parent || !fxLayer104)return null;
         return fxLayer104.globalToLocal(unit.m_fightRes.localToGlobal(new Point(0,0)));
      }
      private static function fxPosition104(lane:int, position:Number) : Point
      {
         if(!GameMapLayer.gl || !fxLayer104)return null;
         return fxLayer104.globalToLocal(GameMapLayer.gl.getLineSpr(lane).localToGlobal(new Point(0,GameMapConfig.posToPixel(position))));
      }
      private static function fxNative104(id:String, scale:Number = 1, alpha:Number = 1) : DisplayObject
      {
         var index:int=int(id.substr(1));var sheet:int=int(index/16);var cell:int=index%16;
         if(id.charAt(0)!="c" || index<0 || index>=32 || !fxAtlases104[sheet])return null;
         var texture:starling.textures.Texture=fxTextures104[id];
         if(!texture)
         {
            var atlas:starling.textures.Texture=fxAtlases104[sheet];var size:Number=atlas.width/4;
            texture=starling.textures.Texture.fromTexture(atlas,new Rectangle((cell%4)*size,int(cell/4)*size,size,size));fxTextures104[id]=texture;
         }
         var art:Image=new Image(texture);art.pivotX=texture.width/2;art.pivotY=texture.height/2;
         art.touchable=false;art.scaleX=art.scaleY=96/texture.width*scale;art.alpha=alpha;
         return art;
      }
      private static function fxLoad104() : void
      {
         if(fxLoading104 || fxLoadFailed104)return;fxLoading104=true;
         fxLoadSheet104(0,"energy");fxLoadSheet104(1,"states");
      }
      private static function fxLoadSheet104(index:int, name:String) : void
      {
         var loader:flash.display.Loader=new flash.display.Loader();
         loader.contentLoaderInfo.addEventListener(flash.events.Event.COMPLETE,function(event:flash.events.Event):void
         {
            var decoded:flash.display.Bitmap=loader.content as flash.display.Bitmap;
            if(!decoded) {fxLoadFailed104=true;trace("Custom VFX: invalid PNG "+name);return;}
            var bitmap:flash.display.BitmapData=decoded.bitmapData.clone();fxBitmaps104[index]=bitmap;
            var texture:starling.textures.Texture=starling.textures.Texture.fromBitmapData(bitmap,false,false);
            texture.root.onRestore=function():void {texture.root.uploadBitmapData(bitmap);};fxAtlases104[index]=texture;
            loader.unloadAndStop(true);
         });
         loader.contentLoaderInfo.addEventListener(flash.events.IOErrorEvent.IO_ERROR,function(event:flash.events.IOErrorEvent):void {fxLoadFailed104=true;trace("Custom VFX load failed: "+name+" "+event.text);});
         loader.load(new flash.net.URLRequest("app:/assets/effects/custom104/"+name+".png"));
      }
      private static function fxPersistent104(row:Object) : Array
      {
         if(row.key=="frost")return ["c9","c12"];
         if(row.key=="zone")return ["c8","c5"];
         if(row.key=="channel")return ["c30","c12"];
         if(row.kind=="egg" || row.kind=="egg_ready")return row.kind=="egg_ready" ? ["c17"] : ["c16"];
         if(row.key=="trap")return ["c18"];
         if(row.key=="record")return ["c26"];
         if(row.key=="rebirth")return ["c21"];
         if(row.key=="crows")return ["c20","c20","c20"];
         if(row.key=="aura")return row.kind=="aura_heal" ? ["c14"] : ["c13"];
         if(row.key=="cold")return ["c9"];
         if(row.key=="windGuard")return ["c1"];
         if(row.kind=="rings" || row.kind=="time_rings")
         {
            var rings:Array=[];for(var n:int=0;n<Math.min(3,int(row.count));n++)rings.push(row.kind=="rings" ? "c12" : "c26");return rings;
         }
         if(row.kind=="root")return ["c27"];
         if(row.kind=="infection" || row.kind=="contract")return ["c10"];
         if(row.kind=="wanted")return ["c7","c7"];
         if(row.kind=="moon")return ["c1"];
         if(row.kind=="windmark")return ["c1"];
         if(row.kind=="awake")return ["c22","c2"];
         if(row.kind=="dance") {var arcs:Array=[];for(n=0;n<Math.min(3,int(row.count));n++)arcs.push("c2");return arcs;}
         if(row.kind=="command")return ["c29","c28"];
         if(row.kind=="bear")return ["c29"];
         if(row.kind=="shot")return ["c19","c15"];
         if(row.kind=="ball")return ["c19"];
         if(row.kind=="phase")return ["c26","c1"];
         if(row.kind=="exposed")return ["c23"];
         if(row.kind=="charmed")return ["c24"];
         if(row.kind=="sonic")return ["c30"];
         if(row.kind=="airborne")return ["c1","c30"];
         if(row.kind=="hunt")return ["c23"];
         if(row.kind=="guard")return ["c28","c13"];
         if(row.kind=="growth")return ["c14"];
         if(row.kind=="counter")return ["c0","c13"];
         if(row.kind=="sap")return ["c14"];
         if(row.kind=="grey")return ["c25"];
         if(row.kind=="charge")return ["c15"];
         if(row.kind=="hammer")return ["c0"];
         if(row.kind=="bomb")return ["c5"];
         if(row.kind=="summon")return ["c12"];
         return [];
      }
      public static function advanceEffects104(elapsed:Number) : void
      {
         yasuoAdvanceEffects104(elapsed);
         if(GameMapLayer.isFastest) {if(fxLayer104)clearEffects104();return;}
         if(!fxEnsure104()) {clearEffects104();return;}
         fxTime104+=elapsed;fxPoll104+=elapsed;if(fxPoll104<.04)return;fxPoll104=0;
         var live:Object={};var unit:Avatar;var row:Object;var key:String;var node:Object;
         for each(var side:int in [1,2])for each(unit in GameMap.currentMap.getAliveList(side))
         {
            if(!unit.m_fightRes || !unit.m_fightRes.parent)continue;
            for each(row in unit.fxState104())
            {
               var ids:Array=fxPersistent104(row);if(!ids.length)continue;
               var origin:Point=row.ground ? fxPosition104(row.lane,row.pos) : fxOrigin104(row.target);if(!origin)continue;
               key=unit.abilityIndex+":"+row.key;live[key]=true;node=fxNodes104[key];
               var signature:String=ids.join("|");
               if(!node || node.signature!=signature)
               {
                  if(node)node.sprite.removeFromParent(true);
                  var sprite:Sprite=new Sprite();sprite.touchable=false;var parts:Array=[];
                  var copies:int=row.span ? 5 : ids.length;
                  for(var i:int=0;i<copies;i++)
                  {
                     var art:DisplayObject=fxNative104(ids[i%ids.length],row.span ? .45 : .65,row.span ? .3 : .55);
                     if(!art)continue;sprite.addChild(art);parts.push(art);
                     if(row.key=="aura" || row.key=="trap" || row.key=="record")art.scaleY*=.45;
                     if(row.key=="crows") {art.rotation=i*Math.PI;art.scaleX*=.6;art.scaleY*=.6;art.alpha=.7;}
                     if(row.kind=="rings" || row.kind=="time_rings") {art.scaleX*=.8+i*.2;art.scaleY*=.3+i*.08;art.y=26;art.alpha=.42;}
                     art.name=String(art.scaleX)+","+String(art.scaleY);
                  }
                  if(row.key=="record" && unit.m_icon)
                  {
                     var ghost:Image=new Image(unit.m_icon.texture);ghost.pivotX=ghost.width/2;ghost.pivotY=ghost.height/2;
                     ghost.alpha=.2;ghost.color=0x70ddff;ghost.touchable=false;sprite.addChildAt(ghost,0);
                  }
                  fxLayer104.addChildAt(sprite,0);
                  node={sprite:sprite,parts:parts,signature:signature};fxNodes104[key]=node;
               }
               node.sprite.x=origin.x;node.sprite.y=origin.y+(row.ground ? 0 : row.key=="aura" || row.key=="cold" ? 25 : 0);
               for(i=0;i<node.parts.length;i++)fxAnimateState104(node.parts[i],row,i,unit.abilityIndex);
               if(row.span)
               {
                  var low:Number=Math.max(0,row.pos-row.span/2);var high:Number=Math.min(GameMapConfig.LINE_POS,row.pos+row.span/2);
                  for(i=0;i<node.parts.length;i++)
                  {
                     var point:Point=fxPosition104(row.lane,low+(high-low)*i/Math.max(1,node.parts.length-1));
                     node.parts[i].x=point.x-origin.x;node.parts[i].y=point.y-origin.y;
                  }
               }
            }
         }
         for(key in fxNodes104)if(!live[key]) {fxNodes104[key].sprite.removeFromParent(true);delete fxNodes104[key];}
      }
      private static function fxAnimateState104(art:DisplayObject, row:Object, index:int, seed:int) : void
      {
         var base:Array=art.name.split(",");var t:Number=fxTime104;var phase:Number=t*2+index*2.094+seed*.3;
         art.scaleX=Number(base[0])*(1+.06*Math.sin(phase));art.scaleY=Number(base[1])*(1+.08*Math.cos(phase));
         if(["crows","dance","phase","charge","windmark","sonic","airborne"].indexOf(row.kind)>=0)
         {
            art.x=Math.cos(phase)*30;art.y=Math.sin(phase)*14;art.rotation=phase+(row.kind=="crows" ? 0 : Math.PI/2);
            if(row.kind=="crows") {art.rotation=Math.sin(phase)*.2;art.scaleY*=.8+.25*Math.sin(t*10+index);}
         }
         else if(row.kind=="awake") {art.rotation=(index ? -1 : 1)*t;art.alpha=.35+.12*Math.sin(phase);}
         else if(row.kind=="shot" || row.kind=="ball") {art.x=Math.cos(phase)*19;art.y=20+Math.sin(phase)*5;art.rotation=t*2;}
         else if(row.kind=="charmed") {art.rotation=t*.65;art.alpha=.55+.12*Math.sin(phase);}
         else if(row.kind=="exposed") {art.alpha=.3+.25*(1+Math.sin(t*4))*.5;art.rotation=-.2;}
         else if(row.kind=="growth" || row.kind=="bear" || row.kind=="command") {art.y=18-Math.sin(phase)*9;art.alpha=.3+.16*Math.sin(phase);}
         else if(row.kind=="guard" || row.kind=="grey") {art.alpha=.38+.12*Math.sin(phase);art.rotation=0;}
         else if(row.kind=="wanted") {art.x=(index ? 1 : -1)*(24+Math.sin(phase)*3);art.rotation=index ? Math.PI : 0;art.scaleX*=.5;art.scaleY*=.5;}
         else if(row.kind=="time" || row.kind=="time_rings")art.rotation=-t*.65;
         else if(row.kind=="egg_ready") {art.rotation=Math.sin(t*5)*.08;art.y=Math.sin(t*3)*3;}
         else if(row.kind=="summon") {art.scaleY*=.35;art.y=28;art.rotation=t*.2;art.alpha=.25;}
      }
      private function fxPulse104(kind:String, target:Avatar = null, lane:int = -1, position:Number = 0) : void
      {
         if(GameMapLayer.isFastest)return;
         if(!fxEnsure104())return;
         var victim:Avatar=target || this;var profile:Array=fxProfile104(kind);var ground:Point=lane>=0 ? fxPosition104(lane,position) : null;
         for each(var piece:Object in profile)
            GameMapLayer.gl.delayCall(fxSpawn104,GameMap.actionDelay+Number(piece.delay),piece,this,victim,ground,GameMap.currentMap,fxEpoch104);
      }
      private function fxStrike104(target:Avatar) : void
      {
         var kind:String=String(s2Family());
         if(skin2.castSkill && skin2.castSkill===skill1 && fxProfile104(kind+"_ult").length)kind+="_ult";
         if(target)fxPulse104(kind,target);
      }
      private static function fxSpawn104(piece:Object, source:Avatar, target:Avatar, ground:Point, battle:Object, epoch:int) : void
      {
         if(battle!==GameMap.currentMap || epoch!=fxEpoch104 || !fxLayer104 || fxPulseCount104>=48)return;
         var start:Point=fxOrigin104(source);var finish:Point=ground || fxOrigin104(target);
         var origin:Point=piece.at=="source" || piece.at=="flight" ? start : finish;
         if(!origin || !finish)return;
         var art:DisplayObject=fxNative104(piece.id,piece.scale);if(!art)return;
         var container:Sprite=new Sprite();container.touchable=false;container.x=origin.x;container.y=origin.y;
         container.addChild(art);fxLayer104.addChild(container);++fxPulseCount104;
         art.rotation=Number(piece.rotation||0);
         var life:Number=Number(piece.life);
         if(piece.at!="flight")
         {
            var baseScale:Number=art.scaleX;art.scaleX*=.35;art.scaleY*=.35;
            var bloom:Tween=new Tween(art,Math.min(.18,life*.4),"easeOut");bloom.scaleTo(baseScale);GameMapLayer.gl.addTween(bloom);
         }
         if(piece.at=="flight")
         {
            art.rotation+=Math.atan2(finish.y-origin.y,finish.x-origin.x);
            var travel:Tween=new Tween(container,life,"linear");travel.moveTo(finish.x,finish.y);GameMapLayer.gl.addTween(travel);
         }
         else if(piece.rise || piece.spin)
         {
            var motion:Tween=new Tween(art,life,"easeOut");
            if(piece.rise)motion.animate("y",Number(piece.rise));
            if(piece.spin)motion.animate("rotation",art.rotation+Number(piece.spin)*life);
            GameMapLayer.gl.addTween(motion);
         }
         var fade:Tween=new Tween(container,.14,"linear");fade.delay=Math.max(0,life-.14);fade.fadeTo(0);
         fade.onComplete=function():void {container.removeFromParent(true);if(epoch==fxEpoch104)fxPulseCount104=Math.max(0,fxPulseCount104-1);};GameMapLayer.gl.addTween(fade);
      }
      private function fxTransfer104(kind:String, receiver:Avatar) : void
      {
         if(!receiver)return;fxPulse104(kind=="ball" ? "ball" : "sonic",receiver);
      }

      // END BATTLE EFFECTS 104

      public function equipmentPart104(sourceSkill:*, part:String, value:Number) : Number
      {
         var row:Object = sourceSkill && sourceSkill.skillSetData ? GlobalData.$mConfig_skill[sourceSkill.skillSetData.id] : null;
         var parts:Object = row ? row.equipment_parts_104 : null;
         return parts && parts[part] != null ? value*Number(parts[part]) : value;
      }

      public function executeAbility(kind:String, scale:Number, effect:String, sourceSkill:*) : Boolean
      {
         var parallelBatch:Object = ["illaoi_n", "illaoi_c", "jayce_n", "jayce_c", "maokai_c", "wukong_c", "gangplank_c", "yi_n", "riven_n", "riven_c", "orianna_n", "orianna_c", "alistar_n", "diana_n", "jinx_n", "jinx_c", "aoxing_c", "kaelthas_c", "cat_n", "cat_c", "polar_n", "polar_c", "santa_c"].indexOf(kind) >= 0 ? beginParallelVisualBatch() : null;
         try
         {
            return executeAbilityBody(kind,scale,effect,sourceSkill);
         }
         finally { endParallelVisualBatch(parallelBatch); }
      }

      private function executeAbilityBody(kind:String, scale:Number, effect:String, sourceSkill:*) : Boolean
      {
         if(kind.indexOf("six_")==0) return sixStarExecute105(kind,effect,sourceSkill);
         if(kind.indexOf("night_yasuo_")==0) return yasuoExecute104(kind,sourceSkill);
         if(kind.indexOf("dragon_kaisa_")==0) return kaisaExecute104(kind,sourceSkill);
         if(kind.indexOf("skin2_")==0) return executeSkin2(kind,sourceSkill);
         if(kind == "cat_n" || kind == "cat_c") return executeCatSkin(kind,scale,effect,sourceSkill);
         if(kind == "polar_n" || kind == "polar_c") return executePolarSkin(kind,effect,sourceSkill);
         if(kind == "santa_n" || kind == "santa_c") return executeSantaSkin(kind,effect,sourceSkill);
         if(kind == "nurse_n" || kind == "nurse_c") return executeNurseSkin(kind,sourceSkill);
         var orangeFourStatBuffMultiplier:Number = getStar() == 6 ? 5 : 1;
         var enemies:Array;
         var targets:Array;
         var target:Avatar;
         var ally:Avatar;
         var other:Avatar;
         var state:Object;
         var primary:Avatar;
         var coefficient:Number;
         var marked:Boolean;
         var landed:Boolean;
         var i:int;
         var count:int;
         var context:Object = currentAbilityAttack();
         var manualConfig:Object = sourceSkill && sourceSkill.skillSetData && GlobalData.$mConfig_skill ? GlobalData.$mConfig_skill[sourceSkill.skillSetData.id] : null;
         var manualDamageMultiplier:Number = sourceSkill ? Number(sourceSkill.getNativeSetting("manualDamageMultiplier",1)) : 1;
         var manualEffectMultiplier:Number = sourceSkill ? Number(sourceSkill.getNativeSetting("manualEffectMultiplier",1)) : 1;
         var manualDefenseBuffMultiplier:Number = sourceSkill ? Number(sourceSkill.getNativeSetting("manualDefenseBuffMultiplier",1)) : 1;
         if(!isFinite(manualDamageMultiplier) || manualDamageMultiplier <= 0) manualDamageMultiplier = 1;
         if(!isFinite(manualEffectMultiplier) || manualEffectMultiplier <= 0) manualEffectMultiplier = 1;
         if(!isFinite(manualDefenseBuffMultiplier) || manualDefenseBuffMultiplier <= 0) manualDefenseBuffMultiplier = 1;
         var hadManualFactor:Boolean = context != null && context.hasOwnProperty("manualDamageMultiplier");
         var previousManualFactor:Object = hadManualFactor ? context.manualDamageMultiplier : null;
         var hadManualEffectFactor:Boolean = context != null && context.hasOwnProperty("manualEffectMultiplier");
         var previousManualEffectFactor:Object = hadManualEffectFactor ? context.manualEffectMultiplier : null;
         if(context && context.owner === this)
         {
            context.manualDamageMultiplier = manualDamageMultiplier;
            context.manualEffectMultiplier = manualEffectMultiplier;
         }
         try
         {
         switch(kind)
         {
            case "illaoi_n":
               enemies = abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(!enemies.length) return false;
               primary = enemies[0]; targets = [primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_2",250),primary,nativeAbilityNumber(sourceSkill,kind,"cast_3",3),false,"nearest",[primary])); count = 0;
               for each(target in targets) if(abilityHit(target,equipmentPart104(sourceSkill,"tentacle_hit",nativeAbilityNumber(sourceSkill,kind,"cast_6",1.2))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_7",1),effect) && target.getType() == 1 && !target.isManualSummonUnit) ++count;
               if(count) abilityHeal(this,equipmentPart104(sourceSkill,"tentacle_heal",nativeAbilityNumber(sourceSkill,kind,"cast_9",0.15))*Math.min(nativeAbilityNumber(sourceSkill,kind,"cast_10",3),count)*scale);
               break;
            case "illaoi_c":
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",350),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",3))) abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_2",2),nativeAbilityNumber(sourceSkill,kind,"cast_3",1),effect);
               abilityState.counter = {until:abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_4",2),left:nativeAbilityNumber(sourceSkill,kind,"cast_5",2),seen:{},manualDamageMultiplier:manualDamageMultiplier,manualEffectMultiplier:manualEffectMultiplier,debuff:false};
               break;
            case "jayce_n":
               state = abilityState.form || {hammer:false}; abilityState.form = state;
               enemies = abilityEnemies(state.hammer ? nativeAbilityNumber(sourceSkill,kind,"cast_0",500) : nativeAbilityNumber(sourceSkill,kind,"cast_1",700)); if(!enemies.length) return false; primary=enemies[0];
               if(!state.hammer)
               {
                  abilityHit(primary,nativeAbilityNumber(sourceSkill,kind,"cast_3",1.4)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_4",1),effect);
                  for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_5",200),primary,nativeAbilityNumber(sourceSkill,kind,"cast_6",1),false,"nearest",[primary])) abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_8",0.8)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_9",1),effect);
               }
               else
               {
                  if(!abilityDash(primary)) return false;
                  if(abilityHit(primary,equipmentPart104(sourceSkill,"hammer_hit",nativeAbilityNumber(sourceSkill,kind,"cast_10",1.8))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_11",1),effect)) primary.checkMove(false,nativeAbilityNumber(sourceSkill,kind,"cast_12",200),this,-1,true);
                  abilityShield(this,equipmentPart104(sourceSkill,"hammer_shield",nativeAbilityNumber(sourceSkill,kind,"cast_14",0.5))*scale);
               }
               state.hammer = !state.hammer;
               break;
            case "jayce_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700)); if(!enemies.length) return false; primary=enemies[0];
               targets=[primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_2",250),primary,nativeAbilityNumber(sourceSkill,kind,"cast_3",3),false,"nearest",[primary]));
               for each(target in targets) abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_5",1.6),nativeAbilityNumber(sourceSkill,kind,"cast_6",1),effect,target===primary ? nativeAbilityNumber(sourceSkill,kind,"cast_7",3) : nativeAbilityNumber(sourceSkill,kind,"cast_8",0));
               if(primary.hp > 0)
               {
                  if(!abilityState.root) abilityDash(primary);
                  if(abilityHit(primary,nativeAbilityNumber(sourceSkill,kind,"cast_10",1.4),nativeAbilityNumber(sourceSkill,kind,"cast_11",1),effect,nativeAbilityNumber(sourceSkill,kind,"cast_12",3))) primary.checkMove(false,nativeAbilityNumber(sourceSkill,kind,"cast_13",250),this,-1,true);
               }
               abilityState.form = {hammer:false};
               break;
            case "nidalee_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",1),false,"farthest"); if(!enemies.length) return false; target=enemies[0];
               coefficient=(nativeAbilityNumber(sourceSkill,kind,"cast_4",1)+Math.min(sourceSkill.skillSetData.range,Math.abs(pos-target.pos))/Math.max(nativeAbilityNumber(sourceSkill,kind,"cast_5",1),sourceSkill.skillSetData.range))*scale;
               if(abilityHit(target,equipmentPart104(sourceSkill,"spear",coefficient),nativeAbilityNumber(sourceSkill,kind,"cast_6",2),effect)) abilityMark(target,"hunt",nativeAbilityNumber(sourceSkill,kind,"cast_8",3));
               break;
            case "nidalee_c":
               ally=abilityAlly(); abilityHeal(ally,equipmentPart104(sourceSkill,"primal_heal",nativeAbilityNumber(sourceSkill,kind,"cast_0",0.7)));
               target=abilityMarkedTarget("hunt",nativeAbilityNumber(sourceSkill,kind,"cast_2",700));
               if(target && abilityDash(target))
               {
                  marked=target.abilityHasMark(this,"hunt");
                  if(abilityHit(target,marked ? nativeAbilityNumber(sourceSkill,kind,"cast_4",3.2) : nativeAbilityNumber(sourceSkill,kind,"cast_5",2.2),nativeAbilityNumber(sourceSkill,kind,"cast_6",2),effect) && marked) delete target.abilityState["mark_hunt_"+abilityIndex];
               }
               break;
            case "kayle_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(enemies.length && abilityHit(enemies[0],equipmentPart104(sourceSkill,"holy_hit",nativeAbilityNumber(sourceSkill,kind,"cast_2",1.2))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect)) abilityControl(enemies[0],"sunder",nativeAbilityNumber(sourceSkill,kind,"cast_6",2),nativeAbilityNumber(sourceSkill,kind,"cast_7",0.2)*scale);
               abilityHeal(abilityAlly(),equipmentPart104(sourceSkill,"holy_heal",nativeAbilityNumber(sourceSkill,kind,"cast_8",0.45))*scale);
               break;
            case "kayle_c":
               ally=abilityAlly(nativeAbilityNumber(sourceSkill,kind,"cast_0",600)); if(!ally) return false;
               ally.abilityState.guard={kind:"kayle",charges:nativeAbilityNumber(sourceSkill,kind,"cast_2",1),until:ally.abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_3",2),owner:this,manualDamageMultiplier:manualDamageMultiplier,debuff:false};
               break;
            case "maokai_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(!enemies.length || !abilityDash(enemies[0])) return false;
               if(abilityHit(enemies[0],scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect)) abilityControl(enemies[0],"root",nativeAbilityNumber(sourceSkill,kind,"cast_6",1));
               abilityState.sap={until:abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_7",2),manualEffectMultiplier:equipmentPart104(sourceSkill,"sap_heal",manualEffectMultiplier),debuff:false};
               break;
            case "maokai_c":
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",3),false,"nearest",null,true)) if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_3",1.8),nativeAbilityNumber(sourceSkill,kind,"cast_4",2),effect)) abilityControl(target,"root",nativeAbilityNumber(sourceSkill,kind,"cast_6",2));
               abilityShield(this,equipmentPart104(sourceSkill,"root_shield",nativeAbilityNumber(sourceSkill,kind,"cast_7",0.2)),nativeAbilityNumber(sourceSkill,kind,"cast_8",2),true);
               break;
            case "wukong_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",175)); if(!enemies.length) return false;
               if(abilityHit(enemies[0],nativeAbilityNumber(sourceSkill,kind,"cast_2",1.4)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",1),effect)) abilityControl(enemies[0],"sunder",nativeAbilityNumber(sourceSkill,kind,"cast_6",2),nativeAbilityNumber(sourceSkill,kind,"cast_7",0.25)*scale);
               abilitySummon(id,nativeAbilityNumber(sourceSkill,kind,"cast_8",1),nativeAbilityNumber(sourceSkill,kind,"cast_9",0.35)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_10",2),"wukong",null,true); checkMove(false,nativeAbilityNumber(sourceSkill,kind,"cast_12",200));
               break;
            case "wukong_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700)); if(!enemies.length || !abilityDash(enemies[0])) return false; primary=enemies[0];
               targets=[primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",300),primary,nativeAbilityNumber(sourceSkill,kind,"cast_4",3),false,"nearest",[primary]));
               for(i=0;i<nativeAbilityNumber(sourceSkill,kind,"cast_7",2);i++) for each(target in targets) if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_8",1.3),nativeAbilityNumber(sourceSkill,kind,"cast_9",1),effect,nativeAbilityNumber(sourceSkill,kind,"cast_10",2.6)) && i==0) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_13",1));
               addBuff("steel",nativeAbilityNumber(sourceSkill,kind,"cast_15",2),nativeAbilityNumber(sourceSkill,kind,"cast_16",0.4)*manualDefenseBuffMultiplier);
               break;
            case "gangplank_n":
               marked=hp/hpMax < nativeAbilityNumber(sourceSkill,kind,"cast_0",0.5); enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_1",600)); if(!enemies.length) return false;
               abilityHit(enemies[0],nativeAbilityNumber(sourceSkill,kind,"cast_3",1.6)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_4",1),effect);
               if(marked) { removeAllDebuff(); abilityHeal(this,nativeAbilityNumber(sourceSkill,kind,"cast_5",0.4)*scale); }
               break;
            case "gangplank_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",800)); if(!enemies.length) return false; primary=enemies[0];
               abilityState.zone={abyssRelicContext104:abyssCaptureContext104(this),line:primary.line,pos:primary.pos,left:nativeAbilityNumber(sourceSkill,kind,"cast_2",2),manualDamageMultiplier:manualDamageMultiplier,manualEffectMultiplier:manualEffectMultiplier};
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",350),primary,nativeAbilityNumber(sourceSkill,kind,"cast_4",3))) if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_5",1.2),nativeAbilityNumber(sourceSkill,kind,"cast_6",1),effect)) abilityControl(target,"weak",nativeAbilityNumber(sourceSkill,kind,"cast_8",1),nativeAbilityNumber(sourceSkill,kind,"cast_9",0.2));
               break;
            case "yi_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600),null,-1); if(!enemies.length) return false;
               coefficient=(enemies.length==nativeAbilityNumber(sourceSkill,kind,"cast_2",1) ? nativeAbilityNumber(sourceSkill,kind,"cast_3",2) : nativeAbilityNumber(sourceSkill,kind,"cast_4",1.1))*scale;
               for each(target in enemies.slice(0,nativeAbilityNumber(sourceSkill,kind,"cast_6",3))) abilityHit(target,coefficient,nativeAbilityNumber(sourceSkill,kind,"cast_7",1),effect);
               if(!sourceSkill.getNativeSetting("reviewFleeQuality104",0)) addBuff("fleeup",nativeAbilityNumber(sourceSkill,kind,"cast_9",1),nativeAbilityNumber(sourceSkill,kind,"cast_10",600)*scale*orangeFourStatBuffMultiplier);
               break;
            case "yi_c":
               addBuff("strong",nativeAbilityNumber(sourceSkill,kind,"cast_1",3),nativeAbilityNumber(sourceSkill,kind,"cast_2",0.5)); addBuff("hitup",nativeAbilityNumber(sourceSkill,kind,"cast_4",3),nativeAbilityNumber(sourceSkill,kind,"cast_5",800)*orangeFourStatBuffMultiplier); removeBuff("weak");
               abilityState.highlander={until:abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_7",3),left:nativeAbilityNumber(sourceSkill,kind,"cast_8",2),debuff:false};
               if(skill0) skill0.useSkill();
               break;
            case "veigar_n":
               var expandedVeigar:Boolean=Boolean(manualConfig && manualConfig.sixStarVeigar105);
               enemies=expandedVeigar ? sixStarLane105(3000,true).slice(0,2) : abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600));
               if(!enemies.length) return false;
               var growEvil:Boolean=false;
               for each(target in enemies)
                  if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_2",1.2)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect) && target.getType()==1 && !target.isManualSummonUnit)
                     growEvil=true;
               if(growEvil)
               {
                  var oldEvilStacks:int = int(abilityState.evilStacks);
                  abilityState.evilStacks = Math.min(nativeAbilityNumber(sourceSkill,kind,"cast_5",10),oldEvilStacks+nativeAbilityNumber(sourceSkill,kind,"cast_6",1));
                  var evilGrowth:Number=expandedVeigar ? .07 : nativeAbilityNumber(sourceSkill,kind,"cast_8",0.03)*activeManualEffectMultiplier();
                  if(int(abilityState.evilStacks) > oldEvilStacks) abilityState.evilStackBonus = Number(abilityState.evilStackBonus || nativeAbilityNumber(sourceSkill,kind,"cast_7",0)) + equipmentPart104(sourceSkill,"evil_stack",evilGrowth);
                  abilityFeedback("邪恶之力："+int(abilityState.evilStacks)+"/10","FX_S9160_STRONG");
               }
               break;
            case "veigar_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",1),true,"ratio"); if(!enemies.length) enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",700));
               if(!enemies.length) return false;
               target=enemies[0];
               var previousVeigarHit:Number = Number(abilityState.veigarCastHit || 0);
               abilityState.veigarCastHit = previousVeigarHit+30000*Number(sourceSkill.getNativeSetting("manualFixedScale104",1));
               try { abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_5",2)+equipmentPart104(sourceSkill,"execution",nativeAbilityNumber(sourceSkill,kind,"cast_6",3))*(nativeAbilityNumber(sourceSkill,kind,"cast_7",1)-target.hp/target.hpMax),nativeAbilityNumber(sourceSkill,kind,"cast_8",2),effect); }
               finally { abilityState.veigarCastHit = previousVeigarHit; }
               break;
            case "elise_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600)); if(!enemies.length) return false; target=enemies[0];
               coefficient=scale+Math.min(getDamage(),target.hp*equipmentPart104(sourceSkill,"current_hp",nativeAbilityNumber(sourceSkill,kind,"cast_2",0.04))*scale)/Math.max(nativeAbilityNumber(sourceSkill,kind,"cast_3",1),getDamage());
               if(abilityHit(target,coefficient,nativeAbilityNumber(sourceSkill,kind,"cast_4",2),effect)) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_6",1));
               break;
            case "elise_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",1),true,"ratio"); if(!enemies.length || !abilityDash(enemies[0])) return false; target=enemies[0];
               coefficient=nativeAbilityNumber(sourceSkill,kind,"cast_5",1.8)+Math.min(getDamage()*nativeAbilityNumber(sourceSkill,kind,"cast_6",1.8),(target.hpMax-target.hp)*equipmentPart104(sourceSkill,"venom_execute",nativeAbilityNumber(sourceSkill,kind,"cast_7",0.12)))/Math.max(nativeAbilityNumber(sourceSkill,kind,"cast_8",1),getDamage());
               abilityHit(target,coefficient,nativeAbilityNumber(sourceSkill,kind,"cast_9",2),effect); abilitySummon("A_2013_5",nativeAbilityNumber(sourceSkill,kind,"cast_11",2),nativeAbilityNumber(sourceSkill,kind,"cast_12",0.3),nativeAbilityNumber(sourceSkill,kind,"cast_13",2),"elise");
               break;
            case "riven_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",450)); if(!enemies.length || !abilityDash(enemies[0])) return false; primary=enemies[0];
               count=int(abilityState.rivenStep)%nativeAbilityNumber(sourceSkill,kind,"cast_3",3)+nativeAbilityNumber(sourceSkill,kind,"cast_4",1); abilityState.rivenStep=count%nativeAbilityNumber(sourceSkill,kind,"cast_5",3); abilityFeedback("折翼之舞：第"+count+"式",effect);
               for each(target in [primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_8",200),primary,nativeAbilityNumber(sourceSkill,kind,"cast_9",2),false,"nearest",[primary]))) if(abilityHit(target,(count==nativeAbilityNumber(sourceSkill,kind,"cast_11",3) ? equipmentPart104(sourceSkill,"third_dance",nativeAbilityNumber(sourceSkill,kind,"cast_12",1.4)) : nativeAbilityNumber(sourceSkill,kind,"cast_13",0.8))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_14",1),effect) && count==nativeAbilityNumber(sourceSkill,kind,"cast_15",3)) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_17",1));
               if(count==nativeAbilityNumber(sourceSkill,kind,"cast_18",2)) abilityShield(this,equipmentPart104(sourceSkill,"second_shield",nativeAbilityNumber(sourceSkill,kind,"cast_19",0.6))*scale);
               break;
            case "riven_c":
               addBuff("strong",nativeAbilityNumber(sourceSkill,kind,"cast_1",2),nativeAbilityNumber(sourceSkill,kind,"cast_2",0.35));
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",700),null,nativeAbilityNumber(sourceSkill,kind,"cast_4",3),false,"nearest",null,true)) abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_6",1.6)+nativeAbilityNumber(sourceSkill,kind,"cast_7",0.96)*(nativeAbilityNumber(sourceSkill,kind,"cast_8",1)-target.hp/target.hpMax),nativeAbilityNumber(sourceSkill,kind,"cast_9",1),effect);
               abilityState.rivenStep=nativeAbilityNumber(sourceSkill,kind,"cast_10",2);
               break;
            case "orianna_n":
               ally=abilityAlly(nativeAbilityNumber(sourceSkill,kind,"cast_0",3001),"front",true) || this; abilityState.ball=ally;
               abilityShield(ally,equipmentPart104(sourceSkill,"ball_shield",nativeAbilityNumber(sourceSkill,kind,"cast_2",0.8))*scale);
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",300),ally,nativeAbilityNumber(sourceSkill,kind,"cast_4",2))) abilityHit(target,scale,nativeAbilityNumber(sourceSkill,kind,"cast_5",2),effect);
               break;
            case "orianna_c":
               ally=abilityState.ball as Avatar; if(!ally || ally.hp<=0 || ally.line!=line) ally=this; abilityState.ball=ally;
               targets=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_1",350),ally,nativeAbilityNumber(sourceSkill,kind,"cast_2",3));
               for each(target in targets) { abilityPull(target,ally,nativeAbilityNumber(sourceSkill,kind,"cast_3",200)); if(abilityHit(target,equipmentPart104(sourceSkill,"shockwave",nativeAbilityNumber(sourceSkill,kind,"cast_4",2.2)),nativeAbilityNumber(sourceSkill,kind,"cast_5",2),effect)) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_7",1)); }
               abilityShield(ally,nativeAbilityNumber(sourceSkill,kind,"cast_8",0.8));
               break;
            case "nunu_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",175)); if(!enemies.length) return false;
               target=enemies[0]; abilityHit(target,(target.isManualSummonUnit ? nativeAbilityNumber(sourceSkill,kind,"cast_2",3) : nativeAbilityNumber(sourceSkill,kind,"cast_3",1.4))*scale,target.isManualSummonUnit ? nativeAbilityNumber(sourceSkill,kind,"cast_4",3) : nativeAbilityNumber(sourceSkill,kind,"cast_5",2),effect);
               abilityHeal(this,equipmentPart104(sourceSkill,"consume_heal",nativeAbilityNumber(sourceSkill,kind,"cast_6",0.7))*scale);
               break;
            case "nunu_c":
               abilityShield(this,equipmentPart104(sourceSkill,"channel_shield",nativeAbilityNumber(sourceSkill,kind,"cast_0",1.2))); abilityState.channel={abyssRelicContext104:abyssCaptureContext104(this),pos:pos,line:line,manualDamageMultiplier:manualDamageMultiplier,manualEffectMultiplier:manualEffectMultiplier}; abilityFeedback("绝对零度：开始引导","FX_A_1073_MAGIC");
               break;
            case "alistar_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(!enemies.length || !abilityDash(enemies[0])) return false; primary=enemies[0];
               targets=[primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",250),primary,nativeAbilityNumber(sourceSkill,kind,"cast_4",3),false,"nearest",[primary]));
               abilityHit(primary,nativeAbilityNumber(sourceSkill,kind,"cast_6",0.8)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_7",2),effect,nativeAbilityNumber(sourceSkill,kind,"cast_8",1.4)*scale);
               for each(target in targets) if(abilityHit(target,equipmentPart104(sourceSkill,"pulverize",nativeAbilityNumber(sourceSkill,kind,"cast_9",0.6))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_10",2),effect,target===primary ? nativeAbilityNumber(sourceSkill,kind,"cast_11",1.4)*scale : nativeAbilityNumber(sourceSkill,kind,"cast_12",0))) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_14",1));
               addBuff("taunt",nativeAbilityNumber(sourceSkill,kind,"cast_16",2));
               break;
            case "alistar_c":
               removeAllDebuff(); abilityHeal(this,equipmentPart104(sourceSkill,"will_heal",nativeAbilityNumber(sourceSkill,kind,"cast_0",0.5)));
               abilityState.alistarGuard104={until:abilitySerial,reduction:.8*Number(sourceSkill.getNativeSetting("manualFixedScale104",1)),debuff:false};
               break;
            case "diana_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650)); if(!enemies.length) return false; primary=enemies[0];
               for each(target in [primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_2",250),primary,nativeAbilityNumber(sourceSkill,kind,"cast_3",3),false,"nearest",[primary]))) if(abilityHit(target,scale,nativeAbilityNumber(sourceSkill,kind,"cast_5",2),effect)) abilityMark(target,"moon",nativeAbilityNumber(sourceSkill,kind,"cast_7",3));
               break;
            case "diana_c":
               primary=abilityMarkedTarget("moon",nativeAbilityNumber(sourceSkill,kind,"cast_1",650)); if(!primary || !abilityDash(primary)) return false;
               targets=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_2",300),this,nativeAbilityNumber(sourceSkill,kind,"cast_3",3)); if(targets.indexOf(primary)<0) {targets.unshift(primary); targets=targets.slice(0,nativeAbilityNumber(sourceSkill,kind,"cast_6",3));}
               for each(target in targets)
               {
                  marked=target.abilityHasMark(this,"moon"); abilityPull(target,this,nativeAbilityNumber(sourceSkill,kind,"cast_8",150));
                  if(abilityHit(target,marked ? equipmentPart104(sourceSkill,"moon_mark",nativeAbilityNumber(sourceSkill,kind,"cast_9",2.7)) : nativeAbilityNumber(sourceSkill,kind,"cast_10",1.8),nativeAbilityNumber(sourceSkill,kind,"cast_11",2),effect) && marked) delete target.abilityState["mark_moon_"+abilityIndex];
               }
               abilityShield(this,equipmentPart104(sourceSkill,"moon_shield",nativeAbilityNumber(sourceSkill,kind,"cast_13",1)));
               break;
            case "khazix_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(!enemies.length || !abilityDash(enemies[0])) return false;
               abilityHit(enemies[0],(abilityIsolated(enemies[0]) ? equipmentPart104(sourceSkill,"isolated_hit",nativeAbilityNumber(sourceSkill,kind,"cast_4",2.4)) : nativeAbilityNumber(sourceSkill,kind,"cast_5",1.6))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_6",1),effect);
               break;
            case "khazix_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700),null,-1,true); primary=null;
               for each(target in enemies) if(abilityIsolated(target)) {primary=target; break;}
               if(!primary && enemies.length) primary=enemies[0]; if(!primary || !abilityDash(primary,true)) return false;
               abilityHit(primary,abilityIsolated(primary) ? nativeAbilityNumber(sourceSkill,kind,"cast_3",4.2) : nativeAbilityNumber(sourceSkill,kind,"cast_4",2.8),nativeAbilityNumber(sourceSkill,kind,"cast_5",1),effect); addBuff("fleeup",nativeAbilityNumber(sourceSkill,kind,"cast_7",2),equipmentPart104(sourceSkill,"escape_dodge",nativeAbilityNumber(sourceSkill,kind,"cast_8",800))*orangeFourStatBuffMultiplier);
               if(primary.hp<=0 && primary.getType()==1 && !primary.isManualSummonUnit) sourceSkill.abilityCooldownOverride=nativeAbilityNumber(sourceSkill,kind,"cast_11",3);
               break;
            case "malzahar_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600)); if(!enemies.length) return false; target=enemies[0];
               if(target.s2AnnieImmune()) break;
               if(target.buffs.purify) {target.removeBuff("purify",true); break;}
               target.abilityState["malz_"+abilityIndex]={owner:this,until:target.abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_4",1),ticks:nativeAbilityNumber(sourceSkill,kind,"cast_5",3),tickDamage:getDamage()*nativeAbilityNumber(sourceSkill,kind,"cast_6",1)*scale*manualDamageMultiplier*heroSkillOutputRate104(),hops:0,debuff:true};
               target.s2AnnieStatus("poison");
               break;
            case "malzahar_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650)); if(!enemies.length) return false; target=enemies[0];
               if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_2",2.4),nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect)) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_5",2));
               abilitySummon("A_2013_5",nativeAbilityNumber(sourceSkill,kind,"cast_7",2),nativeAbilityNumber(sourceSkill,kind,"cast_8",0.35),nativeAbilityNumber(sourceSkill,kind,"cast_9",2),"malzahar",target);
               break;
            case "jinx_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650)); if(!enemies.length) return false; primary=enemies[0];
               abilityHit(primary,nativeAbilityNumber(sourceSkill,kind,"cast_2",1.5)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",1),effect);
               for each(target in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_4",250),primary,nativeAbilityNumber(sourceSkill,kind,"cast_5",2),false,"nearest",[primary])) abilityHit(target,equipmentPart104(sourceSkill,"rocket_splash",nativeAbilityNumber(sourceSkill,kind,"cast_7",1.1))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_8",1),effect);
               break;
            case "jinx_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",1000),null,nativeAbilityNumber(sourceSkill,kind,"cast_1",1),true,"ratio"); if(!enemies.length) return false; primary=enemies[0];
               targets=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_4",300),primary,nativeAbilityNumber(sourceSkill,kind,"cast_5",2),false,"nearest",[primary]);
               abilityHit(primary,nativeAbilityNumber(sourceSkill,kind,"cast_7",2)+Math.min(nativeAbilityNumber(sourceSkill,kind,"cast_8",2)*getDamage(),(primary.hpMax-primary.hp)*equipmentPart104(sourceSkill,"missing_hp",nativeAbilityNumber(sourceSkill,kind,"cast_9",0.12)))/Math.max(nativeAbilityNumber(sourceSkill,kind,"cast_10",1),getDamage()),nativeAbilityNumber(sourceSkill,kind,"cast_11",1),effect);
               for each(target in targets) abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_12",1.2),nativeAbilityNumber(sourceSkill,kind,"cast_13",1),effect);
               if(context && context.kills.length) {addBuff("strong",nativeAbilityNumber(sourceSkill,kind,"cast_15",2),nativeAbilityNumber(sourceSkill,kind,"cast_16",0.3)); addBuff("critup",nativeAbilityNumber(sourceSkill,kind,"cast_18",2),nativeAbilityNumber(sourceSkill,kind,"cast_19",800)*orangeFourStatBuffMultiplier); if(skill0) skill0.useSkill();}
               break;
            case "tahm_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",500)); if(!enemies.length) return false;
               if(abilityHit(enemies[0],nativeAbilityNumber(sourceSkill,kind,"cast_2",1.1)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect)) abilityControl(enemies[0],"stun",nativeAbilityNumber(sourceSkill,kind,"cast_6",1));
               abilityState.grey={until:abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_7",1),value:0,manualEffectMultiplier:manualEffectMultiplier}; abilityFeedback("灰色生命：开始储存","FX_S9160_SHIELD");
               break;
            case "tahm_c":
               ally=abilityAlly(nativeAbilityNumber(sourceSkill,kind,"cast_0",500),"ratio",true) || this;
               if(ally!==this) ally.reline(line,Math.max(0,Math.min(GameMapConfig.LINE_POS,pos+(team==1 ? nativeAbilityNumber(sourceSkill,kind,"cast_4",100) : -nativeAbilityNumber(sourceSkill,kind,"cast_5",100)))),-2147483648,0,0,true);
               abilityShield(ally,nativeAbilityNumber(sourceSkill,kind,"cast_9",1.6)); ally.addBuff("purify",nativeAbilityNumber(sourceSkill,kind,"cast_11",2)); addBuff("taunt",nativeAbilityNumber(sourceSkill,kind,"cast_13",2)); addBuff("steel",nativeAbilityNumber(sourceSkill,kind,"cast_15",2),nativeAbilityNumber(sourceSkill,kind,"cast_16",0.4)*manualDefenseBuffMultiplier);
               break;
            case "caitlyn_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600)); if(!enemies.length) return false; target=enemies[0];
               if(abilityHit(target,equipmentPart104(sourceSkill,"net_hit",scale),nativeAbilityNumber(sourceSkill,kind,"cast_2",1),effect)) abilityMark(target,"aim",nativeAbilityNumber(sourceSkill,kind,"cast_4",2),scale);
               checkMove(false,nativeAbilityNumber(sourceSkill,kind,"cast_5",250));
               break;
            case "caitlyn_c":
               primary=abilityMarkedTarget("aim",nativeAbilityNumber(sourceSkill,kind,"cast_1",1000),"farthest"); if(!primary) return false; target=primary;
               for each(other in abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_3",200),primary,-1,true,"nearest",[primary]))
               {
                  if(team==1 ? other.pos>primary.pos && other.pos<pos : other.pos<primary.pos && other.pos>pos) {target=other; break;}
               }
               addBuff("hitup",nativeAbilityNumber(sourceSkill,kind,"cast_8",1),nativeAbilityNumber(sourceSkill,kind,"cast_9",800)*orangeFourStatBuffMultiplier); marked=target.abilityHasMark(this,"aim");
               if(abilityHit(target,marked ? equipmentPart104(sourceSkill,"marked_shot",nativeAbilityNumber(sourceSkill,kind,"cast_11",5)) : nativeAbilityNumber(sourceSkill,kind,"cast_12",4),nativeAbilityNumber(sourceSkill,kind,"cast_13",1),effect) && marked) delete target.abilityState["mark_aim_"+abilityIndex];
               break;
            case "karthus_n":
               enemies=abilityEnemies(600); if(!enemies.length) return false;
               targets=[enemies[0]].concat(abilityEnemies(200,enemies[0],2,false,"nearest",[enemies[0]]));
               for each(target in targets) abilityHit(target,0.875*scale*(targets.length==1 ? equipmentPart104(sourceSkill,"isolated_hit",2) : 1),2,effect);
               break;
            case "karthus_c":
               for each(target in abilityAllEnemies()) abilityHit(target,2.75*(1+(target.hp<target.hpMax*0.4 ? equipmentPart104(sourceSkill,"requiem_finish",0.4) : 0)),2,effect);
               break;
            case "kaelthas_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",600)); if(!enemies.length) return false; target=enemies[0];
               if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_2",0.8)*scale,nativeAbilityNumber(sourceSkill,kind,"cast_3",2),effect) && target.hp>0 && !target.buffs.purify && !target.s2AnnieImmune())
               {
                  target.abilityState["bomb_"+abilityIndex]={abyssRelicContext104:abyssCaptureContext104(this),owner:this,until:target.abilitySerial+nativeAbilityNumber(sourceSkill,kind,"cast_6",1),coefficient:equipmentPart104(sourceSkill,"bomb_burst",nativeAbilityNumber(sourceSkill,kind,"cast_7",1.2))*scale,manualDamageMultiplier:manualDamageMultiplier,debuff:true};
                  target.s2AnnieStatus("bomb");
               }
               break;
            case "kaelthas_c":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",700)); if(!enemies.length) return false; primary=enemies[0];
               for each(target in [primary].concat(abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_2",300),primary,nativeAbilityNumber(sourceSkill,kind,"cast_3",3),false,"nearest",[primary])))
               {
                  state=target.abilityState["bomb_"+abilityIndex];
                  target.abilityState.bombConsumeOwner=this;
                  landed=abilityHit(target,state ? equipmentPart104(sourceSkill,"consume_bomb",nativeAbilityNumber(sourceSkill,kind,"cast_6",4)) : nativeAbilityNumber(sourceSkill,kind,"cast_7",2.2),nativeAbilityNumber(sourceSkill,kind,"cast_8",2),effect);
                  delete target.abilityState.bombConsumeOwner;
                  if(landed && state) delete target.abilityState["bomb_"+abilityIndex];
               }
               break;
            case "aoxing_n":
               enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_0",650)); if(!enemies.length) return false; primary=enemies[0]; targets=[primary]; marked=false;
               for(i=0;i<nativeAbilityNumber(sourceSkill,kind,"cast_3",3);i++)
               {
                  var bounceSource:Avatar = i == 0 ? this : primary;
                  if(i>0) { enemies=abilityEnemies(nativeAbilityNumber(sourceSkill,kind,"cast_6",300),primary,nativeAbilityNumber(sourceSkill,kind,"cast_7",1),false,"nearest",targets); if(!enemies.length) break; primary=enemies[0]; targets.push(primary); }
                  if(abilityHit(primary,(i==0 ? nativeAbilityNumber(sourceSkill,kind,"cast_11",1.4) : equipmentPart104(sourceSkill,"lightning_bounce",nativeAbilityNumber(sourceSkill,kind,"cast_12",1)))*scale,nativeAbilityNumber(sourceSkill,kind,"cast_13",2),effect,0,bounceSource) && primary.getType()==1 && !primary.isManualSummonUnit) marked=true;
               }
               if(marked) { abilityState.thunder=Math.min(nativeAbilityNumber(sourceSkill,kind,"cast_16",3),int(abilityState.thunder)+nativeAbilityNumber(sourceSkill,kind,"cast_17",1)); abilityFeedback("风暴电荷："+int(abilityState.thunder)+"/3","FX_A_1114_MAGIC"); }
               break;
            case "aoxing_c":
               count=int(abilityState.thunder); abilityState.thunder=0; if(count > 0) abilityFeedback("释放风暴电荷："+count,"FX_A_1114_MAGIC"); i=-1; targets=[];
               for(var lane:int=0;lane<3;lane++)
               {
                  enemies=abilityCandidates(otherTeam,lane,pos,GameMapConfig.LINE_POS,-1,true,"front");
                  if(enemies.length>i) {i=enemies.length; targets=abilityCandidates(otherTeam,lane,pos,GameMapConfig.LINE_POS,nativeAbilityNumber(sourceSkill,kind,"cast_9",4),false,"front");}
               }
               i=0;
               for each(target in targets) if(abilityHit(target,nativeAbilityNumber(sourceSkill,kind,"cast_12",1.8)+equipmentPart104(sourceSkill,"storm_charge",nativeAbilityNumber(sourceSkill,kind,"cast_13",0.4))*count,nativeAbilityNumber(sourceSkill,kind,"cast_14",2),effect) && count==nativeAbilityNumber(sourceSkill,kind,"cast_15",3) && target.getType()==1 && !target.isManualSummonUnit && i++<nativeAbilityNumber(sourceSkill,kind,"cast_17",2)) abilityControl(target,"stun",nativeAbilityNumber(sourceSkill,kind,"cast_19",1));
               break;
            default: return false;
         }
         return true;
         }
         finally
         {
            if(context && context.owner === this)
            {
               if(hadManualFactor) context.manualDamageMultiplier = previousManualFactor;
               else delete context.manualDamageMultiplier;
               if(hadManualEffectFactor) context.manualEffectMultiplier = previousManualEffectFactor;
               else delete context.manualEffectMultiplier;
            }
         }
      }

      private function executeSantaSkin(kind:String, effect:String, sourceSkill:*) : Boolean
      {
         var targets:Array = kind == "santa_n" ? abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,-1) : abilityAllEnemies();
         if(targets.length == 0 || hp <= 0) return false;
         if(kind == "santa_n")
         {
            // Lock this cast's repeat count before any of its hits can kill.
            var count:int = 1+int(int(abilityState.santaKills)/2);
            for(var i:int = 0;i < count;i++)
            {
               targets = abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,-1);
               if(targets.length == 0 || hp <= 0) break;
               var ticket:int = Random.getRandom(targets.length);
               var victim:Avatar = targets[((ticket % targets.length)+targets.length)%targets.length] as Avatar;
               abilityHit(victim,Number(sourceSkill.getNativeAction()[4]),2,effect);
               abilityState.santaStacks = int(abilityState.santaStacks)+1;
               abilityFeedback("邪恶攻击 "+int(abilityState.santaStacks)+"层","FX60_STRONG",16744448);
            }
         }
         else
         {
            var oldHit104:Number = Number(abilityState.veigarCastHit || 0);
            abilityState.veigarCastHit = oldHit104+10000*Number(sourceSkill.getNativeSetting("manualFixedScale104",1));
            try {
               for each(var target:Avatar in targets)
                  if(abilityHit(target,0.3,3,effect) && target.hp > 0) abilityControl(target,"stun",1);
            } finally { abilityState.veigarCastHit = oldHit104; }
         }
         return true;
      }

      private function executeNurseSkin(kind:String, sourceSkill:*) : Boolean
      {
         if(hp <= 0 || !GameMap.currentMap) return false;
         var allies:Vector.<Avatar> = GameMap.currentMap.getAliveList(team);
         if(allies.length == 0) return false;
         var target:Avatar;
         var amount:int;
         var healingRate:Number = Number(sourceSkill.getNativeSetting("manualEffectMultiplier",1));
         if(!isFinite(healingRate) || healingRate <= 0) healingRate = 1;
         if(kind == "nurse_n")
         {
            for each(target in allies) if(target.hp > 0) target.addBuff("purify",1);
            amount = Tools.toInt(Tools.toInt(getDamage()*(1+checkTalent(1)))*Number(sourceSkill.getNativeAction()[4])*healingRate*heroSkillOutputRate104());
            for each(target in allies)
            {
               if(target.hp <= 0) continue;
               target.injured(amount,1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this);
            }
         }
         else
         {
            var primary:Avatar = allies[0];
            for each(target in allies)
               if(Number(target.hp)/Math.max(1,target.hpMax) < Number(primary.hp)/Math.max(1,primary.hpMax)) primary = target;
            amount = Tools.toInt(hpMax*0.5*healingRate*heroSkillOutputRate104());
            // Keep both entries when the most injured target is this caster.
            for each(target in [primary,this])
            {
               if(hp <= 0) break;
               if(target.hp <= 0) continue;
               target.addBuff("purify",1);
               target.addBuff("bless",1);
               target.injured(amount,1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this);
            }
         }
         return true;
      }

      private function queueNurseHealing(amount:int, overheal:int = 0) : void
      {
         if(hp <= 0 || amount <= 0 || !skillB || !skillB.skills || !skillB.skills.length || skillB.skills[0][0] != "nurse_healing") return;
         if(!abilityState.nursePending) abilityState.nursePending = [];
         overheal = Math.max(0,Math.min(amount,overheal));
         var overflowRate:Number = skillB.skills[0].length > 2 ? Number(skillB.skills[0][2]) : 1;
         abilityState.nursePending.push(Tools.toInt((amount-overheal)*Number(skillB.skills[0][1])+overheal*overflowRate));
         if(abilityState.nurseBusy) return;
         abilityState.nurseBusy = true;
         try
         {
            while(abilityState.nursePending.length > 0 && hp > 0)
            {
               var damage:int = int(abilityState.nursePending.shift());
               if(damage <= 0) continue;
               var context:Object = beginAbilityAttack(this,"passive");
               try
               {
                  for each(var target:Avatar in abilityAllEnemies())
                  {
                     if(target.line != line) continue;
                     if(hp <= 0) break;
                     // Fixed true damage enters after AP/armor/miss/crit math.
                     target.injured(damage,1,DisplayTools.getAttrs("FX_S9150_TRUE"),3,this,false,this);
                  }
               }
               finally { endAbilityAttack(context); }
            }
         }
         finally
         {
            abilityState.nurseBusy = false;
            if(hp <= 0) abilityState.nursePending = [];
         }
      }

      private function queueSantaKill() : void
      {
         if(hp <= 0 || !skillB || !skillB.skills || !skillB.skills.length || skillB.skills[0][0] != "santa_kill") return;
         abilityState.santaStacks = int(abilityState.santaStacks)+int(skillB.skills[0][1]);
         abilityState.santaKills = int(abilityState.santaKills)+int(skillB.skills[0][2]);
      }

      private function executePolarSkin(kind:String, effect:String, sourceSkill:*) : Boolean
      {
         var targets:Array;
         var target:Avatar;
         if(kind == "polar_n")
         {
            targets = abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,-1);
            if(targets.length == 0) return false;
            var params:Array = sourceSkill.getNativeAction();
            if(Number(params[4])>0) addBuff("critup",1,Number(params[4]));
            var reduction:Number = Number(params[5]);
            for each(target in targets)
               if(abilityHit(target,Number(params[6]),1,effect) && target.hp > 0)
                  abilityControl(target,"sunder",1,reduction/(1-reduction));
            return true;
         }
         targets = abilityAllEnemies();
         if(targets.length == 0) return false;
         var primary:Avatar = targets[0] as Avatar;
         for each(target in targets) if(target.getDamage() > primary.getDamage()) primary = target;
         targets = abilityCandidates(otherTeam,primary.line,primary.pos,300,-1);
         var oldHit:Number = abilityState.polarCastHit != null ? Number(abilityState.polarCastHit) : 0;
         abilityState.polarCastHit = oldHit+50000*Number(sourceSkill.getNativeSetting("manualFixedScale104",1));
         try
         {
            for each(target in targets)
            {
               if(abilityHit(target,3,2,effect) && target.hp > 0)
               {
                  abilityControl(target,"curse",1);
                  var polarRow:Object=GlobalData.$mConfig_skill[sourceSkill.skillSetData.id];
                  abilityControl(target,"stun",polarRow && polarRow.sixStarPolarStun105 ? int(polarRow.sixStarPolarStun105) : 1);
               }
            }
         }
         finally { abilityState.polarCastHit = oldHit; }
         return true;
      }

      private function polarBasicAttack() : void
      {
         if(hp <= 0 || !skillB || !skillB.skills || !skillB.skills.length || skillB.skills[0][0] != "polar_basic") return;
         var round:int = GameMap.currentMap ? GameMap.currentMap.roundNum : 0;
         if(abilityState.polarRound == null)
         {
            abilityState.polarRound = round;
            abilityState.polarCount = 0;
            abilityState.polarBasic = false;
         }
         var elapsed:int = round-int(abilityState.polarRound);
         if(elapsed > 0)
         {
            var lost:int = elapsed-(abilityState.polarBasic ? 1 : 0);
            abilityState.polarCount = Math.max(0,int(abilityState.polarCount)-lost);
            abilityState.polarRound = round;
            abilityState.polarBasic = false;
         }
         var policy:Array = skillB.skills[0];
         if(!abilityState.polarBasic) abilityState.polarCount = Math.min(int(policy[2]),int(abilityState.polarCount)+1);
         abilityState.polarBasic = true;
         var targets:Array = abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,-1);
         if(targets.length == 0) return;
         var ticket:int = Random.getRandom(targets.length);
         var target:Avatar = targets[((ticket % targets.length)+targets.length)%targets.length] as Avatar;
         var context:Object = beginAbilityAttack(this,"passive");
         try { abilityHit(target,Number(policy[1])*int(abilityState.polarCount),1,"FX_S9004_ARC"); }
         finally { endAbilityAttack(context); }
      }

      private function abilityAllEnemies() : Array
      {
         var result:Array = [];
         if(!GameMap.currentMap) return result;
         for each(var enemy:Avatar in GameMap.currentMap.getAliveList(otherTeam))
            if(enemy && enemy.hp > 0) result.push(enemy);
         return result;
      }

      public function addPurifyCharges(count:int) : void
      {
         if(count < 1 || hp <= 0) return;
         removeAllDebuff();
         var previous:Buff = buffs["purify"] as Buff;
         count = Math.max(count,previous ? int(previous.value) : 0);
         removeBuff("purify");
         // Positive purify value stores charges; ordinary purify keeps value 0.
         var guard:Buff = new Buff("purify",0,count);
         buffs["purify"] = guard;
         if(GameMapLayer.gl) GameMapLayer.gl.delayCall(showBuff,GameMap.actionDelay,guard);
         abilityFeedback("净化（"+count+"层）","FX_S9150_PURIFY",10526975);
      }

      private function executeCatSkin(kind:String, scale:Number, effect:String, sourceSkill:*) : Boolean
      {
         var context:Object = currentAbilityAttack();
         if(!context || context.owner !== this || hp <= 0) return false;
         var targets:Array;
         var primary:Avatar;
         var target:Avatar;
         var wave:int;
         if(kind == "cat_n")
         {
            if(abilityState.root) return false;
            targets = abilityCandidates(otherTeam,line,pos,GameMapConfig.LINE_POS,3,false,"front");
            if(targets.length == 0) return false;
            primary = targets[0] as Avatar;
            var params:Array = sourceSkill.getNativeAction();
            addBuff("hitup",2,Number(params[4]));
            abilityDash(primary);
            var before:Number = Number(context.damage);
            for each(target in targets) abilityHit(target,Number(params[5]),3,effect);
            abilityHit(primary,Number(params[6]),3,effect);
            var restore:int = Tools.toInt(Math.max(0,Number(context.damage)-before)*Number(params[7])*heroSkillOutputRate104());
            if(hp > 0 && restore > 0) injured(restore,1,null,4,null,false,this);
            return true;
         }
         if(abilityAllEnemies().length == 0) return false;
         addPurifyCharges(2);
         context.catCaptainCapture = true;
         context.catCrits = 0;
         try
         {
            for(wave=0;wave<6;wave++)
            {
               targets = abilityAllEnemies();
               for each(target in targets) abilityHit(target,0.3,3,effect);
            }
         }
         finally { context.catCaptainCapture = false; }
         flushParallelVisualBatch();
         if(hp > 0 && int(context.catCrits) > 0) addBuff("strong",2,0.03*int(context.catCrits));
         return true;
      }

      private function queueCatSkinKill() : void
      {
         if(hp <= 0 || !skillB || !skillB.skills || !skillB.skills.length || skillB.skills[0][0] != "cat_passive") return;
         var round:int = GameMap.currentMap ? GameMap.currentMap.roundNum : 0;
         if(abilityState.catKillRound == null || int(abilityState.catKillRound) != round)
         {
            abilityState.catKillRound = round;
            abilityState.catKillCount = 0;
            abilityState.catKillPending = 0;
         }
         ++abilityState.catKillPending;
         if(abilityState.catKillBusy) return;
         abilityState.catKillBusy = true;
         var policy:Array = skillB.skills[0];
         try
         {
            while(int(abilityState.catKillPending) > 0 && int(abilityState.catKillCount) < int(policy[3]) && hp > 0)
            {
               --abilityState.catKillPending;
               ++abilityState.catKillCount;
               var context:Object = beginAbilityAttack(this,"passive");
               try
               {
                  for(var strike:int=0;strike<int(policy[2]);strike++)
                  {
                     var targets:Array = abilityAllEnemies();
                     if(targets.length == 0) break;
                     var ticket:int = Random.getRandom(targets.length);
                     var victim:Avatar = targets[((ticket % targets.length)+targets.length)%targets.length] as Avatar;
                     abilityHit(victim,Number(policy[1]),3,"FX_S9130_COMBO");
                  }
               }
               finally { endAbilityAttack(context); }
            }
         }
         finally
         {
            abilityState.catKillBusy = false;
            abilityState.catKillPending = 0;
         }
      }

      public function get isManualSummonUnit() : Boolean
      {
         return buffs && buffs["summon"] != null;
      }


      public static const TEST_DAMAGE_RATE:Number = 1;

      public static var MIN_DAMAGE_RATE:Number = 0.1;

      public static function get REAL_DAMAGE_RATE() : Number { return Number(damageAttack104()[1]); }
      public static function set REAL_DAMAGE_RATE(value:Number) : void { configuredTrueDamageRate104 = value; }

      public static var SIGN_DAMAGE_RATE:Number = 1.5;

      public static var CRIT_RATE:Number = 2;

      public static var MISS_POINT:int = 20;

      public static var CRIT_POINT:int = 20;

      public static var MISS_MAX:int = 60;

      public static var CRIT_MAX:int = 80;

      public static var DANGEROUS_RATE:Number = 0.5;

      public static var POWER_RATE:Number = 1e-8;

      public static var POWER_HP:Number = 0.29;

      public static var POWER_DAMAGE:Number = 1.5;

      public static var POWER_DE_PH:Number = 1.8;

      public static var POWER_DE_MA:Number = 1.8;

      public static var POWER_SPEED_RANGE:int = 1000;

      public static var POWER_SKILL_0_STAR:Number = 0.1;

      public static var POWER_SKILL_0_LV:Number = 0.1;

      public static var POWER_SKILL_1_STAR:Number = 0.5;

      public static var PITH_MAX:int = 99999;

      public static var PITH_POINT:int = 10;

      public static const RES_SIDE:int = 94;

      public static const RES_STAND_SCALE:Number = 0.4;

      public static const MISS_COLOR:uint = 13684944;

      public static const HP_BIG:int = 5;

      public static const HP_LINE:int = 1000;

      public static const HP_HIDE_LINE:int = 10000;

      public static const HP_HIDE_BIG:int = 50000;

      public static const HP_HIDE_GOD:int = 250000;

      public static const ACTION_TIME:Number = 0.3;

      public static const AUTO_POS_TIME:Number = 0.6;

      public static const SHOW_TIME:Number = 0.5;

      public static const SKILL_TIME:Number = 0.5;

      public static const WAIT_TIME:Number = 0.4;

      public static const ACTION_SHORTCUT:Number = 0.08;

      public static const MOVE_TIME:Number = 0.4;

      public static const SWING_TIME:Number = 0.12;

      public static const HIT_TIME:Number = 0.2;

      public static const RE_LINE_TIME:Number = 2.8;

      public static const DEAD_TIME:Number = 0.5;

      public static const MISS_TIME:Number = 0.2;

      public static const ROTATION_TIME:Number = 0.3;

      public static const ATTACK_TIME:Number = 0.25;

      public static const AOE_TIME:Number = 0.15;

      public static const POISON_TIME:Number = 1;

      public static const BLESS_TIME:Number = 1;

      public static const PRE_TIME:Number = 0.05;

      public static const MG_MOVE_TIME:Number = 1.2;

      public static const CLOSE_LINE_TIME:Number = 2;

      public static const POP_STR_TIME:Number = 0.5;

      public static const POP_STR_LONG_TIME:Number = 0.75;

      public static const POP_STR_LONG_LONG_TIME:Number = 1;

      public static const POP_STR_SIZE:int = 35;

      public static const POP_STR_SMALL_SIZE:int = 25;

      public static const POP_STR_BIG_SIZE:int = 45;

      public static const DEAD_FLY_DELAY:Number = 0.4;

      public static const DEAD_FLY_RANDOM_X:int = 100;

      public static const DEAD_FLY_RATE:Number = 0.2;

      public static const DEAD_FLY_SPEED:int = 1000;

      public static const DEAD_FLY_FADE_TIME:Number = 0.1;

      public static const DEAD_FLY_NUM:int = 3;

      public static const DEAD_FLY_SCALE:Number = 1.1;

      public static const MISS_X:int = 40;

      public static const HIT_Y:int = 20;

      public static const ATTACK_Y:int = 25;

      public static const MOVE_POS:int = 400;

      public static const FIGHT_RES_SCALE:Number = 1;

      public static const SUMMON_RES_SCALE:Number = 0.8;

      public static const BOSS_RES_SCALE:Number = 1.3;

      public static const ACTION_SCALE:Number = 1.2;

      public static const BOUNCE_SCALE:Number = 1.15;

      public static const MISS_SCALE:Number = 0.9;

      public static const MOVE_ROTATION:Number = 0.1;

      public static const SWING_ROTATION:Number = 0.5;

      public static const SWING_TIMES:int = 3;

      public static var index:int = 0;

      public var isShowLock:Boolean = false;

      public var dragAvatar:Avatar;

      public var m_icon:Image;

      private var mLimitBreakEdges:Vector.<Image> = new Vector.<Image>();

      public var isOthers:Boolean;

      public var actionNum:int;

      public var id:String;

      public var isLocked:Boolean;

      public var isNPC:Boolean;

      public var indexID_s:int = 0;

      public var team:int;

      public var line:int;

      private var abilityPosition:int;
      public function get pos() : int { return abilityPosition; }
      public function set pos(value:int) : void
      {
         if(value != abilityPosition && abilityState) delete abilityState.channel;
         abilityPosition = value;
      }

      public var offset:Number = 0;

      public var offsetAim:Number = 0;

      public var hp:int;

      public var hpMax:int;

      public var ap:int;

      public var dePh:int;

      public var deMa:int;

      public var speed:int;

      public var range:int;

      public var hit:int;

      public var flee:int;

      public var crit:int;

      public var tough:int;

      public var isLeader:Boolean;

      public var isBoss:Boolean;

      public var isDrop:Boolean;

      public var dropRate:Number;

      public var dropId:String;

      public var talent:Talent;

      public var skill0:SkillSet;

      public var skill1:SkillSet;

      public var skill2:SkillSet;

      public var skillB:SkillSet;

      public var currentSkillKillContext:Object;
      public var manualFocusTarget:Avatar;
      public var manualSkillDots:Object;
      private var manualDotSerial:uint = 0;
      public var manualBattleStacks:Object;
      public var manualTimedStacks:Array;
      public var manualOwnerActionSerial:int = 0;
      private static var modEventDepth:int = 0;
      private static var modEventBudget:int = 0;

      public function hasModBuff(kind:String) : Boolean
      {
         if(kind == "root" && abilityState && abilityState.root) return true;
         if(kind == "timed_bless") return buffs && buffs["bless"] && Number(buffs["bless"].value) > 0;
         return buffs && buffs[kind] != null;
      }

      public function emitModEvent(event:String,source:Avatar = null,target:Avatar = null,amount:Number = 0,overheal:Number = 0) : Boolean
      {
         if(event=="death") sixBatchDeath105(source);
         if(event=="crit" && skillB && sixBatchPassive105("yasuo")) skillB.cooldown();
         yasuoEvent104(event,source,target,amount);
         kaisaEvent104(event,source,target);
         skin2Event(event,source,target,amount,overheal);
         if(skillB && skillB.skills && skillB.skills.length ||
            abilityState.highlander && abilityState.highlander.extra)
         {
            sixStarCombatEvent105(event,target,amount,overheal);
            sixFollowupEvent105(event,source,target,overheal);
         }
         if(!skillB || !skillB.isModEffectSequence() || !GameMap.currentMap) return false;
         var row:Object = GlobalData.$mConfig_skill[skillB.skillSetData.id];
         var gate:Object = row ? row.modCondition : null;
         if(!gate || gate.kind != "event" || (gate.event != event && !(gate.reviewDashResponse104 && event == "dodge")) || (hp <= 0 && event != "death")) return false;
         if(abilityState.modEventBusy || modEventDepth >= 8 || (modEventDepth > 0 && gate.allowChain !== true)) return false;
         var other:Avatar = source === this ? target : source;
         if(gate.relation == "self" && other !== this) return false;
         if(gate.relation == "ally" && (!other || other.team != team || other === this)) return false;
         if(gate.relation == "enemy" && (!other || other.team == team)) return false;
         if(gate.unitType == "hero" && (!other || other.getType() != 1 || other.isManualSummonUnit)) return false;
         if(gate.unitType == "summon" && (!other || !other.isManualSummonUnit && other.getType() != 2)) return false;
         if(gate.minAmount != null && amount < Number(gate.minAmount)) return false;
         if(gate.hpBelow != null && Number(Math.max(0,hp))/Math.max(1,hpMax) > Number(gate.hpBelow)) return false;
         if(gate.requiredBuff && !hasModBuff(String(gate.requiredBuff))) return false;
         if(gate.absentBuff && hasModBuff(String(gate.absentBuff))) return false;
         if(gate.otherHpBelow != null && (!other || Math.max(0,other.hp)/Math.max(1,other.hpMax) > Number(gate.otherHpBelow))) return false;
         if(gate.otherHpNotFull105 && (!other || other.hp >= other.hpMax)) return false;
         if(gate.otherRequiredBuff && (!other || !other.hasModBuff(String(gate.otherRequiredBuff)))) return false;
         var nearbyRadius:Number = gate.nearbyRadius == null ? 600 : Number(gate.nearbyRadius);
         var nearbyFriend:int = 0;
         var nearbyFoe:int = 0;
         var nearbySummon:int = 0;
         var nearby:Avatar;
         for each(nearby in GameMap.currentMap.getAliveList(team))
         {
            if(nearby === this || nearby.line != line || Math.abs(nearby.pos-pos) > nearbyRadius) continue;
            ++nearbyFriend;
            if(nearby.isManualSummonUnit || nearby.getType() == 2) ++nearbySummon;
         }
         for each(nearby in GameMap.currentMap.getAliveList(team == 1 ? 2 : 1))
         {
            if(nearby.line == line && Math.abs(nearby.pos-pos) <= nearbyRadius) ++nearbyFoe;
         }
         if(nearbyFriend < int(gate.nearbyAllies || 0) || nearbyFoe < int(gate.nearbyEnemies || 0) || nearbySummon < int(gate.nearbySummons || 0)) return false;
         if(gate.reviewDashResponse104 && abilityState.reviewDashReady104 !== true) return false;
         var ownTurn:int = manualOwnerActionSerial;
         var readyTurn:int = abilityState.modEventReady == null ? skillB.skillSetData.warmup : int(abilityState.modEventReady);
         if(ownTurn < readyTurn) return false;
         var round:int = GameMap.currentMap.roundNum;
         if(abilityState.modEventRound == null || int(abilityState.modEventRound) != round)
         {
            abilityState.modEventRound = round; abilityState.modEventCount = 0;
         }
         var limit:int = gate.maxPerRound == null ? 1 : int(gate.maxPerRound);
         if(limit > 0 && int(abilityState.modEventCount) >= limit) return false;
         var every:int = gate.everyEvents == null ? 1 : int(gate.everyEvents);
         if(every > 1)
         {
            abilityState.modFilteredEvents = int(abilityState.modFilteredEvents || 0)+1;
            if(int(abilityState.modFilteredEvents) < every) return false;
         }
         var previous:Object = skillB.modEventContext;
         skillB.modEventContext = {event:event,source:source,target:target,amount:Math.max(0,amount),overheal:Math.max(0,overheal)};
         if(!skillB.canModEventCast()) { skillB.modEventContext = previous; return false; }
         if(modEventDepth == 0) modEventBudget = 64;
         if(modEventBudget <= 0) { skillB.modEventContext = previous; return false; }
         --modEventBudget; ++modEventDepth;
         if(gate.reviewDashResponse104) abilityState.reviewDashReady104 = false;
         abilityState.modEventBusy = true;
         abilityState.modEventCount = int(abilityState.modEventCount)+1;
         abilityState.modEventReady = ownTurn+skillB.skillSetData.cooldown;
         abilityState.modFilteredEvents = 0;
         try
         {
            skillB.useSkill();
            if(gate.sixStarRefreshNormal105 && skill0)
            {
               skill0.m_cooldownNum=-1;
               skill0.abilityCooldownOverride=-1;
            }
         }
         finally { abilityState.modEventBusy = false; --modEventDepth; skillB.modEventContext = previous; }
         return true;
      }

      public function emitModTurnEnd() : Boolean
      {
         if(abilityState.modEventEndSerial != null && int(abilityState.modEventEndSerial) == manualOwnerActionSerial) return false;
         abilityState.modEventEndSerial = manualOwnerActionSerial;
         return emitModEvent("turn_end",this,this);
      }

      public var manualSummonFamilies:Object;
      public var manualAttackRangeOverride:Number = NaN;
      public var manualSkillDamageCapture:Object;
      public var manualLethalFloor:Object;
      public var currentSkillHitContext:Object;

      public var buffs:Object;

      public var lv:int = 0;

      public var exp:int = 0;

      public var slv:int = 0;

      public var loveExp:int = 0;

      public var morph:int;

      public var hpP:int;

      public var apP:int;

      public var dePhP:int;

      public var deMaP:int;

      public var phase:int;

      public var limitBreak:int;

      public var cultureSchema:String = "";

      public var equips:Vector.<Equip>;

      protected var m_buff:Sprite;

      protected var m_avatarRes:Sprite;

      protected var m_fightRes:Sprite;

      protected var m_fightBg:Sprite;

      protected var m_fightRange:Sprite;

      private var rangePreviewQueued:Boolean = false;

      private var rangeMoveEndsAt:Number = 0;

      public var m_actionNum:Sprite;

      protected var m_tf:TextField;

      protected var m_drop:DisplayObject;

      public var mDestiny:Object;

      public var mDNdata:Object;

      public var mData:Object;

      private var _checkListmyCurrHp:Array;

      private var _checkListotherCurrHp:Array;

      public var mBloodSpr:ProgressBar;

      private var tryndUndyingActive:Boolean = false;

      private var tryndUndyingRounds:int = 0;

      public var manualActionTypeOverride:int = -1;

      public function Avatar(param1:String, param2:Object = null, param3:Boolean = false)
      {
         super();
         // Battle aliases describe the active context (owned/enemy/assist).
         // Keep the instance id in param2; never derive its definition from it.
         if(param2 != null && !(param2 is Array) && param2.aid != null && param2.base_aid != null)
         {
            param1 = String(param2.aid);
         }
         param1 = param1.replace(".","");
         var _loc4_:int = param1.indexOf("|");
         if(!param2 && !param3)
         {
            param2 = getUserAvatarObj(param1);
         }
         if(_loc4_ > -1)
         {
            id = param1;
            param1 = param1.slice(0,_loc4_);
            m_data = AvatarManager.getOnlyExample().getData(param1);
         }
         else
         {
            _loc4_ = param1.indexOf("-");
            if(_loc4_ > -1)
            {
               param1 = param1.slice(0,_loc4_);
            }
            m_data = AvatarManager.getOnlyExample().getData(param1);
         }
         init(param2);
      }

      public static function getUserAvatarObj(param1:String = "0", param2:Object = null) : Object
      {
         var _loc3_:Object = null;
         var _loc4_:String = null;
         var _loc5_:Object = {};
         if(GlobalData.$isExploration)
         {
            _loc3_ = GlobalData.$exploration_select_avatar;
         }
         else
         {
            if(!param2)
            {
               param2 = GlobalData.$userData;
            }
            if(param2)
            {
               _loc3_ = param2.avatars;
            }
         }
         if(param1.indexOf("|") > -1)
         {
            param1 = param1.split("|")[1];
         }
         if(Tools.strIsNumber(param1))
         {
            for(_loc4_ in _loc3_)
            {
               if(_loc4_.split("|")[1] == param1)
               {
                  _loc5_ = Tools.clone(_loc3_[_loc4_]);
                  _loc5_.aid = _loc4_;
                  return _loc5_;
               }
            }
         }
         return null;
      }

      public static function getPosPer(param1:int, param2:int = 1) : Number
      {
         var _loc3_:Number = param1 / GameMapConfig.LINE_POS;
         _loc3_ = Math.round(_loc3_ * 100) / 100;
         return param2 == 1 ? 1 - _loc3_ : _loc3_;
      }

      public static function getColorMatrixFilter(param1:int = 1) : ColorMatrixFilter
      {
         var _loc3_:Array = null;
         var _loc2_:ColorMatrixFilter = new ColorMatrixFilter();
         param1 = 3;
         if(param1 == 0)
         {
            _loc3_ = [1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0];
         }
         else if(param1 == -1)
         {
            _loc3_ = [0.95,0,0,0,0,0,1.5,0,0,0,0,0,1.05,0,0,0,0,0,1,0];
         }
         else if(param1 == 1)
         {
            _loc3_ = [0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0];
         }
         else if(param1 == 2)
         {
            _loc3_ = [0.9,0.1,0.2,0,0,0.1,0.9,0.2,0,0,0.2,0.3,0.5,0,0,0,0,0,1,0];
         }
         else if(param1 == 3)
         {
            _loc3_ = [1.1,-0.1,-0.1,0,0,-0.1,1.3,-0.1,0,0,-0.1,-0.1,1.1,0,0,0,0,0,1,0];
         }
         _loc2_.matrix = Vector.<Number>(_loc3_);
         _loc2_.adjustContrast(-0.1);
         _loc2_.adjustSaturation(0.2);
         _loc2_.adjustHue(-0.15);
         return _loc2_;
      }

      public static function getPhaseMax(param1:String) : int
      {
         var _loc5_:Array = null;
         var _loc3_:Object = null;
         var _loc2_:int = int(param1.slice(2,3));
         var _loc4_:int = int(param1.split("_")[2]);
         var _loc6_:Array = GlobalData.$mConfig_simple.phase_config;
         if(_loc2_ == 1)
         {
            _loc3_ = _loc6_[0];
         }
         else
         {
            _loc3_ = _loc6_[1];
         }
         _loc5_ = _loc3_[String(_loc4_)];
         if(_loc5_)
         {
            return _loc5_[1];
         }
         return 0;
      }

      // BEGIN DAMAGE FORMULA 104
      private static var damageChoiceLoaded104:Boolean = false;
      private static var legacyDamageChoice104:Boolean = false;
      private static var damageBattleStarted104:Boolean = false;
      private static var legacyBattleDamage104:Boolean = false;
      private static var configuredTrueDamageRate104:Number = NaN;
      private static const DAMAGE_CHOICE_KEY104:String = "lal_legacy_damage_formula_104";
      private static const DEFAULT_DAMAGE_RULES104:Object = {
         reduction_exponent:1.5,defense_attack_midpoint:0.7,miss_slope:40,crit_slope:60,true_skill_rate:0.8,
         attack_overrides:{"1":0.5,"4":8,"5":15,"6":35,"7":60,"15":0,"16":0,"21":0.66}
      };

      public static function useLegacyDamage104() : Boolean
      {
         if(!damageChoiceLoaded104)
         {
            legacyDamageChoice104 = LocalStore.getItemObj(DAMAGE_CHOICE_KEY104) === true;
            damageChoiceLoaded104 = true;
         }
         return legacyDamageChoice104;
      }

      public static function setLegacyDamage104(enabled:Boolean) : void
      {
         LocalStore.setItemObj(DAMAGE_CHOICE_KEY104,enabled);
         legacyDamageChoice104 = enabled;
         damageChoiceLoaded104 = true;
      }

      public static function beginDamageRules104() : void
      {
         // One battle keeps one model even if a preference changes mid-replay.
         legacyBattleDamage104 = useLegacyDamage104();
         damageBattleStarted104 = true;
      }

      public static function ratioDamage104() : Boolean
      {
         return !(damageBattleStarted104 ? legacyBattleDamage104 : useLegacyDamage104());
      }

      private static function damageRuleNumber104(key:String) : Number
      {
         var rules:Object = GlobalData.$mConfig ? GlobalData.$mConfig.combat_rules : null;
         var value:Number = rules && rules[key]!=null ? Number(rules[key]) : Number(DEFAULT_DAMAGE_RULES104[key]);
         return isFinite(value) && value>0 ? value : Number(DEFAULT_DAMAGE_RULES104[key]);
      }

      public static function damageAttack104() : Array
      {
         var attack:Array = GlobalData.$mConfig_simple.attack.concat();
         if(isFinite(configuredTrueDamageRate104)) attack[1] = configuredTrueDamageRate104;
         if(!ratioDamage104()) return attack;
         var rules:Object = GlobalData.$mConfig ? GlobalData.$mConfig.combat_rules : null;
         var overrides:Object = rules && rules.attack_overrides ? rules.attack_overrides : DEFAULT_DAMAGE_RULES104.attack_overrides;
         for(var key:String in overrides) attack[int(key)] = Number(overrides[key]);
         return attack;
      }

      private static function statGrowth105(points:Number) : Number
      {
         return Math.log(1 + Math.max(0,points)/10000) / Math.log(11);
      }

      private static function opposedPower105(advantage:Number) : Number
      {
         return 1 + 0.6 * statGrowth105(advantage);
      }

      private static function opposedCritChance105(delta:Number) : Number
      {
         if(delta <= 0) return 15 * Math.pow(1-delta/10000,-Math.log(3)/Math.log(11));
         if(delta >= 20000) return 60 - 45 / (2 * opposedPower105(delta) - 1);
         // Quintic matching the value, slope and curvature at 0 and +20000.
         var t:Number = delta/20000;
         return 100 * (0.15 + t * (0.13744707299739786 + t * (0.20041939924923793
             + t * (-0.113881973159351 + t * (-0.18760058259473933 + t * 0.12325384349962887)))));
      }

      private static function opposedMissChance105(delta:Number) : Number
      {
         return 100 * (1 - Math.pow(1 + Math.max(0,delta)/4000,-Math.log(5)/Math.log(26)));
      }

      private static function rollPercent105(percent:Number) : Boolean
      {
         // Keep the native percent bucket while resolving fractional percentages in one draw.
         var draw:int = Random.getRandom(10000);
         return (draw % 100)*100 + int(draw/100) < Math.round(percent*100);
      }

      private static function precisionRecovery105(caster:Avatar) : Number
      {
         if(!ratioDamage104() || !caster) return 1;
         var hit:Number = Tools.toInt(caster.getHit()*(1+caster.checkTalent(4)));
         return 1 + 0.5 * statGrowth105(hit);
      }

      private static function defenseDamage104(amount:Number, defense:Number, baseAttack:Number) : Number
      {
         if(!ratioDamage104()) return Math.max(amount*MIN_DAMAGE_RATE,amount-defense);
         var ratio:Number = Math.max(0,defense)/Math.max(1,baseAttack);
         var reduction:Number = ratio>0 ? 1/(1+Math.pow(damageRuleNumber104("defense_attack_midpoint")/ratio,damageRuleNumber104("reduction_exponent"))) : 0;
         return amount*(1-Math.min(1-MIN_DAMAGE_RATE,reduction));
      }

      public static function trueSkillCoefficient104(coefficient:Number = 1) : Number
      {
         return coefficient*(ratioDamage104() ? damageRuleNumber104("true_skill_rate") : 1)/REAL_DAMAGE_RATE;
      }

      // END DAMAGE FORMULA 104

      public static function countDamage(param1:Avatar, param2:Avatar, param3:int, param4:int = -1, param5:Number = 1) : Array
      {
         var _loc7_:Number = Number(NaN);
         var _loc6_:Array = [];
         _loc6_[1] = AvatarData.damageRate(param1.avatarData.signType,param2.avatarData.signType);
         _loc7_ = Tools.toInt(param3 * _loc6_[1]);
         trace(_loc7_ + "is克制后的伤害" + "ph" + param2.getDePh() + "ma" + param2.getDeMa());
         if(param2.checkTalent(2) != 0 || param2.checkTalent(3) != 0)
         {
            trace(param2.getDePh() + "|||||||||||||||||||||||||||||||" + param2.id + "|||||||||||||||||||||||||||||||||" + param2.getDefenseAgainst(param1,1));
            trace(param2.getDeMa() + "|||||||||||||||||||||||||||||||" + param2.id + "|||||||||||||||||||||||||||||||||" + param2.getDefenseAgainst(param1,2));
         }
         var abyssTrue104:Number = (param4 == 1 || param4 == 2) ? param1.abyssConversion104() : 0;
         if(abyssTrue104 > 0)
         {
            // Split raw damage before each branch's element and rounding stages.
            var abyssPhysicalRaw104:Number = Tools.toInt(param3 * (1 - abyssTrue104) * _loc6_[1]);
            var abyssTrueRaw104:Number = Tools.toInt(param3 * abyssTrue104 * _loc6_[1]);
            _loc7_ = Tools.toInt(Tools.toInt(defenseDamage104(abyssPhysicalRaw104,param2.getDefenseAgainst(param1,param4),param1.ap)) * param5) + Tools.toInt(Tools.toInt(abyssTrueRaw104 * REAL_DAMAGE_RATE) * param5);
            param5 = 1;
         }
         else if(param4 == 1)
         {
            _loc7_ = defenseDamage104(_loc7_,param2.getDefenseAgainst(param1,1),param1.ap);
         }
         else if(param4 == 2)
         {
            _loc7_ = defenseDamage104(_loc7_,param2.getDefenseAgainst(param1,2),param1.ap);
         }
         else if(param4 == 3)
         {
            _loc7_ *= REAL_DAMAGE_RATE;
         }
         else if(param4 == 5)
         {
            _loc7_ = 0;
         }
         else if(param4 == 0)
         {
            _loc7_ = 0;
         }
         else if(param4 == 4)
         {
            _loc7_ = _loc7_;
         }
         _loc7_ = Tools.toInt(_loc7_);
         trace(_loc7_);
         _loc6_[0] = Tools.toInt(_loc7_ * param5);
         trace(param5 + "heheheheheh" + _loc6_[0]);
         _loc6_[1] = _loc6_[1] == SIGN_DAMAGE_RATE ? true : false;
         return _loc6_;
      }

      public static function checkCrit(param1:Avatar, param2:Avatar) : Number
      {
         var _loc7_:Number = Number(NaN);
         var _loc6_:* = damageAttack104();
         var _loc5_:int = Tools.toInt(param1.getCrit() + param1.getCrit() * param1.checkTalent(6));
         var _loc8_:int = Tools.toInt(param2.getTough() + param2.getTough() * param2.checkTalent(7));
         trace("oldCrit" + param1.getCrit() + "|||||||||||||||newCrit" + _loc5_);
         trace("oldTough" + param2.getTough() + "|||||||||||||||newTough" + param2.getTough());
         var delta:Number = ratioDamage104() ? Math.max(0,_loc5_) - Math.max(0,_loc8_) : Number(_loc5_) - _loc8_;
         var _loc4_:Number = ratioDamage104() ? opposedCritChance105(delta) :
             Tools.toInt(Math.min(_loc6_[7],Math.max(0,_loc6_[5]+100*delta/(_loc5_+_loc8_+_loc6_[11]))));
         GameMapTools.gameTrace("暴击判定",param1.id,param2.id);
         var sixAttack:Object=param1.skillB ? currentAbilityAttack() : null;
         var force:Boolean=sixAttack && sixAttack.owner===param1 && sixAttack.sixForceCrit105;
         var chance:Number=_loc4_;
         if(sixAttack && sixAttack.owner===param1 && sixAttack.kind=="active" && param1.skillB)
         {
            var rengar:Array=param1.sixFollowupPassive105("rengar");
            if(rengar) chance=Math.min(100,chance*Number(rengar[4]));
         }
         var _loc3_:Boolean = force || (ratioDamage104() ? rollPercent105(chance) : Random.getRandom() < chance);
         if(_loc3_)
         {
            _loc7_ = ratioDamage104() ? 2 * opposedPower105(force ? Math.max(0,_loc5_) : delta) : _loc6_[3] + _loc5_ * _loc6_[16] / (_loc5_ + _loc6_[12]);
            GameMapTools.gameTrace("暴击倍数",_loc7_);
            return _loc7_;
         }
         return 1;
      }

      public static function missTween(param1:Avatar) : void
      {
         var _loc3_:Sprite = param1.fightRes;
         var _loc2_:int = 40;
         if(param1.offset < 0)
         {
            _loc2_ = -_loc2_;
         }
         _loc2_ = -_loc2_;
         var _loc6_:Tween = new Tween(_loc3_,0.2,"easeOut");
         _loc6_.scaleTo(param1.getScale() * 0.9);
         _loc6_.animate("pivotX",_loc2_);
         var _loc5_:Tween = new Tween(_loc3_,0.2,"easeIn");
         _loc5_.delay = 0.2;
         _loc5_.scaleTo(param1.getScale());
         _loc5_.animate("pivotX",0);
         var _loc4_:GameMapLayer = GameMapLayer.gl;
         _loc4_.addTween(_loc6_);
         _loc4_.addTween(_loc5_);
      }

      public static function attackTween(param1:Avatar, param2:Avatar, param3:int = -1, param4:Number = 0) : void
      {
         var _loc8_:Sprite = null;
         var _loc9_:Sprite = null;
         var _loc12_:Number = Number(NaN);
         var _loc6_:int = 0;
         var _loc5_:int = 0;
         var _loc11_:Number = Number(NaN);
         if(param3 < 0 && (!param1 || !param2))
         {
            return;
         }
         if(param1)
         {
            _loc8_ = param1.fightRes;
         }
         if(param2)
         {
            _loc9_ = param2.fightRes;
         }
         var _loc10_:int = 25;
         if(param1.team == 1)
         {
            _loc10_ = -_loc10_;
         }
         _loc11_ = 0;
         var _loc13_:Number = 0.25;
         var _loc15_:Tween = new Tween(_loc8_,_loc13_,"easeOut");
         _loc15_.delay = _loc11_ + param4;
         if(param3 >= 0)
         {
            _loc15_.animate("x",param3);
         }
         else if(param1 != param2 && param1.line == param2.line)
         {
            _loc12_ = GameMapTools.getRadians(new Point(_loc8_.x,_loc8_.y),new Point(_loc9_.x,_loc9_.y));
            _loc6_ = Math.abs(_loc10_) * Math.cos(_loc12_);
            _loc5_ = Math.abs(_loc10_) * Math.sin(_loc12_);
            _loc15_.animate("x",_loc8_.x + _loc6_);
            _loc15_.animate("y",_loc8_.y + _loc5_);
         }
         else
         {
            _loc15_.animate("y",_loc8_.y + _loc10_);
         }
         _loc15_.scaleTo(param1.getScale() * 0.9);
         var _loc14_:Tween = new Tween(_loc8_,0.25,"easeIn");
         _loc14_.delay = 0.25 + _loc11_ + param4;
         _loc14_.scaleTo(param1.getScale());
         _loc14_.animate("x",_loc8_.x);
         _loc14_.animate("y",_loc8_.y);
         var _loc7_:GameMapLayer = GameMapLayer.gl;
         _loc7_.addTween(_loc15_);
         _loc7_.addTween(_loc14_);
      }

      public static function sortOnPosLine(param1:Avatar, param2:Avatar) : int
      {
         var _loc4_:int = param1.pos;
         var _loc3_:int = param2.pos;
         if(_loc4_ < _loc3_)
         {
            return -1;
         }
         if(_loc4_ > _loc3_)
         {
            return 1;
         }
         return 0;
      }

      public function get resId() : String
      {
         var _loc1_:String = avatarData.res;
         if(morph > 0)
         {
            _loc1_ += ".";
         }
         return _loc1_;
      }

      public function get isBot() : Boolean
      {
         return id.indexOf("-") != -1;
      }

      public function setDestinyAndDN(param1:String = "", param2:Array = null, param3:Array = null, param4:Object = null, param5:Object = null, param6:Boolean = false) : void
      {
         if(GlobalData.$mConfig_simple.bonds_104)
         {
            bondLineup104 = param2;
            mDestiny = null;
            mDNdata = PanelDetailDN.getDNAttrsAllValue(param5);
            updateBondSkills104();
            return;
         }
         mDestiny = PanelCenterDNTeam.getDestinyMyAll(param1 == "" ? id : param1,param2,param3,param4,param5,param6);
         mDNdata = PanelDetailDN.getDNAttrsAllValue(param5);
         if(mDestiny.skill0.length > 0)
         {
            skill0 = new SkillSet(mDestiny.skill0,this,slv);
         }
         if(mDestiny.skill1.length > 0)
         {
            skill1 = new SkillSet(mDestiny.skill1,this,1,true);
         }
      }

      public function clearDNdata() : void
      {
         mDNdata = null;
      }

      public function clearDestinydata() : void
      {
         mDestiny = null;
      }

      public function setEquips(param1:Array = null, param2:Boolean = true, param3:Object = null) : void
      {
         var _loc6_:Array = null;
         var _loc4_:int = 0;
         var _loc8_:int = 0;
         var _loc5_:Equip = null;
         var _loc7_:* = undefined;
         if(param1 == null && param2)
         {
            _loc6_ = GlobalData.$userData.as_equips;
            _loc4_ = getIndex();
            if(_loc4_ >= 0)
            {
               param1 = _loc6_[getIndex()];
            }
            else
            {
               param1 = null;
            }
         }
         equips = new Vector.<Equip>();
         // Abyss relic (7th slot) of this team position; only the player's own
         // equipment rows carry it. Abyss battles use server snapshots (hpMax set).
         abyssRelic104 = null;
         if(param2)
         {
            var relicIndex:int = GlobalData.$userData && GlobalData.$userData.team is Array && GlobalData.$userData.team[0] is Array ? getIndex() : -1;
            var relicSlots:Array = GlobalData.$userData && GlobalData.$userData.abyss_relic_slots is Array ? GlobalData.$userData.abyss_relic_slots as Array : null;
            var relicItems:Object = GlobalData.$userData ? GlobalData.$userData.abyss_relics : null;
            if(relicIndex >= 0 && relicSlots && relicItems && relicSlots[relicIndex]) abyssRelic104 = relicItems[relicSlots[relicIndex]];
         }
         if(!param1 || param1.length == 0)
         {
            skill2 = null;
            updateBondSkills104();
            return;
         }
         if(param2)
         {
            param3 = GlobalData.$userData.my_equips;
            if(!param3)
            {
               return;
            }
            _loc8_ = 0;
            while(_loc8_ < param1.length)
            {
               _loc7_ = param3[param1[_loc8_]];
               if(_loc7_)
               {
                  _loc5_ = new Equip(param1[_loc8_],_loc7_);
                  equips.push(_loc5_);
               }
               _loc8_++;
            }
         }
         else
         {
            _loc8_ = 0;
            while(_loc8_ < param1.length)
            {
               if(param3)
               {
                  _loc7_ = param3[param1[_loc8_]];
               }
               else
               {
                  _loc7_ = param1[_loc8_];
               }
               if(_loc7_)
               {
                  _loc5_ = new Equip(_loc7_.eid,_loc7_);
                  equips.push(_loc5_);
               }
               _loc8_++;
            }
         }
         skill2 = getBookSkill();
         updateBondSkills104();
      }

      public var abyssRelic104:Object = null;

      // Same as server abyss_relics.apply_panel: each substat multiplies the final
      // panel value of its stat and truncates (substat stats never repeat).
      public function applyAbyssRelic104(stat:String, value:int) : int
      {
         if(!abyssRelic104 || !(abyssRelic104.substats is Array)) return value;
         for each(var affix:Object in abyssRelic104.substats)
         {
            if(affix && affix.stat == stat) value = int(value * (1 + Number(affix.value)));
         }
         return value;
      }

      // Main affix power budget, added to the skill factor of the power formula.
      public function abyssRelicPowerRate104() : Number
      {
         if(!abyssRelic104 || !abyssRelic104.main) return 0;
         var rate:Number = GlobalData.$mConfig_simple && GlobalData.$mConfig_simple.abyss_relic_main_power_rate != null ? Number(GlobalData.$mConfig_simple.abyss_relic_main_power_rate) : 0.15;
         return rate * (abyssRelic104.main.ancient ? 1.25 : 1);
      }

      public function getIndex() : int
      {
         var _loc1_:Array = GlobalData.$userData.team[0];
         return _loc1_.indexOf(id);
      }

      public function get avatarData() : AvatarData
      {
         return m_data as AvatarData;
      }

      public function getEffectiveActionType() : int
      {
         return manualActionTypeOverride >= 1 && manualActionTypeOverride <= 4 ? manualActionTypeOverride : avatarData.actionType;
      }

      public function get otherTeam() : int
      {
         return 3 - team;
      }

      public function get posPer() : Number
      {
         return getPosPer(pos,team);
      }

      public function refreshReline(param1:int = -1, param2:int = -1, param3:int = -1) : void
      {
         var _loc4_:GameMapLayer = GameMapLayer.gl;
         _loc4_.addAvatar(this,-1);
         refreshPos(param1,param2,param3);
      }

      public function refreshPos(param1:int = -1, param2:int = -1, param3:int = -1) : void
      {
         var _loc4_:DisplayObject = null;
         if(param1 < 0)
         {
            param1 = line;
         }
         if(param2 < 0)
         {
            param2 = pos;
         }
         if(param3 < 0)
         {
            param3 = offset;
         }
         _loc4_ = fightRes;
         _loc4_.x = GameMapConfig.offsetToPixel(param3);
         _loc4_.y = GameMapConfig.posToPixel(param2);
      }

      public function hideRange() : void
      {
         if(m_fightRange)
         {
            m_fightRange.visible = false;
         }
         fightRes.rotation = 0;
         fightRes.scaleX = fightRes.scaleY = getScale();
      }

      public function showRange(param1:int, param2:int, param3:int) : void
      {
         hideRange();
      }

      public static function rangePreviewBounds(param1:int, param2:int, param3:int, param4:Number) : Rectangle
      {
         var _allLines:Boolean = param2 > GameMapConfig.LINE_POS;
         var _width:Number = _allLines ? GameMapConfig.FIGHT_WIDTH : GameMapConfig.FIGHT_WIDTH / Math.max(1,param3);
         var _first:int = Math.max(0,Math.min(GameMapConfig.LINE_POS,param1 - Math.max(0,param2)));
         var _last:int = Math.max(_first,Math.min(GameMapConfig.LINE_POS,param1 + Math.max(0,param2)));
         var _top:Number = GameMapConfig.posToPixel(_first);
         return new Rectangle(_allLines ? 0 : param4 - _width * 0.5,_top,Math.max(1,_width),Math.max(2,GameMapConfig.posToPixel(_last) - _top));
      }

      public static function rangePreviewSchedule(param1:Number, param2:Number) : Array
      {
         var _start:Number = Math.max(param1,param2);
         return [_start,_start + 0.2];
      }

      private function queueRangePreview() : void
      {
         if(rangePreviewQueued || GameMap.currentAvatar !== this || !GameMapLayer.gl)
         {
            return;
         }
         rangePreviewQueued = true;
         var _schedule:Array = rangePreviewSchedule(GameMap.actionDelay,rangeMoveEndsAt);


         GameMap.actionDelay = _schedule[1];
      }

      public function getAvatarRes(param1:Boolean = false, param2:Boolean = false, param3:Boolean = false) : Sprite
      {
         if(!m_avatarRes)
         {
            m_avatarRes = newAvatarRes(null,param1,param2,param3);
         }
         if(!GlobalData.modCardFrame(avatarData.res + "_icon0000") && !m_avatarRes.getChildByName("limitBreakEdge")) m_avatarRes.flatten();
         return m_avatarRes;
      }

      public function getPithNum() : int
      {
         if(isWeightedCultivation())
         {
            var weights:Object = GlobalData.$mConfig_simple && GlobalData.$mConfig_simple.culture && GlobalData.$mConfig_simple.culture.weighted ? GlobalData.$mConfig_simple.culture.weighted.weights : null;
            return Math.max(0,hpP) * (weights && weights.hp != null ? int(weights.hp) : 1) + Math.max(0,apP) * (weights && weights.ap != null ? int(weights.ap) : 12) + Math.max(0,dePhP) * (weights && weights.de_ph != null ? int(weights.de_ph) : 10) + Math.max(0,deMaP) * (weights && weights.de_ma != null ? int(weights.de_ma) : 10);
         }
         return hpP + apP + deMaP + dePhP;
      }

      public function isWeightedCultivation() : Boolean
      {
         return cultureSchema == "weighted-v2" && getType() == 1 && (getStar() == 5 || getStar() == 6);
      }

      public function getCultivationCap() : int
      {
         var culture:Object = GlobalData.$mConfig_simple ? GlobalData.$mConfig_simple.culture : null;
         if(!culture) return 0;
         if(isWeightedCultivation())
         {
            var weighted:Object = culture.weighted;
            var star:Object = weighted && weighted.stars ? weighted.stars[String(getStar())] : null;
            if(!star) return 0;
            return Math.max(0,int(star.cap_base) + Math.min(3,Math.max(0,phase)) * int(star.cap_per_phase));
         }
         var base:int = Math.max(0,int(culture.max_pith_base));
         var absolute:int = culture.max_pith != null ? Math.max(0,int(culture.max_pith)) : base;
         var bonus:int = mData && mData.pith_max != null ? Math.max(0,int(mData.pith_max)) : 0;
         return Math.min(absolute,base + bonus);
      }

      public function getCultivationDisplayScale() : int
      {
         return isWeightedCultivation() ? 1 : int(GlobalData.$mConfig_simple.culture.culture_pith);
      }

      public function newAvatarRes(param1:Sprite = null, param2:Boolean = false, param3:Boolean = false, param4:Boolean = false) : Sprite
      {
         if(param1) clearLimitBreakEdge(param1);
         var _loc6_:Image = null;
         var _loc9_:Boolean = false;
         var _loc11_:Image = null;
         var _loc14_:int = 0;
         var _loc8_:Image = null;
         var _loc16_:Image = null;
         var _loc13_:Number = Number(NaN);
         var _loc12_:Number = Number(NaN);
         var _loc7_:* = null;
         if(param1)
         {
            param1.removeChildren(0,-1,true);
         }
         if(!param1)
         {
            param1 = new Sprite();
         }
         m_icon = null;
         if(param2)
         {
            _loc6_ = GlobalFunction.createImage("UI_bg_card_2_0005");
            _loc6_.name = "avatar";
            if(team == 1)
            {
               _loc6_.color = 13158;
            }
            else
            {
               _loc6_.color = 8388608;
            }
            _loc6_.touchable = false;
            param1.addChild(_loc6_);
         }
         if(!m_icon)
         {
            m_icon = GlobalFunction.getAvatarIcon(avatarData.res);
            _loc9_ = m_icon.width > 100;
            m_icon.x = _loc9_ ? -5 : 0;
            m_icon.y = _loc9_ ? -5 : 0;
         }
         m_icon.touchable = true;
         param1.addChild(m_icon);
         var hasLimitBreakVisual:Boolean = limitBreak > 0 && getType() == 1 && (getStar() == 5 || getStar() == 6);
         if(hasLimitBreakVisual || morph > 0)
         {
            _loc14_ = Math.min(1,Math.max(0,getStar() - 5));
            _loc11_ = GlobalFunction.createImage("UI_bg_card_4_2_ 000" + String(_loc14_));
            _loc11_.touchable = false;
            _loc11_.x = m_icon.x - 3;
            _loc11_.y = m_icon.y - 1;
            param1.addChild(_loc11_);
            if(hasLimitBreakVisual)
            {
               _loc11_.name = "limitBreakEdge";
               mLimitBreakEdges.push(_loc11_);
               var pulse:Tween = new Tween(_loc11_,0.85,"easeInOut");
               pulse.animate("alpha",0.45);
               pulse.reverse = true;
               pulse.repeatCount = 0;
               if(GlobalData.$mStarling) GlobalData.$mStarling.juggler.add(pulse);
            }
         }
         if(hasLimitBreakVisual || getStar() == 6 && phase >= 3)
         {
            var breakColor:uint = getStar() == 5 ? 0xB561F1 : 0xFF9B32;
            var breakLabel:TextField = GlobalTextStyle.getTextField(getStar() == 6 && phase >= 3 ? "满阶" : "突破极限",15,breakColor,"center",m_icon.width,20);
            breakLabel.x = m_icon.x;
            breakLabel.y = m_icon.y - 21;
            breakLabel.touchable = false;
            param1.addChild(breakLabel);
         }
         var _loc10_:Image = GlobalFunction.createImage("UI_tag_0_000" + (String(this.avatarData.damageType - 1)));
         _loc10_.touchable = false;
         _loc10_.x = 28;
         _loc10_.y = m_icon.y + m_icon.height - _loc10_.height - 11;
         if(phase > 0)
         {
            _loc8_ = GlobalFunction.createImage("UI_tag_0_1_000" + (String(phase - 1)));
            _loc8_.touchable = false;
            _loc8_.x = _loc10_.x - 26;
            _loc8_.y = _loc10_.y + 7;
            param1.addChild(_loc8_);
         }
         param1.addChild(_loc10_);
         var _loc5_:Image = GlobalFunction.createImage("UI_tag_1_000" + (String(this.avatarData.signType - 1)));
         _loc5_.touchable = false;
         _loc5_.x = _loc10_.x + int((_loc10_.width - _loc5_.width) * 0.5);
         _loc5_.y = _loc10_.y + int((_loc10_.height - _loc5_.height) * 0.5) - 1;
         param1.addChild(_loc5_);
         if(param4)
         {
            _loc16_ = GlobalFunction.createImage("UI_btn_over_20_0000");
            _loc16_.visible = false;
            _loc16_.name = "UI_btn_over_20_0000";
            _loc16_.touchable = false;
            param1.addChild(_loc16_);
         }
         var _loc15_:int = getPithNum();
         if(_loc15_ > 0)
         {
            _loc13_ = _loc10_.x;
            _loc12_ = _loc10_.y;
         }
         return param1;
      }

      private function clearLimitBreakEdge(container:Sprite = null) : void
      {
         for(var i:int = mLimitBreakEdges.length - 1; i >= 0; i--)
         {
            var image:Image = mLimitBreakEdges[i];
            if(container && image.parent != container) continue;
            if(GlobalData.$mStarling) GlobalData.$mStarling.juggler.removeTweens(image);
            mLimitBreakEdges.splice(i,1);
         }
      }

      public function refreshIcon() : void
      {
         if(m_icon && m_icon.filter)
         {
            m_icon.filter.cache();
         }
      }

      public function newFightRes(param1:Sprite = null) : Sprite
      {
         fxLoad104();
         var _loc2_:String = null;
         var _loc3_:Sprite = null;
         var _loc7_:Image = null;
         if(param1)
         {
            param1.removeChildren(0,-1,true);
         }
         if(!param1)
         {
            param1 = new Sprite();
         }
         if(iconStyle == 1)
         {
            _loc3_ = newAvatarRes(null,true,isLeader);
            _loc3_.pivotX = 94 / 2;
            _loc3_.pivotY = 94 / 2;
            param1.addChild(_loc3_);
            mBloodSpr = new ProgressBar(team,hp / hpMax,hpMax);
            refreshVitalBar104(hp,hpMax,shieldValue104());
            mBloodSpr.y = -_loc3_.pivotY - 5;
            param1.addChild(mBloodSpr);
            if(isLeader)
            {
               _loc7_ = DisplayTools.newImg("aLeader");
               _loc7_.y = mBloodSpr.y - 25;
               param1.addChildAt(_loc7_,0);
            }
            m_buff = new Sprite();
            param1.addChild(m_buff);
            if(actionNum >= 0)
            {
               param1.addEventListener("touch",this.onTouch);
            }
            if(_loc7_)
            {
               _loc7_.touchable = false;
            }
            m_buff.touchable = false;
            param1.touchable = true;
            return param1;
         }
         m_fightBg = new Sprite();
         param1.addChild(m_fightBg);
         var _loc5_:Image = new Image(GlobalData.$assetManager.getTexture("avatarBg" + getStar() + "0000"));
         _loc5_.pivotX = int(_loc5_.width / 2);
         _loc5_.pivotY = int(_loc5_.height / 2);
         m_fightBg.addChild(_loc5_);
         m_resourceObj.pivotX = int(m_resourceObj.width / 2);
         m_resourceObj.pivotY = int(m_resourceObj.height / 2);
         m_resourceObj.scaleX = m_resourceObj.scaleY = 0.75;
         m_fightBg.addChild(m_resourceObj);
         param1.scaleY = param1.scaleX = getScale();
         var _loc4_:String = "0000";
         _loc2_ = "heroFrame" + team;
         if(avatarData.actionType == 3)
         {
            _loc2_ += "3";
         }
         _loc2_ += _loc4_;
         if(isLeader)
         {
            _loc7_ = new Image(GlobalData.$assetManager.getTexture("avatarLeader0000"));
            param1.addChild(_loc7_);
            _loc7_.pivotX = _loc7_.width / 2;
            _loc7_.pivotY = _loc7_.height / 2;
            if(avatarData.actionType == 3)
            {
               _loc7_.x = -42;
               _loc7_.y = -46;
            }
            else
            {
               _loc7_.x = -38;
               _loc7_.y = -43;
            }
         }
         m_buff = new Sprite();
         param1.addChild(m_buff);
         if(actionNum >= 0)
         {
            param1.addEventListener("touch",this.onTouch);
         }
         if(_loc7_)
         {
            _loc7_.touchable = false;
         }
         m_buff.touchable = false;
         param1.touchable = true;
         return param1;
      }

      public function get fightRes() : Sprite
      {
         if(!m_fightRes)
         {
            m_fightRes = newFightRes();
         }
         return m_fightRes;
      }

      public function onTouch(param1:TouchEvent) : void
      {
         var _loc2_:Touch = param1.getTouch(m_fightRes,"began");
         if(_loc2_)
         {
            if(GlobalData.$currentGuide)
            {
               if(GuideMaster.getOnlyExample().currentGuide.stepData.ma != actionNum)
               {
                  return;
               }
            }
            if(!GameMap.currentMap.isFight)
            {
               GlobalData.$mEventDispatcher.dispatchEventWith("update_pve_drag_avatar",false,{
                  "avatar":this,
                  "touch":_loc2_
               });
            }
         }
      }

      public function touchDetaiAvatar(param1:TouchEvent) : void
      {
         var _loc3_:* = undefined;
         var _loc2_:Touch = param1.getTouch(param1.currentTarget as DisplayObject,"ended");
         if(_loc2_)
         {
            _loc3_ = this.toDataObj();
            _loc3_.id = _loc3_.aid;
            GlobalFunction.setDetaiAvatar(_loc3_);
         }
      }

      public function hideActionNum() : void
      {
         if(m_actionNum)
         {
            m_actionNum.removeFromParent(true);
            if(m_tf)
            {
               m_tf.removeFromParent(true);
               m_tf = null;
            }
         }
      }

      public function reInit(param1:Object) : void
      {
         var _loc2_:int = 0;
         var _loc5_:int = line;
         var _loc4_:int = pos;
         var _loc3_:int = actionNum;
         var _loc6_:String = param1.aid;
         if(_loc6_)
         {
            _loc2_ = _loc6_.indexOf("|");
            id = _loc6_.slice(0,_loc2_);
            isLeader = param1.is_friend;
            if(!mData)
            {
               mData = {};
            }
            mData.isF = isLeader ? 1 : 0;
            m_data = AvatarManager.getOnlyExample().getData(id);
            m_resourceObj = null;
            m_fightRes = newFightRes(m_fightRes);
         }
         init(param1);
         if(param1.equips)
         {
            setEquips(param1.equips,false);
         }
         hp = 0;
         goFight(1,_loc5_,0,isLeader);
         pos = _loc4_;
         actionNum = _loc3_;
      }

      public function init(param1:Object) : void
      {
         var _loc3_:Array = null;
         var _loc2_:Boolean = false;
         var previousLimitBreak:int = limitBreak;
         var previousMorph:int = morph;
         skill0 = null;
         skill1 = null;
         skill2 = null;
         skillB = null;
         talent = null;
         limitBreak = 0;
         cultureSchema = "";
         loadAbyssPassives104(param1 != null && !(param1 is Array) && param1.hp_max ? param1 : null);
         if(param1 == null)
         {
            mData = {
               "aid":id,
               "id":id,
               "ap":0,
               "de_ma":0,
               "de_ph":0,
               "exp":0,
               "hp":0,
               "lv":1,
               "slv":1,
               "love_exp":0,
               "phase":0,
               "limit_break":0,
               "culture_schema":"",
               "morph":0
            };
            lv = mData.lv;
            exp = mData.exp;
            slv = mData.slv;
            hpP = mData.hp;
            apP = mData.ap;
            dePhP = mData.de_ph;
            deMaP = mData.de_ma;
            loveExp = mData.love_exp;
            phase = mData.phase;
            limitBreak = mData.limit_break;
            cultureSchema = mData.culture_schema;
            morph = mData.morph;
            id = mData.id;
         }
         else if(param1 is Array)
         {
            _loc3_ = param1 as Array;
            lv = _loc3_[1];
            slv = _loc3_[2];
            if(_loc3_.length >= 12)
            {
               hpP = _loc3_[3];
               apP = _loc3_[4];
               dePhP = _loc3_[5];
               deMaP = _loc3_[6];
               phase = _loc3_[7];
               limitBreak = _loc3_.length > 12 ? int(_loc3_[12]) : 0;
               line = _loc3_[8];
               pos = _loc3_[9];
               setEquips(_loc3_[10],false);
               _loc2_ = true;
               morph = _loc3_[11];
            }
            else if(_loc3_.length >= 11)
            {
               isNPC = true;
            }
            else
            {
               isNPC = true;
            }
         }
         else
         {
            cultureSchema = param1.culture_schema != null ? String(param1.culture_schema) : "";
            if(param1.hp_max)
            {
               hpP = apP = dePhP = deMaP = 0;
               lv = param1.lv;
               slv = param1.slv;
               hpMax = param1.hp_max;
               ap = param1.ap;
               hp = param1.hp;
               dePh = param1.de_ph;
               deMa = param1.de_ma;
               morph = param1.morph;
               phase = param1.phase;
               limitBreak = int(param1.limit_break);
               if(param1.book_skill)
               {
                  skill2 = new SkillSet(param1.book_skill.skid,this,param1.book_skill.slv);
               }
               if(param1.skill)
               {
                  skill0 = new SkillSet(param1.skill.skid,this,param1.slv);
               }
               if(param1.leader_skill)
               {
                  skill1 = new SkillSet(param1.leader_skill.skid,this,param1.leader_skill.slv,true);
               }
               if(param1.skillB)
               {
                  skillB = new SkillSet(param1.skillB.skid,this,param1.skillB.slv);
               }
               if(param1.talent)
               {
                  talent = new Talent(param1.talent);
               }
               if(param1.tpl)
               {
                  speed = param1.tpl[3];
                  range = param1.tpl[4];
               }
               if(param1.new_4attrs)
               {
                  hit = param1.new_4attrs.hit;
                  flee = param1.new_4attrs.flee;
                  crit = param1.new_4attrs.crit;
                  tough = param1.new_4attrs.tough;
               }
            }
            else
            {
               lv = param1.lv;
               exp = param1.exp;
               slv = param1.slv;
               hpP = param1.hp;
               apP = param1.ap;
               dePhP = param1.de_ph;
               deMaP = param1.de_ma;
               loveExp = param1.love_exp;
               phase = param1.phase;
               limitBreak = int(param1.limit_break);
               morph = param1.morph;
               id = param1.id ? param1.id : param1.aid;
            }
            if(param1.current_hp)
            {
               hp = param1.current_hp;
            }
            mData = param1;
         }
         if(!id)
         {
            id = avatarData.id + "-" + index;
            index += 1;
         }
         initHalo(param1);
         initSkills();
         if(m_avatarRes && (previousLimitBreak != limitBreak || previousMorph != morph))
         {
            m_avatarRes.unflatten();
            newAvatarRes(m_avatarRes);
         }
         actionNum = -1;
         line = -1;
         if(!_loc2_)
         {
            equips = new Vector.<Equip>();
         }
      }

      private function initHalo(param1:Object) : void
      {
         if(param1)
         {
            if(param1["talent"])
            {
               if(param1.talent != "" && param1.talent is String)
               {
                  talent = new Talent(param1.talent);
               }
               else
               {
                  talent = new Talent(param1.talent.id);
               }
            }
         }
      }

      public function toDataNormalObj() : Object
      {
         var _loc1_:Object = toDataObj();
         _loc1_.id = id;
         _loc1_.hp = hpP;
         _loc1_.ap = apP;
         _loc1_.de_ma = deMaP;
         _loc1_.de_ph = dePhP;
         _loc1_.love_exp = loveExp;
         _loc1_.phase = phase;
         _loc1_.limit_break = limitBreak;
         _loc1_.culture_schema = cultureSchema;
         return _loc1_;
      }

      public function toDataObj() : Object
      {
         var _loc1_:Object = {};
         _loc1_.equipment_bonds_104 = [];
         for each(var equipmentBond104:Object in getEquipmentBondRows104()) _loc1_.equipment_bonds_104.push(String(equipmentBond104.equipment));
         _loc1_.bonds_104 = [];
         for each(var bond104:Object in getBondRows104()) _loc1_.bonds_104.push(String(bond104.id));
         _loc1_.aid = avatarData.id;
         if(mData && mData.instance_id) _loc1_.instance_id = String(mData.instance_id);
         _loc1_.ap = ap;
         _loc1_.morph = morph;
         _loc1_.phase = phase;
         _loc1_.limit_break = limitBreak;
         _loc1_.culture_schema = cultureSchema;
         _loc1_.buffs = {};
         _loc1_.de_ma = deMa;
         _loc1_.de_ph = dePh;
         _loc1_.hp = hp;
         _loc1_.hp_max = hpMax;
         _loc1_.isme = team == 1;
         _loc1_.leader = isLeader ? 1 : 0;
         _loc1_.line = line;
         _loc1_.lv = lv;
         _loc1_.new_4attrs = {};
         _loc1_.new_4attrs.hit = hit;
         _loc1_.new_4attrs.flee = flee;
         _loc1_.new_4attrs.crit = crit;
         _loc1_.new_4attrs.tough = tough;
         _loc1_.pos = pos;
         _loc1_.slv = slv;
         _loc1_.tpl = [];
         _loc1_.tpl[0] = avatarData.signType;
         _loc1_.tpl[1] = avatarData.actionType;
         _loc1_.tpl[2] = avatarData.damageType;
         _loc1_.tpl[3] = speed;
         _loc1_.tpl[4] = range;
         _loc1_.talent = talent ? talent.id : null;
         if(skill0)
         {
            _loc1_.skill = {};
            _loc1_.skill.cd = skill0.skillSetData.warmup;
            _loc1_.skill.pl = skill0.skillSetData.pl;
            _loc1_.skill.skid = skill0.skillSetData.id;
            _loc1_.skill.skills = skill0.skills;
         }
         else
         {
            _loc1_.skill = null;
         }
         if(skill1 && isLeader)
         {
            _loc1_.leader_skill = {};
            _loc1_.leader_skill.cd = skill1.skillSetData.warmup;
            _loc1_.leader_skill.pl = skill1.skillSetData.pl;
            _loc1_.leader_skill.skid = skill1.skillSetData.id;
            _loc1_.leader_skill.skills = skill1.skills;
         }
         else
         {
            _loc1_.leader_skill = null;
         }
         if(skill2)
         {
            _loc1_.book_skill = {};
            _loc1_.book_skill.pl = skill2.skillSetData.pl;
            if(_loc1_.book_skill.pl)
            {
               _loc1_.book_skill.cd = skill2.skillSetData.warmup;
            }
            _loc1_.book_skill.skid = skill2.skillSetData.id;
            _loc1_.book_skill.skills = skill2.skills;
            _loc1_.book_skill.slv = skill2.lv;
         }
         else
         {
            _loc1_.book_skill = null;
         }
         if(skillB)
         {
            _loc1_.skillB = {};
            _loc1_.skillB.cd = skillB.skillSetData.warmup;
            _loc1_.skillB.pl = skillB.skillSetData.pl;
            _loc1_.skillB.skid = skillB.skillSetData.id;
            _loc1_.skillB.skills = skillB.skills;
         }
         else
         {
            _loc1_.skillB = null;
         }
         return _loc1_;
      }

      protected function initSkills() : void
      {
         var _loc1_:String = null;
         var _loc2_:AvatarData = avatarData;
         if(!skill0)
         {
            _loc1_ = _loc2_.skill0;
            if(_loc1_ != null && _loc1_ != "")
            {
               skill0 = new SkillSet(_loc1_,this,slv);
            }
         }
         if(!skill1)
         {
            _loc1_ = _loc2_.skill1;
            if(_loc1_ != null && _loc1_ != "")
            {
               skill1 = new SkillSet(_loc1_,this,1,true);
            }
         }
         if(!skillB && _loc2_.skillB)
         {
            _loc1_ = _loc2_.skillB;
            if(_loc1_ != null && _loc1_ != "")
            {
               skillB = new SkillSet(_loc1_,this,1);
            }
         }
      }

      protected function initbuffs() : void
      {
         buffs = {};
         manualSkillDots = {};
         manualBattleStacks = {};
         manualTimedStacks = [];
         manualOwnerActionSerial = 0;
         skin2 = {};
         manualSummonFamilies = {};
         manualLethalFloor = {};
      }

      public function getManualBattleStack(param1:String) : Number
      {
         if(!manualBattleStacks || !manualBattleStacks[param1]) return 0;
         return Math.max(0,Number(manualBattleStacks[param1]));
      }

      public function addManualBattleStack(param1:String, param2:Number, param3:int) : void
      {
         if(!manualBattleStacks) manualBattleStacks = {};
         if(["attack","defense","flee"].indexOf(param1) < 0) return;
         if(!isFinite(param2) || param2 <= 0 || param3 < 1) return;
         manualBattleStacks[param1] = Math.min(Number(param3) * param2,getManualBattleStack(param1) + param2);
         var flat:Boolean = ["hit","flee","crit","tough"].indexOf(param1) >= 0;
         var labels:Object = {hit:"精准",flee:"闪避",crit:"暴击",tough:"韧性"};
         abilityFeedback(flat ? labels[param1]+"叠加：+"+Math.round(getManualBattleStack(param1)) : "永久成长："+Math.round(getManualBattleStack(param1)*100)+"%",flat ? "FX_S9140_FLEE" : "FX_S9160_STRONG");
      }

      public function getManualTimedStack(param1:String) : Number
      {
         var _loc1_:int = 0;
         var _loc2_:Number = 0;
         if(!manualTimedStacks) return 0;
         while(_loc1_ < manualTimedStacks.length)
         {
            if(manualTimedStacks[_loc1_] && manualTimedStacks[_loc1_].stat == param1 && int(manualTimedStacks[_loc1_].expiresAt) >= manualOwnerActionSerial) _loc2_ += Number(manualTimedStacks[_loc1_].value);
            _loc1_++;
         }
         return Math.max(0,_loc2_);
      }

      public function addManualTimedStack(param1:String, param2:Number, param3:int, param4:int) : void
      {
         var _loc1_:int = 0;
         var _loc2_:int = 0;
         var _loc3_:Array = [];
         if(param1 != "attack" || !isFinite(param2) || param2 <= 0 || param2 > 1 || param3 < 1 || param3 > 8 || param4 < 1 || param4 > 20) return;
         if(!manualTimedStacks) manualTimedStacks = [];
         while(_loc1_ < manualTimedStacks.length)
         {
            if(manualTimedStacks[_loc1_] && int(manualTimedStacks[_loc1_].expiresAt) >= manualOwnerActionSerial)
            {
               _loc3_.push(manualTimedStacks[_loc1_]);
               if(manualTimedStacks[_loc1_].stat == param1) _loc2_++;
            }
            _loc1_++;
         }
         manualTimedStacks = _loc3_;
         if(_loc2_ >= param3) return;
         manualTimedStacks.push({"stat":param1,"value":param2,"expiresAt":manualOwnerActionSerial + param4});
         abilityFeedback("力量叠层："+(_loc2_+1)+"/"+param3,"FX_S9160_STRONG");
      }

      private function advanceManualOwnerAction() : void
      {
         var _loc1_:int = 0;
         var _loc2_:Array = [];
         manualOwnerActionSerial++;
         if(!manualTimedStacks) manualTimedStacks = [];
         while(_loc1_ < manualTimedStacks.length)
         {
            if(manualTimedStacks[_loc1_] && int(manualTimedStacks[_loc1_].expiresAt) >= manualOwnerActionSerial) _loc2_.push(manualTimedStacks[_loc1_]);
            _loc1_++;
         }
         manualTimedStacks = _loc2_;
      }

      public function getManualSummonSlots(param1:String, param2:int) : int
      {
         var _loc1_:Array = null;
         var _loc2_:int = 0;
         var _loc3_:Vector.<Avatar> = null;
         var _loc4_:Vector.<Avatar> = null;
         if(!manualSummonFamilies) manualSummonFamilies = {};
         _loc3_ = manualSummonFamilies[param1] as Vector.<Avatar>;
         if(!_loc3_) return Math.max(0,param2);
         _loc1_ = [];
         _loc2_ = 0;
         while(_loc2_ < _loc3_.length)
         {
            if(_loc3_[_loc2_] && _loc3_[_loc2_].hp > 0) _loc1_.push(_loc3_[_loc2_]);
            _loc2_++;
         }
         _loc4_ = new Vector.<Avatar>();
         _loc2_ = 0;
         while(_loc2_ < _loc1_.length)
         {
            _loc4_.push(_loc1_[_loc2_] as Avatar);
            _loc2_++;
         }
         manualSummonFamilies[param1] = _loc4_;
         return Math.max(0,param2 - _loc1_.length);
      }

      public function registerManualSummon(param1:String, param2:Avatar, param3:int) : Boolean
      {
         var _loc1_:Vector.<Avatar> = null;
         if(!param1 || !param2 || param2.hp <= 0 || getManualSummonSlots(param1,param3) <= 0) return false;
         if(!manualSummonFamilies) manualSummonFamilies = {};
         _loc1_ = manualSummonFamilies[param1] as Vector.<Avatar>;
         if(!_loc1_) _loc1_ = new Vector.<Avatar>();
         _loc1_.push(param2);
         manualSummonFamilies[param1] = _loc1_;
         return true;
      }

      public function addManualSkillDot(param1:String, param2:String, param3:Number, param4:Number, param5:int, param6:Avatar = null, param7:int = 0, stack:Boolean = false) : void
      {
         var _loc1_:Object = null;
         var _loc2_:Buff = null;
         if(yasuoImmune104(param2)) return;
         if(s2AnnieImmune()) return;
         if(!param1 || (param2 != "poison" && param2 != "burn" && param2 != "bleed") || !isFinite(param3) || param3 < 0 || !isFinite(param4) || param4 < 0 || param5 < 1) return;
         if(buffs && buffs["purify"])
         {
            removeBuff("purify",true);
            return;
         }
         if(!manualSkillDots) manualSkillDots = {};
         if(stack) param1 += ":layer:" + (++manualDotSerial);
         _loc1_ = {"kind":param2,"apTick":Math.max(0,int(param3)),"hpMaxFraction":param4,"damageType":param7,"round":param5,"source":param6};
         _loc2_ = new Buff(param2 == "bleed" ? "poison" : param2,param5,Number(_loc1_.apTick));
         _loc1_.visual = _loc2_;
         if(manualSkillDots[param1] && manualSkillDots[param1].visual && m_buff && manualSkillDots[param1].visual.displayObject && manualSkillDots[param1].visual.displayObject.parent == m_buff)
         {
            m_buff.removeChild(manualSkillDots[param1].visual.displayObject);
         }
         manualSkillDots[param1] = _loc1_;
         showBuff(_loc2_);
         s2AnnieStatus(param2);
         if(param2=="burn") sixReactionBurnChanged105();
      }

      public function hasManualDamageOverTime() : Boolean
      {
         var _loc1_:String = null;
         if(buffs && (buffs["poison"] || buffs["burn"])) return true;
         for(_loc1_ in abilityState)
         {
            if(_loc1_.indexOf("malz_") == 0 && abilityState[_loc1_] && abilityState[_loc1_].ticks > 0) return true;
         }
         for(_loc1_ in manualSkillDots)
         {
            if(manualSkillDots[_loc1_] && manualSkillDots[_loc1_].round >= 0) return true;
         }
         return false;
      }

      public function hasManualDotKind(param1:String) : Boolean
      {
         var _loc1_:String = null;
         if(param1 == "poison" && buffs && buffs["poison"]) return true;
         if(param1 == "burn" && buffs && buffs["burn"]) return true;
         if(hasAbyssDot104(param1)) return true;
         for(_loc1_ in manualSkillDots)
         {
            if(manualSkillDots[_loc1_] && manualSkillDots[_loc1_].round >= 0 && manualSkillDots[_loc1_].kind == param1) return true;
         }
         return false;
      }

      public function clearManualSkillDots() : void
      {
         var _loc1_:String = null;
         var _loc2_:Buff = null;
         if(!manualSkillDots) return;
         for(_loc1_ in manualSkillDots)
         {
            _loc2_ = manualSkillDots[_loc1_] ? manualSkillDots[_loc1_].visual as Buff : null;
            if(_loc2_ && m_buff && _loc2_.displayObject && _loc2_.displayObject.parent == m_buff) m_buff.removeChild(_loc2_.displayObject);
         }
         manualSkillDots = {};
      }

      private function tickManualLethalFloors() : void
      {
         var _loc1_:String = null;
         var _loc2_:Object = null;
         var _loc3_:int = 0;
         if(!manualLethalFloor) return;
         for(_loc1_ in manualLethalFloor)
         {
            _loc2_ = manualLethalFloor[_loc1_];
            if(!_loc2_) continue;
            if(_loc2_.justApplied === true)
            {
               _loc2_.justApplied = false;
               continue;
            }
            _loc2_.rounds = int(_loc2_.rounds) - 1;
            if(int(_loc2_.rounds) <= 0)
            {
               delete manualLethalFloor[_loc1_];
               _loc3_ = Math.max(0,int(_loc2_.expiryHeal));
               if(typeof _loc2_.expiryHealHpMaxFraction == "number" && isFinite(Number(_loc2_.expiryHealHpMaxFraction)) && Number(_loc2_.expiryHealHpMaxFraction) > 0)
               {
                  _loc3_ = Math.max(_loc3_,Math.max(0,int(hpMax * Number(_loc2_.expiryHealHpMaxFraction))));
               }
               if(_loc3_ > 0 && hp > 0)
               {
                  injured(_loc3_,1,DisplayTools.getAttrs("FX60_HEAL"),4,this,false,this);
               }
            }
         }
      }

      protected function showBuff(param1:Buff) : void
      {
         // Cleansing can run before this delayed visual callback. Only render
         // a Buff still owned by the unit, including independent DOT visuals.
         var active:Boolean = false;
         for each(var current:Buff in buffs) if(current === param1) active = true;
         if(!active && manualSkillDots)
            for each(var dot:Object in manualSkillDots) if(dot && dot.visual === param1) active = true;
         if(!active) return;
         if(!m_buff)
         {
            return;
         }
         if(param1.displayObject)
         {
            m_buff.addChild(param1.displayObject);
         }
      }

      public function addBuff(param1:String, param2:int, param3:Number = 0, param4:Number = 0, param5:int = -1, param6:Avatar = null) : void
      {
         if(yasuoImmune104(param1)) return;
         if(s2AnnieImmune() && Buff.LIST_DEBUFF.indexOf(param1)>=0) return;
         if(abilityState.channel && ["stun","silence","root","pull","push"].indexOf(param1)>=0) return;
         var _loc8_:* = 0;
         var _loc13_:String = null;
         var _loc9_:Boolean = false;
         var _loc6_:Number = Number(NaN);
         var sourceContext:Object = currentAbilityAttack();
         var source:Avatar = param6 || (sourceContext ? sourceContext.owner as Avatar : null);
         var manualEffect:Number = sourceContext ? Number(sourceContext.manualEffectMultiplier) : 1;
         if(!isFinite(manualEffect) || manualEffect <= 0) manualEffect = 1;
         if(param3 != 0 && param1 != "summon" && !(param1 == "shield" && abyssOrigin104 == "relic_shield")) param3 *= manualEffect;
         if(param1 == "shield" && ratioDamage104()) param3 = Tools.toInt(param3 * precisionRecovery105(source || this));
         if(param1 == "shield" && source) param3 *= source.getRecoveryTalentMultiplier();
         if(param1 == "shield" && source) param3 = source.abyssAmplifyHeal104(param3);
         var _loc11_:Buff = new Buff(param1,param2,param3);
         _loc11_.source = source;
         if(param1 == "poison" && source && GlobalData.$mConfig_simple.hero_skill_output_rate_104 != null) _loc11_.poisonHpRate104 = source.poisonSkillOutputRate104();
         var _loc12_:Buff = buffs[param1];
         var priorBurnLayers:int=param1=="burn" && _loc12_ && _loc12_.round>0 && _loc12_.value>0 ?
            Math.max(1,int(abilityState.sixReactionBurnLayers105)) : 0;
         // A timed revival must never shorten an existing permanent one.
         // Legacy bless uses value 0; the explicit timed_bless action uses 1.
         if(param1 == "bless" && _loc12_)
         {
            if(_loc12_.value <= 0 && _loc11_.value > 0) return;
            if(_loc11_.value <= 0 && _loc12_.value > 0) _loc11_.round = Math.max(_loc11_.round,_loc12_.round);
         }
         var _loc7_:GameMapLayer = GameMapLayer.gl;
         if(param5 < 0)
         {
            param5 = 35;
         }
         var _loc14_:Number = 0.75;
         param4 = GameMap.actionDelay + param4;
         var _loc10_:Number = 0;
         if(param1 == "weak" && abilityState.highlander) return;
         if(abilityState.sixIreliaImmune105 && SIX_IRELIA_IMMUNITIES.indexOf(param1)>=0) return;
         if(param1 == "silence")
         {
            _loc10_ = checkTalent(8);
         }
         else if(param1 == "weak")
         {
            _loc10_ = checkTalent(9);
         }
         else if(param1 == "poison")
         {
            _loc10_ = checkTalent(10);
         }
         else if(param1 == "burn")
         {
            _loc10_ = checkTalent(11);
         }
         else if(param1 == "sunder")
         {
            _loc10_ = checkTalent(12);
         }
         else if(param1 == "stun")
         {
            _loc10_ = checkTalent(13);
         }
         if(_loc10_ > 0)
         {
            _loc6_ = Random.getRandom();
            if(Tools.toInt(_loc10_ * 100) > _loc6_)
            {
               _loc8_ = 10526880;
               _loc8_ = 16777215;
               if(param1 == "silence")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30019) + GlobalLanguageStr.getLanguageStr(30037);
               }
               else if(param1 == "weak")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30015) + GlobalLanguageStr.getLanguageStr(30037);
               }
               else if(param1 == "poison")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30038) + GlobalLanguageStr.getLanguageStr(30037);
               }
               else if(param1 == "burn")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30028) + GlobalLanguageStr.getLanguageStr(30037);
               }
               else if(param1 == "sunder")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30017) + GlobalLanguageStr.getLanguageStr(30037);
               }
               else if(param1 == "stun")
               {
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30018) + GlobalLanguageStr.getLanguageStr(30037);
               }
               _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4 + 0.4,_loc13_,this,_loc8_,param5,_loc14_,null,65);
               return;
            }
         }
         if(param1 == "pull")
         {
            checkMove(true,param3,GameMap.currentAvatar,-1,true);
            return;
         }
         if(param1 == "push")
         {
            checkMove(false,param3,GameMap.currentAvatar,-1,true);
            return;
         }
         if(buffs["purify"])
         {
            if(Buff.LIST_DEBUFF.indexOf(param1) != -1)
            {
               removeBuff("purify",true);
               _loc8_ = 10526880;
               _loc13_ = GlobalLanguageStr.getLanguageStr(30025);
               _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4,_loc13_,this,_loc8_,param5,_loc14_);
               return;
            }
         }
         else if(buffs["evil"] && param1 != "purify")
         {
            if(Buff.LIST_BUFF.indexOf(param1) != -1)
            {
               removeBuff("evil");
               _loc8_ = 10526880;
               _loc13_ = GlobalLanguageStr.getLanguageStr(30025);
               _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4,_loc13_,this,_loc8_,param5,_loc14_);
               return;
            }
         }
         if(buffs["curse"] && Buff.LIST_BUFF.indexOf(param1) != -1 && param1 != "purify")
         {
            _loc8_ = 10526880;
            _loc13_ = GlobalLanguageStr.getLanguageStr(30025);
            _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4,_loc13_,this,_loc8_,param5,_loc14_);
            return;
         }
         if(param1 == "purify")
         {
            removeAllDebuff();
            if(_loc12_ && _loc12_.value > 0) return;
         }
         else if(param1 == "evil")
         {
            removeAllGoodBuff();
         }
         if(!_loc12_)
         {
            buffs[param1] = _loc11_;
            _loc7_.delayCall(showBuff,param4,_loc11_);
            _loc9_ = true;
         }
         else
         {
            switch(param1)
            {
               case "stun":
               case "silence":
               case "purify":
               case "evil":
               case "curse":
               case "taunt":
               case "bless":
                  if(_loc11_.round >= _loc12_.round)
                  {
                     removeBuff(param1,false,false);
                     buffs[param1] = _loc11_;
                     _loc7_.delayCall(showBuff,param4,_loc11_);
                     _loc9_ = true;
                  }
                  else
                  {
                     _loc8_ = 10526880;
                     _loc13_ = GlobalLanguageStr.getLanguageStr(30020);
                     _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4 + 0.4,_loc13_,this,_loc8_,param5,_loc14_,null,65);
                  }
                  break;
               case "root":
               case "weak":
               case "sunder":
               case "shield":
               case "strong":
               case "steel":
               case "armor":
               case "hitup":
               case "fleeup":
               case "critup":
               case "toughup":
               case "book_penetration":
                  if(_loc11_.value >= _loc12_.value)
                  {
                     removeBuff(param1,false,false);
                     buffs[param1] = _loc11_;
                     _loc7_.delayCall(showBuff,param4,_loc11_);
                     _loc9_ = true;
                  }
                  else
                  {
                     _loc8_ = 10526880;
                     _loc13_ = GlobalLanguageStr.getLanguageStr(30020);
                     _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4 + 0.4,_loc13_,this,_loc8_,param5,_loc14_,null,65);
                  }
                  break;
               case "poison":
               case "burn":
                  _loc12_.poisonHpRate104 = Math.max(_loc12_.poisonHpRate104,_loc11_.poisonHpRate104);
                  _loc12_.value = int(_loc12_.value * _loc12_.round / _loc11_.round + _loc11_.value);
                  // Native DOT merges into one pool; the latest accepted applier owns it.
                  _loc12_.source = _loc11_.source;
                  _loc12_.round = _loc11_.round;
                  _loc11_ = _loc12_;
                  _loc9_ = true;
            }
         }
         _loc13_ = "";
         if(_loc9_)
         {
            if(param1 == "stun" || param1 == "silence") delete abilityState.channel;
            switch(param1)
            {
               case "stun":
                  _loc8_ = 16777120;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30018) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "silence":
                  _loc8_ = 13684944;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30019) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "weak":
                  _loc8_ = 8396928;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30015) + GameMapTools.toPercentage(1 - 1 / (1 + _loc11_.value));
                  break;
               case "sunder":
                  _loc8_ = 9478352;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30017) + GameMapTools.toPercentage(1 - 1 / (1 + _loc11_.value));
                  break;
               case "poison":
                  _loc8_ = 53248;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30013) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "burn":
                  _loc8_ = 16737792;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30028) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "shield":
                  _loc8_ = 16777024;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30012) + _loc11_.value;
                  break;
               case "strong":
                  _loc8_ = 16744448;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30014) + GlobalLanguageStr.getLanguageStr(30000) + GameMapTools.toPercentage(_loc11_.value);
                  break;
               case "steel":
                  _loc8_ = 16763904;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30082) + GlobalLanguageStr.getLanguageStr(30000) + GameMapTools.toPercentage(_loc11_.value);
                  break;
               case "taunt":
                  _loc8_ = 16737792;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30027) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "purify":
                  _loc8_ = 10526975;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30016) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "evil":
                  _loc8_ = 10053222;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30080) + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "curse":
                  _loc8_ = 10053222;
                  _loc13_ = "诅咒" + _loc11_.round + GlobalLanguageStr.getLanguageStr(30002);
                  break;
               case "bless":
                  _loc8_ = 16777164;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30081);
                  break;
               case "hitup":
                  _loc8_ = 10526975;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30021) + "+" + _loc11_.value;
                  break;
               case "fleeup":
                  _loc8_ = 10526975;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30022) + "+" + _loc11_.value;
                  break;
               case "critup":
                  _loc8_ = 16751001;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30023) + "+" + _loc11_.value;
                  break;
               case "toughup":
                  _loc8_ = 16751001;
                  _loc13_ = GlobalLanguageStr.getLanguageStr(30024) + "+" + _loc11_.value;
            }
            if(_loc13_.length > 0)
            {
               if(param5 < 35)
               {
                  _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4,_loc13_,this,_loc8_,param5,_loc14_);
               }
               else
               {
                  _loc7_.delayCall(_loc7_.infoLayer.popTextForAvatar,param4 + 0.4,_loc13_,this,_loc8_,param5,_loc14_,null,65);
               }
            }
         }
         if(_loc9_ && _loc11_.type=="shield") queueVitalBar104(param4);
         if(param1=="stun" && hp>0 && buffs.stun)
         {
            kaisaNotifyStun104(this);
            if(GameMap.currentMap)
            {
               for each(var observer105:Avatar in GameMap.currentMap.getAliveList(otherTeam))
               {
                  if(observer105.line!=line || !observer105.skillB || !observer105.skillB.skills) continue;
                  var opening105:Array=observer105.sixStarPassive105();
                  if(opening105 && opening105[1]=="six_kennen_p") observer105.skillB.checkUse();
               }
            }
         }
         if(_loc9_)
         {
            s2AnnieStatus(param1);
            if(param1=="curse") sixBatchCurse105();
            if(param1=="stun") sixReactionStun105();
            if(param1=="burn" && param3>0)
            {
               abilityState.sixReactionBurnLayers105=priorBurnLayers+1;
               sixReactionBurnChanged105();
            }
         }

      }

      public function resetBuff() : void
      {
         var _loc1_:String = null;
         var _loc2_:Buff = null;
         removeAllBuff();
         if(skill2)
         {
            _loc1_ = skill2.getPassiveType();
            if(_loc1_)
            {
               switch(_loc1_)
               {
                  case "ae":
                     _loc2_ = new Buff("asuck",2147483647,skill2.getPassiveValue());
                     buffs["asuck"] = _loc2_;
                     break;
                  case "back":
                     _loc2_ = new Buff("back",2147483647,skill2.getPassiveValue());
                     buffs["back"] = _loc2_;
                     break;
                  case "avenge":
                     _loc2_ = new Buff("avenge",2147483647,skill2.getPassiveValue());
                     buffs["avenge"] = _loc2_;
               }
            }
         }
      }

      public function removeAllBuff() : void
      {
         var _loc1_:String = null;
         if(buffs)
         {
            for(_loc1_ in buffs)
            {
               removeBuff(_loc1_);
            }
         }
         clearManualSkillDots();
      }

      public function dispelShieldForSkill() : void
      {
         removeBuff("shield");
      }

      public function dispelGoodBuffsForSkill() : void
      {
         removeAllGoodBuff();
      }

      protected function removeAllGoodBuff() : void
      {
         removeIndependentShields104();
         abilityClearStates(false);
         var _loc1_:String = null;
         for(_loc1_ in buffs)
         {
            if(Buff.LIST_BUFF.indexOf(_loc1_) > -1)
            {
               removeBuff(_loc1_);
            }
         }
      }

      protected function removeAllDebuff() : void
      {
         skin2ClearDebuffs();
         abilityClearStates(true);
         var _loc1_:String = null;
         for(_loc1_ in buffs)
         {
            if(Buff.LIST_DEBUFF.indexOf(_loc1_) > -1)
            {
               removeBuff(_loc1_);
            }
         }
         clearManualSkillDots();
         abyssDots104 = null;
      }

      protected function removeBuff(param1:String, consume:Boolean = false, clearShields:Boolean = true) : void
      {
         abyssRemoveDots104(param1);
         if(param1=="shield" && clearShields) removeIndependentShields104();
         if(param1 == "root") delete abilityState.root;
         var _loc2_:Buff = buffs[param1];
         if(!_loc2_)
         {
            return;
         }
         if(consume && param1 == "purify" && _loc2_.value > 1)
         {
            --_loc2_.value;
            abilityFeedback("净化剩余"+int(_loc2_.value)+"层","FX_S9150_PURIFY",10526975);
            return;
         }
         var _loc3_:GameMapLayer = GameMapLayer.gl;
         if(_loc2_.displayObject)
         {
            _loc3_.delayCall(m_buff.removeChild,GameMap.actionDelay,_loc2_.displayObject);
         }
         delete buffs[param1];
         if(_loc2_.type=="shield") queueVitalBar104();
      }

      private var dotPopup104:Object = null;

      protected function checkBuff() : Boolean
      {
         dotPopup104 = {amount:0,color:53248,label:GlobalLanguageStr.getLanguageStr(30013)};
         try
         {
            return settleBuffs104();
         }
         finally
         {
            var popup:Object = dotPopup104;
            dotPopup104 = null;
            if(popup && popup.amount > 0)
            {
               GameMap.actionDelay += 0.5;
               GameMapLayer.gl.delayCall(GameMapLayer.gl.infoLayer.popInjuredForAvatar,GameMap.actionDelay,
                  String(popup.label)+String(popup.amount),this,uint(popup.color),35,0.75,null,null);
            }
         }
      }

      private function collectDotPopup104(amount:Number, kind:int) : void
      {
         dotPopup104.amount += Math.max(0,amount);
         if(kind == 7)
         {
            dotPopup104.color = 16737792;
            dotPopup104.label = GlobalLanguageStr.getLanguageStr(30029);
         }
      }

      protected function settleBuffs104() : Boolean
      {
         var _loc1_:Buff = null;
         var manualDotKey:String = null;
         var manualDot:Object = null;
         var manualDotAmount:int = 0;
         var manualDotRaw:Number = Number(NaN);
         var manualDotEffect:Object = null;
         if(abyssDots104 && abyssDots104.length)
         {
            abyssTickDots104();
            if(hp <= 0)
            {
               hp = 0;
               return true;
            }
         }
         if(yasuoNightRounds104>=0 && --yasuoNightRounds104<0) yasuoQueueNight104(false);
         if(yasuoVampRounds104>=0) --yasuoVampRounds104;
         tickManualLethalFloors();
         if(tryndUndyingActive)
         {
            if(tryndUndyingRounds <= 0)
            {
               tryndUndyingActive = false;
               tryndUndyingRounds = 0;
            }
            else
            {
               --tryndUndyingRounds;
            }
         }
         var _loc3_:String = null;
         var _loc5_:* = undefined;
         var _loc4_:int = 0;
         for(_loc3_ in buffs)
         {
            _loc1_ = buffs[_loc3_];
            // Only the new timed variant expires; legacy revival stays armed.
            if(_loc3_ == "bless" && _loc1_.value <= 0) continue;
            if(_loc3_ == "purify" && _loc1_.value > 0) continue;
            if(_loc3_=="sixReactionMfShield105") continue;
            --_loc1_.round;
            switch(_loc3_)
            {
               case "summon":
                  if(_loc1_.round < 0)
                  {
                     hp = 0;
                     return true;
                  }
                  break;
               case "poison":
               case "burn":
            }
            if(_loc1_.round < 0)
            {
               removeBuff(_loc3_,false,false);
            }
         }
         _loc1_ = buffs["poison"];
         if(_loc1_)
         {
            _loc5_ = DisplayTools.getAttrs("POISON_EFF");
            injured(Tools.toInt(_loc1_.value + damageAttack104()[18] * hpMax * (_loc1_.poisonHpRate104 > 0 ? _loc1_.poisonHpRate104 : 1)),1,_loc5_,6,_loc1_.source,false,_loc1_.source,null,"poison");
            if(hp <= 0)
            {
               hp = 0;
               return true;
            }
            if(_loc1_.round <= 0)
            {
               removeBuff(_loc1_.type);
            }
         }
         _loc1_ = buffs["burn"];
         if(_loc1_)
         {
            _loc5_ = DisplayTools.getAttrs("BURN_EFF");
            injured(Tools.toInt(_loc1_.value),1,_loc5_,7,_loc1_.source,false,_loc1_.source,null,"burn");
            if(hp <= 0)
            {
               hp = 0;
               return true;
            }
            if(_loc1_.round <= 0)
            {
               removeBuff(_loc1_.type);
            }
         }
         if(manualSkillDots)
         {
            for(manualDotKey in manualSkillDots)
            {
               manualDot = manualSkillDots[manualDotKey];
               if(!manualDot) continue;
               --manualDot.round;
               manualDotRaw = Number(manualDot.apTick) + Number(manualDot.hpMaxFraction) * hpMax;
               manualDotAmount = Tools.toInt(manualDotRaw);
               if(manualDot.bookRemaining !== undefined)
               {
                  manualDotAmount = Math.ceil(Number(manualDot.bookRemaining) / Math.max(1,int(manualDot.bookTicks)));
                  manualDot.bookRemaining -= manualDotAmount;
                  manualDot.bookTicks--;
               }
               if(manualDotAmount > 0)
               {
                  manualDotEffect = DisplayTools.getAttrs(manualDot.kind == "burn" ? "BURN_EFF" : "POISON_EFF");
                  injured(manualDotAmount,1,manualDotEffect,manualDot.kind == "burn" ? 7 : 6,manualDot.source as Avatar,false,manualDot.source as Avatar,null,String(manualDot.kind));
                  if(hp <= 0)
                  {
                     hp = 0;
                     return true;
                  }
               }
               if(manualDot.round <= 0)
               {
                  var manualDotVisual:Buff = manualDot.visual as Buff;
                  if(manualDotVisual && m_buff && manualDotVisual.displayObject && manualDotVisual.displayObject.parent == m_buff) m_buff.removeChild(manualDotVisual.displayObject);
                  delete manualSkillDots[manualDotKey];
               }
            }
         }
         var _loc2_:GameMap = GameMap.currentMap;
         if(_loc2_.gameMapData.win[0] == -3)
         {
            if(_loc2_.roundNum >= GlobalData.$mConfig_simple.battle[5] - 1)
            {
               _loc4_ = 2 + _loc2_.roundNum - GlobalData.$mConfig_simple.battle[5];
               _loc5_ = DisplayTools.getAttrs("DEAD_MODE_EFF");
               injured(Tools.toInt(_loc4_ * damageAttack104()[19] * hp),1,_loc5_,8);
               if(hp <= 0)
               {
                  hp = 0;
                  return true;
               }
            }
         }
         return false;
      }

      public function activateTryndUndying(param1:int) : void
      {
         tryndUndyingRounds = Math.max(0,param1);
         tryndUndyingActive = tryndUndyingRounds > 0;
      }

      public function getScale() : Number
      {
         if(isBoss)
         {
            return 1.3;
         }
         if(!buffs)
         {
            return 0.8;
         }
         if(buffs["summon"])
         {
            return 0.8;
         }
         return 1;
      }

      public function getBookSkill() : SkillSet
      {
         var _loc2_:SkillSet = null;
         var _loc1_:* = null;
         for each(_loc1_ in equips)
         {
            _loc2_ = _loc1_.getBookSkill(this);
            if(_loc2_)
            {
               return _loc2_;
            }
         }
         return null;
      }

      public function getSymp() : Array
      {
         var _loc1_:* = null;
         var _loc2_:Array = [0,0,0,0];
         for each(_loc1_ in equips)
         {
            if(_loc1_.symp >= 0)
            {
               _loc2_[_loc1_.symp]++;
            }
         }
         return _loc2_;
      }

      public function getSympType() : Array
      {
         var _loc2_:Array = getSymp();
         var _loc1_:Array = [];
         if(_loc2_[0] >= 2)
         {
            _loc1_.push("hp");
         }
         if(_loc2_[1] >= 2)
         {
            _loc1_.push("ap");
         }
         if(_loc2_[2] >= 2)
         {
            _loc1_.push("de_ph");
         }
         if(_loc2_[3] >= 2)
         {
            _loc1_.push("de_ma");
         }
         return _loc1_;
      }

      private function getCultivationGainFromSlope(param1:Number, param2:int) : int
      {
         if(isWeightedCultivation()) return param2;
         var _loc3_:Number = Number(GlobalData.$mConfig_simple.culture.pith_growth_rate);
         if(isNaN(_loc3_) || _loc3_ <= 0)
         {
            _loc3_ = 0.1;
         }
         return int(param1 * param2 * _loc3_);
      }

      public function getCultivationStatGain(param1:String, param2:int) : int
      {
         var _loc3_:AvatarData = avatarData;
         var _loc4_:Number = 0;
         if(param1 == "hp")
         {
            _loc4_ = _loc3_.hp1;
         }
         else if(param1 == "ap")
         {
            _loc4_ = _loc3_.ap1;
         }
         else if(param1 == "de_ph")
         {
            _loc4_ = _loc3_.d11;
         }
         else if(param1 == "de_ma")
         {
            _loc4_ = _loc3_.d21;
         }
         return getCultivationGainFromSlope(_loc4_,param2);
      }

      private function applyOwnedGuildResearch(param1:String, param2:int) : int
      {
         var _loc3_:Object = null;
         var _loc4_:Object = null;
         var _loc5_:Object = null;
         var _loc6_:Object = null;
         var _loc7_:Array = null;
         var _loc8_:String = null;
         var _loc9_:Number = 0;
         var _loc10_:Number = 0;
         var _loc11_:Boolean = false;
         if(isOthers || team == 2 || !id || (mData && mData.exploration_hero_only === true))
         {
            return param2;
         }
         _loc3_ = GlobalData.$userData;
         if(!_loc3_ || !_loc3_.avatars || !_loc3_.attrs)
         {
            return param2;
         }
         _loc4_ = _loc3_.avatars[id];
         if(!_loc4_ && mData && mData.id)
         {
            _loc4_ = _loc3_.avatars[mData.id];
         }
         if(!_loc4_)
         {
            return param2;
         }
         _loc5_ = _loc3_.attrs.guild_graduate_skill;
         _loc6_ = GlobalData.$mGuild_simple;
         if(!_loc5_ || !_loc6_ || !_loc6_.guild_graduate || !_loc6_.guild_graduate.guild_graduate_skill)
         {
            return param2;
         }
         _loc6_ = _loc6_.guild_graduate.guild_graduate_skill;
         for(_loc8_ in _loc5_)
         {
            _loc9_ = Number(_loc5_[_loc8_]);
            if(!(isNaN(_loc9_) || _loc9_ <= 0 || !_loc6_[_loc8_] || !_loc6_[_loc8_].level))
            {
               _loc7_ = _loc6_[_loc8_].effect_attributes as Array;
               if(_loc7_)
               {
                  _loc11_ = false;
                  for each(var _target:String in _loc7_)
                  {
                     if(_target == param1)
                     {
                        _loc11_ = true;
                        break;
                     }
                  }
                  if(_loc11_)
                  {
                     _loc4_ = _loc6_[_loc8_].level[String(int(_loc9_))];
                     if(_loc4_)
                     {
                        _loc10_ = Number(_loc4_.value);
                        if(!(isNaN(_loc10_) || _loc10_ <= 0))
                        {
                           param2 = Tools.toInt(param2 * (1 + _loc10_ / 100));
                        }
                     }
                  }
               }
            }
         }
         return param2;
      }

      public function getHpMax(param1:int = -1, param2:int = -1, param3:Boolean = false) : int
      {
         var _loc4_:int = 0;
         var _loc6_:* = null;
         var _loc7_:int = 0;
         var _loc5_:int = 0;
         if(hpMax)
         {
            return hpMax;
         }
         if(param1 < 0)
         {
            param1 = lv;
         }
         if(getStar() != 6)
         {
            param1 += getPhaseLv();
         }
         if(param2 < 0)
         {
            param2 = hpP;
         }
         var _loc8_:AvatarData = avatarData;
         var _baseHp:Number = _loc8_.hp0 + _loc8_.hp1 * (param1 - 1);
         if(getStar() == 6 && phase > 0)
         {
            _baseHp *= Math.pow(1.12,phase);
         }
         _loc4_ = int(_baseHp) + getCultivationGainFromSlope(_loc8_.hp1,param2);
         if(param3)
         {
            _loc7_ = 0;
            for each(_loc6_ in equips)
            {
               _loc7_ += _loc6_.getHpMax(-1,true);
            }
            if(skill2)
            {
               _loc7_ = Tools.toInt(_loc7_ * skill2.getEquipRate("hp"));
            }
            _loc4_ += _loc7_;
            _loc5_ = int(getSymp()[0]);
            if(_loc5_ >= 2)
            {
               _loc4_ += _loc5_ * GlobalData.$mConfig_simple.dust.symp[1][_loc5_ - 2] * GlobalData.$mConfig_simple.dust.symp[0][0];
            }
         }
         if(mDestiny)
         {
            _loc4_ = (_loc4_ + mDestiny.hp) * (1 + mDestiny.hpP);
         }
         if(mDNdata)
         {
            _loc4_ += mDNdata.hp;
         }
         _loc4_ = applyOwnedGuildResearch("hp",_loc4_);
         _loc4_ = Tools.toInt(_loc4_ * (1 + getBookCombatBonus("hp")));
         _loc4_ = Tools.toInt(_loc4_ * (1 + ownGrowthValue("hp") / 100));
         _loc4_ = Tools.toInt(bondPanel104("hp",_loc4_));
         if(param3) _loc4_ = applyAbyssRelic104("hp",_loc4_);
         return Math.max(_loc4_,0);
      }

      public function getBookCombatBonus(stat:String) : Number
      {
         var value:Number = 0;
         if(skill2 && !skill2.skillSetData.pl && skill2.skills)
         {
            for each(var action:Array in skill2.skills)
            {
               if(action[0] == "book_passive" && action[2] == stat)
               {
                  value = stat == "penetration" ? Math.max(value,Number(action[1])) : value + Number(action[1]);
               }
            }
         }
         if(stat == "penetration")
         {
            if(buffs && buffs["book_penetration"]) value = Math.max(value,Number(buffs["book_penetration"].value));
            return Math.max(0,Math.min(1,value));
         }
         return isFinite(value) ? Math.max(0,value) : 0;
      }

      public function addBookBurn(total:int, rounds:int, source:Avatar) : void
      {
         if(total <= 0 || rounds < 1 || hp <= 0) return;
         var key:String = "book-burn:" + (++manualDotSerial);
         addManualSkillDot(key,"burn",0,0,rounds,source,3);
         if(manualSkillDots && manualSkillDots[key])
         {
            manualSkillDots[key].bookRemaining = total;
            manualSkillDots[key].bookTicks = rounds;
            sixReactionBurnChanged105();
         }
      }

      private function applyBookAttackEffects(target:Avatar, dealt:int) : void
      {
         if(!target || target.hp <= 0 || dealt <= 0 || target.team == team) return;
         var burn:Number = getBookCombatBonus("attack_burn");
         if(burn > 0) target.addBookBurn(Tools.toInt(dealt * burn),3,this);
         var chance:Number = getBookCombatBonus("attack_curse");
         if(chance > 0 && Random.getRandom(10000) < Math.round(chance * 10000)) target.addBuff("curse",3);
      }

      public function getDamage(param1:int = -1, param2:int = -1, param3:Boolean = false) : int
      {
         var _loc6_:int = 0;
         var _loc10_:AvatarData = null;
         var _loc8_:* = null;
         var _loc9_:int = 0;
         var _loc7_:int = 0;
         var _loc5_:Buff = null;
         if(hpMax)
         {
            _loc6_ = ap;
         }
         else
         {
            if(param1 < 0)
            {
               param1 = lv;
            }
            if(getStar() != 6)
            {
               param1 += getPhaseLv();
            }
            if(param2 < 0)
            {
               param2 = apP;
            }
            _loc10_ = avatarData;
            var _baseAp:Number = _loc10_.ap0 + _loc10_.ap1 * (param1 - 1);
            if(getStar() == 6 && phase > 0)
            {
               _baseAp *= Math.pow(1.12,phase);
            }
            _loc6_ = int(_baseAp) + getCultivationGainFromSlope(_loc10_.ap1,param2);
            if(param3)
            {
               _loc9_ = 0;
               for each(_loc8_ in equips)
               {
                  _loc9_ += _loc8_.getDamage(-1,true);
               }
               if(skill2)
               {
                  _loc9_ = Tools.toInt(_loc9_ * skill2.getEquipRate("ap"));
               }
               _loc6_ += _loc9_;
               _loc7_ = int(getSymp()[1]);
               if(_loc7_ >= 2)
               {
                  _loc6_ += _loc7_ * GlobalData.$mConfig_simple.dust.symp[1][_loc7_ - 2] * GlobalData.$mConfig_simple.dust.symp[0][1];
               }
            }
            if(mDestiny)
            {
               _loc6_ = Tools.toInt((_loc6_ + mDestiny.ap) * (1 + mDestiny.apP));
            }
            if(mDNdata)
            {
               _loc6_ += mDNdata.ap;
            }
            _loc6_ = applyOwnedGuildResearch("ap",_loc6_);
         _loc6_ = Tools.toInt(_loc6_ * (1 + getBookCombatBonus("ap")));
         _loc6_ = Tools.toInt(_loc6_ * (1 + ownGrowthValue("attack") / 100));
         _loc6_ = Tools.toInt(bondPanel104("ap",_loc6_));
         if(param3) _loc6_ = applyAbyssRelic104("ap",_loc6_);
         }
         var _loc4_:Number = 1;
         if(buffs)
         {
            _loc5_ = buffs["weak"] as Buff;
            if(_loc5_)
            {
               _loc4_ /= 1 + _loc5_.value;
            }
            _loc5_ = buffs["strong"] as Buff;
            if(_loc5_)
            {
               _loc4_ *= 1 + _loc5_.value;
            }
         }
         _loc6_ = Tools.toInt(_loc6_ * (1 + getManualBattleStack("attack") + getManualTimedStack("attack")) * _loc4_);
         if(hpMax && abilityEntryAttack > 0) _loc6_ += int(abilityEntryAttack * (abilityState.evilStackBonus != null ? Number(abilityState.evilStackBonus) : 0.03 * int(abilityState.evilStacks)));
         if(hpMax && this.abilityState && int(this.abilityState.santaStacks) > 0) _loc6_ = Tools.toInt(_loc6_ * (1+(skillB && skillB.skills && skillB.skills.length && skillB.skills[0][0]=="santa_kill" ? Number(skillB.skills[0][3]) : 0.05)*int(this.abilityState.santaStacks)));
         if(this.yasuoNightRounds104>=0) _loc6_ = Tools.toInt(_loc6_*1.75);
         return Math.max(_loc6_,0);
      }

      public function getDefenseAgainst(source:Avatar, damageType:int) : int
      {
         var penetration:Number = source ? source.getBookCombatBonus("penetration") : 0;
         if(source && damageType==1) {
            if(s2LiveMark(this,"wanted") && skin2.wanted.owner===source) penetration=Math.max(penetration,source.s2Value(source.skill0,"penetration"));
            if(source.skin2.penetrationEnd && source.manualOwnerActionSerial<=source.skin2.penetrationEnd) penetration=Math.max(penetration,source.s2Value(source.skill1,"penetration"));
         }
         var talent:Number = checkTalent(damageType == 1 ? 2 : 3);
         var defense:Number;
         if(penetration <= 0)
         {
            defense = damageType == 1 ? getDePh() : getDeMa();
            return Tools.toInt(defense * (1 + talent));
         }
         var sunder:Number = buffs && buffs["sunder"] ? Math.max(0,Number(buffs["sunder"].value)) : 0;
         var reduction:Number = Math.max(penetration,sunder / (1 + sunder));
         defense = damageType == 1 ? getPhysicalDefense(-1,-1,false,true) : getMagicDefense(-1,-1,false,true);
         return Math.max(0,Tools.toInt(defense * (1 + talent) * (1 - reduction)));
      }

      public function getDePh(param1:int = -1, param2:int = -1, param3:Boolean = false) : int
      {
         return getPhysicalDefense(param1,param2,param3,false);
      }

      private function getPhysicalDefense(param1:int, param2:int, param3:Boolean, ignoreSunder:Boolean) : int
      {
         var _loc4_:int = 0;
         var _loc10_:AvatarData = null;
         var _loc8_:* = null;
         var _loc9_:int = 0;
         var _loc7_:int = 0;
         var _loc6_:Buff = null;
         if(hpMax)
         {
            _loc4_ = dePh;
         }
         else
         {
            if(param1 < 0)
            {
               param1 = lv;
            }
            if(getStar() != 6)
            {
               param1 += getPhaseLv();
            }
            if(param2 < 0)
            {
               param2 = dePhP;
            }
            _loc10_ = avatarData;
            var _baseDePh:Number = _loc10_.d10 + _loc10_.d11 * (param1 - 1);
            if(getStar() == 6 && phase > 0)
            {
               _baseDePh *= Math.pow(1.12,phase);
            }
            _loc4_ = int(_baseDePh) + getCultivationGainFromSlope(_loc10_.d11,param2);
            if(param3)
            {
               _loc9_ = 0;
               for each(_loc8_ in equips)
               {
                  _loc9_ += _loc8_.getDePh();
               }
               if(skill2)
               {
                  _loc9_ = Tools.toInt(_loc9_ * skill2.getEquipRate("de_ph"));
               }
               _loc4_ += _loc9_;
               _loc7_ = int(getSymp()[2]);
               if(_loc7_ >= 2)
               {
                  _loc4_ += _loc7_ * GlobalData.$mConfig_simple.dust.symp[1][_loc7_ - 2] * GlobalData.$mConfig_simple.dust.symp[0][2];
               }
            }
            if(mDestiny)
            {
               _loc4_ = (_loc4_ + mDestiny.de_ph) * (1 + mDestiny.de_phP);
            }
            if(mDNdata)
            {
               _loc4_ += mDNdata.de_ph;
            }
            _loc4_ = applyOwnedGuildResearch("de_ph",_loc4_);
         _loc4_ = Tools.toInt(_loc4_ * (1 + getBookCombatBonus("de_ph")));
         _loc4_ = Tools.toInt(_loc4_ * (1 + ownGrowthValue("defense") / 100));
         _loc4_ = Tools.toInt(bondPanel104("de_ph",_loc4_));
         if(param3) _loc4_ = applyAbyssRelic104("de_ph",_loc4_);
         }
         var _loc5_:Number = 1;
         if(buffs)
         {
            _loc6_ = buffs["sunder"] as Buff;
            if(_loc6_ && !ignoreSunder)
            {
               _loc5_ /= 1 + _loc6_.value;
            }
            _loc6_ = buffs["steel"] as Buff;
            if(_loc6_)
            {
               _loc5_ *= 1 + _loc6_.value;
            }
         }
          _loc4_ = Tools.toInt((_loc4_ * (1 + getManualBattleStack("defense")) +
             Number(abilityState.sixReactionDefense105_dePh || 0)) * _loc5_);
         return Math.max(Tools.toInt(_loc4_ * (buffs && buffs["armor"] ? 1 + Number(buffs["armor"].value) : 1)),0);
      }

      public function getDeMa(param1:int = -1, param2:int = -1, param3:Boolean = false) : int
      {
         return getMagicDefense(param1,param2,param3,false);
      }

      private function getMagicDefense(param1:int, param2:int, param3:Boolean, ignoreSunder:Boolean) : int
      {
         var _loc4_:int = 0;
         var _loc10_:AvatarData = null;
         var _loc8_:* = null;
         var _loc9_:int = 0;
         var _loc7_:int = 0;
         var _loc6_:Buff = null;
         if(hpMax)
         {
            _loc4_ = deMa;
         }
         else
         {
            if(param1 < 0)
            {
               param1 = lv;
            }
            if(getStar() != 6)
            {
               param1 += getPhaseLv();
            }
            if(param2 < 0)
            {
               param2 = deMaP;
            }
            _loc10_ = avatarData;
            var _baseDeMa:Number = _loc10_.d20 + _loc10_.d21 * (param1 - 1);
            if(getStar() == 6 && phase > 0)
            {
               _baseDeMa *= Math.pow(1.12,phase);
            }
            _loc4_ = int(_baseDeMa) + getCultivationGainFromSlope(_loc10_.d21,param2);
            if(param3)
            {
               _loc9_ = 0;
               for each(_loc8_ in equips)
               {
                  _loc9_ += _loc8_.getDeMa();
               }
               if(skill2)
               {
                  _loc9_ = Tools.toInt(_loc9_ * skill2.getEquipRate("de_ma"));
               }
               _loc4_ += _loc9_;
               _loc7_ = int(getSymp()[3]);
               if(_loc7_ >= 2)
               {
                  _loc4_ += _loc7_ * GlobalData.$mConfig_simple.dust.symp[1][_loc7_ - 2] * GlobalData.$mConfig_simple.dust.symp[0][3];
               }
            }
            if(mDestiny)
            {
               _loc4_ = (_loc4_ + mDestiny.de_ma) * (1 + mDestiny.de_maP);
            }
            if(mDNdata)
            {
               _loc4_ += mDNdata.de_ma;
            }
            _loc4_ = applyOwnedGuildResearch("de_ma",_loc4_);
         _loc4_ = Tools.toInt(_loc4_ * (1 + getBookCombatBonus("de_ma")));
         _loc4_ = Tools.toInt(_loc4_ * (1 + ownGrowthValue("defense") / 100));
         _loc4_ = Tools.toInt(bondPanel104("de_ma",_loc4_));
         if(param3) _loc4_ = applyAbyssRelic104("de_ma",_loc4_);
         }
         var _loc5_:Number = 1;
         if(buffs)
         {
            _loc6_ = buffs["sunder"] as Buff;
            if(_loc6_ && !ignoreSunder)
            {
               _loc5_ /= 1 + _loc6_.value;
            }
            _loc6_ = buffs["steel"] as Buff;
            if(_loc6_)
            {
               _loc5_ *= 1 + _loc6_.value;
            }
         }
          _loc4_ = Tools.toInt((_loc4_ * (1 + getManualBattleStack("defense")) +
             Number(abilityState.sixReactionDefense105_deMa || 0)) * _loc5_);
         return Math.max(_loc4_,0);
      }

      public function getSpeed(param1:Boolean = false) : int
      {
         var _loc5_:int = 0;
         var _loc4_:* = null;
         var _loc3_:Buff = null;
         if(hpMax)
         {
            _loc5_ = speed;
         }
         else
         {
            _loc5_ = avatarData.speed;
            if(param1)
            {
               for each(_loc4_ in equips)
               {
                  _loc5_ += _loc4_.getSpeed();
               }
            }
         }
         var _loc2_:Number = 1;
         if(buffs)
         {
            _loc3_ = buffs["weak"] as Buff;
            if(_loc3_)
            {
               _loc2_ /= 1 + _loc3_.value;
            }
            _loc3_ = buffs["strong"] as Buff;
            if(_loc3_)
            {
               _loc2_ *= 1 + _loc3_.value;
            }
         }
         if(GameMap.currentMap && !initializingFightAttributes)
         {
            _loc2_ *= sixFollowupSpeed105();
            if(hpMax && (skillB || abilityState.sixBatchTfMove105)) _loc2_ *= sixBatchSpeed105();
         }
         return Tools.toInt(_loc5_ * _loc2_);
      }

      public function getRange(param1:Boolean = false) : int
      {
         var _loc3_:int = 0;
         var _loc2_:* = null;
         if(GameMap.currentMap && !initializingFightAttributes && hpMax && skillB && sixBatchKayleStage105()>0) return 3000;
         if(isFinite(manualAttackRangeOverride) && manualAttackRangeOverride > 0)
         {
            _loc3_ = int(manualAttackRangeOverride);
         }
         else if(hpMax)
         {
            _loc3_ = range;
         }
         else
         {
            _loc3_ = avatarData.range;
            if(param1)
            {
               for each(_loc2_ in equips)
               {
                  _loc3_ += _loc2_.getRange();
               }
            }
         }
         // Front lines cannot move closer than MIN_SPACE_POS. Apply the
         // summon floor after policy overrides and keep zero-range units inert.
         if(_loc3_ > 0 && this.isManualSummonUnit && !abilityState.sixBatchSand105)
         {
            return Math.max(_loc3_,350,GameMapConfig.MIN_SPACE_POS);
         }
         return _loc3_;
      }

      public function getHit() : int
      {
         var _loc2_:* = null;
         var _loc4_:int = 0;
         var _loc1_:Buff = null;
         var _loc3_:int = 0;
         if(hpMax)
         {
            _loc3_ = hit;
         }
         else
         {
            _loc3_ = mData && mData.hit != null ? Math.max(0,int(mData.hit)) : 0;
            _loc4_ = 0;
            for each(_loc2_ in equips)
            {
               _loc4_ += _loc2_.getHit(-1,true);
            }
            if(skill2)
            {
               _loc4_ = Tools.toInt(_loc4_ * skill2.getEquipRate("hit"));
            }
            _loc3_ += _loc4_;
            if(mDestiny)
            {
               _loc3_ = (_loc3_ + mDestiny.hit) * (1 + mDestiny.hitP);
            }
         }
         if(!hpMax) _loc3_ = Tools.toInt(_loc3_ * (1 + getBookCombatBonus("hit")));
         if(!hpMax) _loc3_ = Tools.toInt(bondPanel104("hit",_loc3_));
         if(!hpMax) _loc3_ = applyAbyssRelic104("hit",_loc3_);
         if(hpMax && abilityState.sixBatchKayleHit105) _loc3_+=int(abilityState.sixBatchKayleHit105);
         if(buffs)
         {
            _loc1_ = buffs["hitup"] as Buff;
            if(_loc1_)
            {
               _loc3_ += _loc1_.value;
            }
         }
         return _loc3_ + (initializingFightAttributes ? 0 : teamTalentFlat("team_hit")) + (this.abilityState ? int(this.abilityState.polarCastHit) + int(this.abilityState.veigarCastHit) : 0);
      }

      public function getFlee() : int
      {
         var _loc3_:* = null;
         var _loc4_:int = 0;
         var _loc1_:Buff = null;
         var _loc2_:int = 0;
         if(hpMax)
         {
            _loc2_ = flee;
         }
         else
         {
            _loc2_ = mData && mData.flee != null ? Math.max(0,int(mData.flee)) : 0;
            _loc4_ = 0;
            for each(_loc3_ in equips)
            {
               _loc4_ += _loc3_.getFlee(-1,true);
            }
            if(skill2)
            {
               _loc4_ = Tools.toInt(_loc4_ * skill2.getEquipRate("flee"));
            }
            _loc2_ += _loc4_;
            if(mDestiny)
            {
               _loc2_ = (_loc2_ + mDestiny.flee) * (1 + mDestiny.fleeP);
            }
         }
         if(!hpMax) _loc2_ = Tools.toInt(_loc2_ * (1 + getBookCombatBonus("flee")));
         if(!hpMax) _loc2_ = Tools.toInt(bondPanel104("flee",_loc2_));
         if(!hpMax) _loc2_ = applyAbyssRelic104("flee",_loc2_);
         if(buffs)
         {
            _loc1_ = buffs["fleeup"] as Buff;
            if(_loc1_)
            {
               _loc2_ += _loc1_.value;
            }
         }
         return _loc2_ + int(getManualBattleStack("flee")) + (initializingFightAttributes ? 0 : teamTalentFlat("team_flee"));
      }

      public function getCrit() : int
      {
         var _loc3_:* = null;
         var _loc4_:int = 0;
         var _loc1_:Buff = null;
         var _loc2_:int = 0;
         if(hpMax)
         {
            _loc2_ = crit;
         }
         else
         {
            _loc2_ = mData && mData.crit != null ? Math.max(0,int(mData.crit)) : 0;
            _loc4_ = 0;
            for each(_loc3_ in equips)
            {
               _loc4_ += _loc3_.getCrit(-1,true);
            }
            if(skill2)
            {
               _loc4_ = Tools.toInt(_loc4_ * skill2.getEquipRate("crit"));
            }
            _loc2_ += _loc4_;
            if(mDestiny)
            {
               _loc2_ = (_loc2_ + mDestiny.crit) * (1 + mDestiny.critP);
            }
         }
         if(!hpMax) _loc2_ = Tools.toInt(_loc2_ * (1 + getBookCombatBonus("crit")));
         if(!hpMax) _loc2_ = Tools.toInt(bondPanel104("crit",_loc2_));
         if(!hpMax) _loc2_ = applyAbyssRelic104("crit",_loc2_);
         if(abilityState && abilityState.sixPolarTurns105)
            _loc2_ += int(_loc2_*int(abilityState.sixPolarTurns105)*Number(abilityState.sixPolarGrowth105));
         var sixBatchYasuo:Array=GameMap.currentMap && !initializingFightAttributes && hpMax && this.skillB ? sixBatchPassive105("yasuo") : null;
         if(sixBatchYasuo) _loc2_=int(_loc2_*Number(sixBatchYasuo[4]));
         if(buffs)
         {
            _loc1_ = buffs["critup"] as Buff;
            if(_loc1_)
            {
               _loc2_ += _loc1_.value;
            }
         }
         return _loc2_ + yasuoCritBonus104 + (initializingFightAttributes ? 0 : teamTalentFlat("team_crit"));
      }

      public function getTough() : int
      {
         var _loc3_:* = null;
         var _loc4_:int = 0;
         var _loc1_:Buff = null;
         var _loc2_:int = 0;
         if(hpMax)
         {
            _loc2_ = tough;
         }
         else
         {
            _loc2_ = mData && mData.tough != null ? Math.max(0,int(mData.tough)) : 0;
            _loc4_ = 0;
            for each(_loc3_ in equips)
            {
               _loc4_ += _loc3_.getTough(-1,true);
            }
            if(skill2)
            {
               _loc4_ = Tools.toInt(_loc4_ * skill2.getEquipRate("tough"));
            }
            _loc2_ += _loc4_;
            if(mDestiny)
            {
               _loc2_ = (_loc2_ + mDestiny.tough) * (1 + mDestiny.toughP);
            }
         }
         if(!hpMax) _loc2_ = Tools.toInt(_loc2_ * (1 + getBookCombatBonus("tough")));
         if(!hpMax) _loc2_ = Tools.toInt(bondPanel104("tough",_loc2_));
         if(!hpMax) _loc2_ = applyAbyssRelic104("tough",_loc2_);
         if(buffs)
         {
            _loc1_ = buffs["toughup"] as Buff;
            if(_loc1_)
            {
               _loc2_ += _loc1_.value;
            }
         }
         return _loc2_ + (initializingFightAttributes ? 0 : teamTalentFlat("team_tough"));
      }

      public function getLoveList() : Array
      {
         var _loc3_:int = 0;
         var _loc2_:Array = [0,loveExp,0];
         var _loc1_:Array = GlobalData.$mConfig_simple.love_up;
         if(!_loc1_)
         {
            return [0,0,2147483647];
         }
         _loc3_ = 0;
         while(_loc3_ < _loc1_[0])
         {
            _loc2_[2] = _loc1_[1] * _loc2_[0] + _loc1_[2];
            if(_loc2_[1] < _loc2_[2])
            {
               break;
            }
            _loc2_[0]++;
            _loc2_[1] -= _loc2_[2];
            _loc3_++;
         }
         if(_loc2_[0] == _loc1_[0])
         {
            _loc2_[2] = 2147483647;
         }
         return _loc2_;
      }

      public function getSkillPro() : Number
      {
         var _loc1_:int = this.skill0 ? this.skill0.lv : 0;
         var _loc2_:Number = avatarData ? avatarData.skillUpP : 1;
         return _loc1_ * getStar() * _loc2_;
      }

      public function getSkillProMother() : Number
      {
         var _loc1_:int = this.skill0 ? this.skill0.lv : 0;
         return (_loc1_ + 1) * getStar();
      }

      public function getAllExp(param1:int = -1, param2:Boolean = false) : int
      {
         var _loc3_:int = 0;
         if(param1 < 0)
         {
            param1 = lv;
         }
         var _loc5_:Array = GlobalData.$mConfig_simple.avatar_exp;
         var _loc8_:int = int(_loc5_[0]);
         var _loc7_:int = int(_loc5_[1]);
         var _loc9_:int = int(_loc5_[2]);
         var _loc4_:int = getLvMax();
         var _loc6_:int = exp;
         if(param2)
         {
            if(param1 >= _loc4_)
            {
               param1 = _loc4_;
               _loc6_ = 0;
            }
         }
         var _loc10_:Array = getExperienceCurve();
         if(_loc10_ != null && param1 >= 1 && param1 <= _loc10_.length)
         {
            _loc3_ = int(_loc10_[param1 - 1] * avatarData.expRate);
         }
         else
         {
            _loc3_ = (_loc8_ / 3 * param1 * param1 * param1 + (_loc7_ - _loc8_) / 2 * param1 * param1 + (_loc8_ / 6 - _loc7_ / 2 + _loc9_) * param1 - _loc9_) * avatarData.expRate;
         }
         return _loc3_ + _loc6_;
      }

      public function getOfferExp(param1:int = -1) : int
      {
         var _loc2_:int = getAllExp(param1);
         var _loc4_:Number = Number((GlobalData.$mConfig_simple.provide_exp as Array)[getStar() - 1]);
         var _loc3_:int = avatarData.offerExp;
         return _loc2_ * _loc4_ + _loc3_;
      }

      public function getNextExp(param1:int = -1) : int
      {
         if(param1 < 0)
         {
            param1 = lv;
         }
         if(param1 >= getLvMax())
         {
            return 2147483647;
         }
         var _loc2_:Array = GlobalData.$mConfig_simple.avatar_exp;
         var _loc4_:int = int(_loc2_[0]);
         var _loc3_:int = int(_loc2_[1]);
         var _loc5_:int = int(_loc2_[2]);
         var _loc6_:Array = getExperienceCurve();
         if(_loc6_ != null && param1 >= 1 && param1 < _loc6_.length)
         {
            return int(_loc6_[param1] * avatarData.expRate) - int(_loc6_[param1 - 1] * avatarData.expRate);
         }
         return avatarData.expRate * (_loc4_ * param1 * param1 + _loc3_ * param1 + _loc5_);
      }

      public function getIdValue() : Number
      {
         return 0.001 * GlobalData.baseModHeroId(avatarData.id).split("_")[1];
      }

      private function getExperienceCurve() : Array
      {
         var curves:Object = GlobalData.$mConfig_simple.avatar_exp_curves;
         var curve:Array = curves ? curves[String(getStar())] as Array : null;
         return curve || GlobalData.$mConfig_simple.avatar_exp_curve as Array;
      }

      public function isSwallowProtect(param1:Avatar) : Boolean
      {
         var _loc6_:Boolean = false;
         var _loc2_:int = getType();
         var _loc5_:int = getStar();
         var _loc4_:int = avatarData.offerExp;
         var _loc3_:int = avatarData.offerGold;
         _loc6_ = GlobalData.$tempAvatarBetter.id == id || GlobalFunction.checkIsTeamMember(id) || GlobalFunction.checkLock(id);
         if(_loc6_)
         {
            return true;
         }
         if(param1.lv >= param1.getLvMax())
         {
            return true;
         }
         if(_loc2_ == 1)
         {
            return true;
         }
         if(_loc5_ >= 5)
         {
            return true;
         }
         if(morph > 0)
         {
            return true;
         }
         if(_loc4_ > 50000)
         {
            return true;
         }
         if(_loc3_ / _loc4_ > 1.5)
         {
            return true;
         }
         if(avatarData.loveExp)
         {
            return true;
         }
         if(avatarData.skillExp)
         {
            return true;
         }
         if(hpP + apP + dePhP + deMaP > 0)
         {
            return true;
         }
         return false;
      }

      public function getSwallowValue(param1:Avatar) : Number
      {
         var _loc9_:Boolean = false;
         var _loc3_:String = null;
         var _loc4_:Number = 0;
         var _loc2_:int = getType();
         var _loc8_:int = getStar();
         var _loc7_:int = avatarData.offerExp;
         var _loc6_:int = avatarData.offerGold;
         _loc9_ = GlobalData.$tempAvatarBetter.id == id || GlobalFunction.checkIsTeamMember(id) || GlobalFunction.checkLock(id);
         _loc4_ = Math.min(10,_loc7_ / _loc6_) * 200 + Math.max(-_loc6_ * 0.1,_loc7_ * 1.2 - _loc6_) + _loc7_ * 0.001 + 50;
         if(_loc9_)
         {
            _loc4_ -= 10000000;
         }
         if(param1.lv >= param1.getLvMax())
         {
            _loc4_ -= _loc7_;
         }
         var _loc5_:int = hpP + apP + dePhP + deMaP;
         if(_loc2_ == 1)
         {
            _loc4_ -= 100000;
            _loc4_ -= _loc8_ * 20000;
            _loc4_ -= _loc5_ * 100;
         }
         else if(_loc5_ > 0)
         {
            _loc4_ += 2000000 + _loc5_ * 100;
         }
         if(param1.getType() == 1)
         {
            if(param1.getLoveList()[0] < GlobalData.$mConfig_simple.love_up[0])
            {
               if(avatarData.loveExp)
               {
                  _loc4_ += 4000000 + avatarData.loveExp * 1000;
               }
            }
            if(param1.avatarData.skill0 != "" && param1.slv < GlobalData.$mConfig_simple.slv_config[0])
            {
               if(avatarData.skillExp)
               {
                  _loc4_ += 3000000 + avatarData.skillExp * 1000;
               }
            }
         }
         else
         {
            if(avatarData.loveExp)
            {
               _loc4_ -= 2000000 + avatarData.loveExp * 1000;
            }
            if(avatarData.skillExp)
            {
               _loc4_ -= 1000000 + avatarData.skillExp * 1000;
            }
         }
         if(lv > 20)
         {
            _loc4_ -= lv * 1000;
         }
         else
         {
            _loc4_ -= lv * 1;
         }
         _loc4_ -= _loc8_ * 10;
         _loc4_ -= phase * 10000;
         if(param1.slv >= GlobalData.$mConfig_simple.slv_config[0])
         {
            _loc3_ = "";
         }
         else
         {
            _loc3_ = param1.avatarData.skill0;
         }
         if(_loc3_ == "")
         {
            _loc4_ -= avatarData.skillExp * 10000;
         }
         _loc4_ -= Math.max(0,slv - 1) * 10000;
         if(isStarUpStuff())
         {
            _loc4_ -= 100000;
         }
         if(morph > 0)
         {
            _loc4_ -= 7000000;
         }
         return _loc4_ + getIdValue();
      }

      public function getExpeditionValue() : Number
      {
         var _loc2_:Number = 0;
         var _loc3_:int = getPower(getLvMax());
         _loc2_ = _loc3_;
         var _loc1_:int = getType();
         if(_loc1_ != 1)
         {
            return -1;
         }
         _loc2_ -= avatarData.skillExp * 10000;
         _loc2_ -= avatarData.loveExp * 10000;
         _loc2_ -= (hpP + apP + dePhP + deMaP) * 100;
         if(lv > 20)
         {
            _loc2_ -= lv * 200;
         }
         _loc2_ -= getStar() * 10000;
         _loc2_ -= phase * 10000;
         _loc2_ -= Math.max(0,slv - 1) * 10000;
         _loc2_ -= loveExp * 10000;
         if(morph > 0)
         {
            _loc2_ -= 7000000;
         }
         return _loc2_ + getIdValue();
      }

      public function getSellValue() : Number
      {
         var _loc2_:Number = 0;
         var _loc5_:int = getOfferExp();
         var _loc4_:int = avatarData.offerGold;
         _loc2_ = Math.min(10,_loc4_ / _loc5_) * 200 + Math.max(-_loc5_ * 0.1,_loc4_ - _loc5_) + _loc4_ * 0.001 + 250;
         var _loc1_:int = getType();
         if(_loc1_ == 1)
         {
            _loc2_ -= 10000000;
         }
         if(avatarData.loveExp)
         {
            _loc2_ -= 2000000 + avatarData.loveExp * 1000;
         }
         if(avatarData.skillExp)
         {
            _loc2_ -= 1000000 + avatarData.skillExp * 1000;
         }
         var _loc3_:int = hpP + apP + dePhP + deMaP;
         if(_loc3_ > 0)
         {
            _loc2_ -= 500000 + (hpP + apP + dePhP + deMaP) * 100;
         }
         if(lv > 10)
         {
            _loc2_ -= lv * 1000;
         }
         else
         {
            _loc2_ -= lv * 1;
         }
         _loc2_ -= getStar() * 100;
         _loc2_ -= phase * 10000;
         _loc2_ -= Math.max(0,slv - 1) * 10000;
         _loc2_ -= loveExp * 60000;
         if(isStarUpStuff())
         {
            _loc2_ -= 100000;
         }
         if(morph > 0)
         {
            _loc2_ -= 7000000;
         }
         return _loc2_ + getIdValue();
      }

      public static function normalizeTeamPower104(value:Number) : Number
      {
         if(!isFinite(value) || value <= 0) return 0;
         return Math.floor(1000000 * Math.pow(value / 1000000,0.75) + 0.000005);
      }

      public function getPower(param1:Boolean = false, param2:int = -1, param3:Boolean = false) : Number
      {
         return Avatar.normalizeTeamPower104(getPowerBase104(param1,param2,param3));
      }

      public function getPowerBase104(param1:Boolean = false, param2:int = -1, param3:Boolean = false) : Number
      {
         updateBondSkills104();
         var _loc10_:Number = skill0 ? skill0.getPower() : 0;
         var _loc9_:Number = param1 ? (skill1 ? skill1.getPower() : 0) : 0;
         var _loc4_:Number = skill2 ? skill2.getPower() : 0;
         var _loc8_:Number = skillB ? skillB.getPower() : 0;
         var _loc7_:Number = talent ? talent.getPower() : 0;
         var _loc6_:* = GlobalData.$mConfig_simple.power;
         if(param2 < 0)
         {
            param2 = lv;
         }
         var _loc5_:Number = Math.pow(Math.max(0,getHpMax(param2,-1,param3) * Number(_loc6_[1]) + getDamage(param2,-1,param3) * Number(_loc6_[2]) + getDePh(param2,-1,param3) * Number(_loc6_[3]) + getDeMa(param2,-1,param3) * Number(_loc6_[4])),2) * (1 + _loc10_ + _loc9_ + _loc4_ + _loc8_ + abyssRelicPowerRate104()) * (POWER_SPEED_RANGE + getSpeed(param3) + getRange(param3)) * (1 + Math.pow(Math.max(0,getHit() + getFlee() + getCrit() + getTough()),1 / _loc6_[10]) * _loc6_[9]) * POWER_RATE;
         _loc5_ = Number(Math.floor(Number(_loc5_.toFixed(5))).toString(10)) + _loc5_ * _loc7_;
         return Number(Math.floor(Number(_loc5_.toFixed(5))).toString(10));
      }

      public function isRangedSkillCaster() : Boolean
      {
         if(getType() != 1) return false;
         var definition:Object = GlobalData.$mConfig_avatar[avatarData.id];
         var ranged:Boolean = definition && typeof definition.ranged_skill == "boolean" ? Boolean(definition.ranged_skill) : avatarData.range >= 500;
         if(!ranged) return false;
         return !abilityState.form || !abilityState.form.hammer;
      }

      public function getLvMax() : int
      {
         if(limitBreak > 0 && getType() == 1 && (getStar() == 5 || getStar() == 6)) return 125;
         if(morph == 0)
         {
            return avatarData.lvMax;
         }
         var _loc1_:* = GlobalData.$mConfig_ploy_system_simple.morph;
         return avatarData.lvMax + morph * _loc1_.attr[0];
      }

      public function getStar() : int
      {
         return avatarData.id.split("_")[2];
      }

      public function getStarMax() : int
      {
         return 6;
      }

      public function getType() : int
      {
         var modTypeRow:Object = GlobalData.$mConfig_avatar ? GlobalData.$mConfig_avatar[avatarData.id] : null;
         if(modTypeRow && modTypeRow.modUnitType == "summon") return 2;
         return int(avatarData.id.slice(2,3));
      }

      public function isStarUpStuff() : Boolean
      {
         var _loc1_:String = avatarData.id.slice(2,4);
         return _loc1_ == "60" || _loc1_ == "61";
      }

      public function getLeadership(param1:Boolean = false) : int
      {
         var _loc3_:int = 0;
         var _loc5_:Array = null;
         var _loc4_:int = avatarData.leadership;
         if(phase != 0)
         {
            _loc3_ = getType();
            _loc5_ = getPhaseList();
            if(_loc5_)
            {
               _loc4_ = _loc5_[4] * phase + _loc4_;
            }
         }
         if(morph != 0)
         {
            _loc4_ += GlobalData.$mConfig_ploy_system_simple.morph.attr[1];
         }
         if(param1)
         {
            return _loc4_;
         }
         var _loc2_:Array = getLoveList();
         if(_loc2_[0] != 0)
         {
            _loc4_ = Math.max(1,_loc4_ - _loc2_[0] * GlobalData.$mConfig_simple.love_up[3]);
         }
         return _loc4_;
      }

      public function getPhase() : int
      {
         return avatarData.id.split("_")[2];
      }

      public function getPhaseList() : Array
      {
         var _loc4_:* = null;
         var _loc2_:Object = null;
         var _loc1_:int = getType();
         var _loc5_:Array = GlobalData.$mConfig_simple.phase_config;
         var _loc3_:int = getStar();
         if(_loc1_ == 1)
         {
            _loc2_ = _loc5_[0];
         }
         else
         {
            _loc2_ = _loc5_[1];
         }
         return _loc2_[String(_loc3_)];
      }

      public function getPhaseLv() : int
      {
         if(phase == 0)
         {
            return 0;
         }
         var _loc1_:Array = getPhaseList();
         if(_loc1_)
         {
            return _loc1_[2] * phase;
         }
         return 0;
      }

      public function getPhasePith() : int
      {
         if(phase == 0)
         {
            return 0;
         }
         var _loc1_:Array = getPhaseList();
         if(_loc1_)
         {
            return _loc1_[3];
         }
         return 0;
      }

      public function getPhaseType() : int
      {
         var _loc4_:Array = null;
         var _loc2_:Object = null;
         var _loc6_:AvatarData = avatarData;
         if(_loc6_.lvMax == 1)
         {
            return 0;
         }
         var _loc1_:int = getType();
         var _loc5_:Array = GlobalData.$mConfig_simple.phase_config;
         var _loc3_:int = getStar();
         if(_loc1_ == 1)
         {
            _loc2_ = _loc5_[0];
         }
         else
         {
            _loc2_ = _loc5_[1];
         }
         _loc4_ = _loc2_[String(_loc3_)];
         if(_loc3_ == 5 && phase >= 2 && _loc6_.starUp.length > 0 && !GlobalFunction.isNullNextStarCfgId(id)) return 2;
         if(_loc4_)
         {
            if(phase < _loc4_[1])
            {
               return 1;
            }
         }
         if(_loc6_.starUp.length > 0 && !GlobalFunction.isNullNextStarCfgId(id))
         {
            return 2;
         }
         return 0;
      }

      public function goFight(param1:int, param2:int, param3:Number, param4:Boolean = true) : void
      {
         summonStatSnapshot = false;
         yasuoNightRounds104=-1;yasuoVampRounds104=-1;yasuoCritBonus104=0;yasuoShieldSerial104=0;yasuoCritBurst104=false;
         kaisaClearPlasma104();kaisaRoot104=null;kaisaCast104=0;kaisaMarks104={};kaisaHunting104=false;kaisaBurst104=false;
         formationOwner = null;
         abilityState = {}; abilitySerial = 0; abilityIndex = ++abilityNextIndex;
         abilityEntryAttack = 0;
         team = param1;
         isLeader = param4;
         if(GameMap.currentMap)
         {
            if(team == 1)
            {
               pos = Math.round(GameMapConfig.LINE_POS * (1 - param3));
            }
            else
            {
               pos = Math.round(GameMapConfig.LINE_POS * param3);
            }
         }
         else
         {
            pos = 0;
         }
         offset = 0;
         line = param2;
         initbuffs();
         initFightAttr();
         abilityEntryAttack = ap;
         yasuoStart104();
         ready();
      }

      public function initFightAttr() : void
      {
         updateBondSkills104();
         initializingFightAttributes = true;
         if(!(mData && mData.tpl))
         {
            hpMax = 0;
         }
         ap = getDamage(-1,-1,true);
         deMa = getDeMa(-1,-1,true);
         dePh = getDePh(-1,-1,true);
         speed = getSpeed(true);
         range = getRange(true);
         hit = getHit();
         flee = getFlee();
         crit = getCrit();
         tough = getTough();
         hpMax = getHpMax(-1,-1,true);
         initializingFightAttributes = false;
         skin2Initialize();
         if(hp <= 0)
         {
            hp = hpMax;
         }
      }

      public function checkAction() : Boolean
      {
         var _currentMap:GameMap;
         var _gl:GameMapLayer;
         var _tween1:Tween;
         var _avatarData:AvatarData;
         var _aimAvatar:Avatar;
         var _checkList:Vector.<Avatar>;
         var _focusAliveList:Vector.<Avatar>;
         var _hasBack:Boolean;
         var _fun:Function;
         GameMap.actionDelay = 0;
         rangePreviewQueued = false;
         rangeMoveEndsAt = 0;
         _currentMap = GameMap.currentMap;
         if(!_currentMap)
         {
            return false;
         }
         if(hp <= 0)
         {
            return false;
         }
         _focusAliveList = _currentMap.getAliveList(otherTeam) as Vector.<Avatar>;
         if(manualFocusTarget && (manualFocusTarget.hp <= 0 || manualFocusTarget.team == team || !_focusAliveList || _focusAliveList.indexOf(manualFocusTarget) < 0))
         {
            manualFocusTarget = null;
         }
         // A finished lane may still supply a global turn-start passive.
         // The lane-end guard below stops normal attacks, skills and movement.
         if(_currentMap.isEnd() || (_currentMap.winnerList[line] != 0 && (!skillB || skillB.getCastRange() <= GameMapConfig.LINE_POS)))
         {
            return false;
         }
         advanceManualOwnerAction();
         _currentMap.startAction(this);
         _gl = GameMapLayer.gl;
         _gl.juggler.removeTweens(fightRes);
         _tween1 = new Tween(fightRes,0.3 / 2,"easeInOut");
         _tween1.scaleTo(getScale() * 1.2);
         _tween1.fadeTo(1);
         _gl.addTween(_tween1);
         if(fightRes.parent)
         {
            (fightRes.parent as AvatarLayer).setFirst(fightRes);
         }
         refreshIcon();
         if(!GlobalData.$userData.nnnnnnnnn)
         {
            GlobalData.$userData.nnnnnnnnn = 0;
         }
         var _loc2_:Object = GlobalData.$userData;
         var _loc3_:Number = Number(_loc2_.nnnnnnnnn) + 1;
         _loc2_.nnnnnnnnn = _loc3_;
         trace("第" + GlobalData.$userData.nnnnnnnnn + "个英雄进行回合" + this.id);
         if(skill0)
         {
            skill0.cooldown();
         }
         if(skill1)
         {
            skill1.cooldown();
         }
         if(skill2)
         {
            skill2.cooldown();
         }
         if(skillB)
         {
            skillB.cooldown();
         }
         kaisaTryCaptain104();
         getTeamHp();
         emitModEvent("turn_start",this,this);
         var openingPassive:Array=skillB && skillB.skills ? sixStarPassive105() : null;
         var openingRow:Object=skillB && skillB.skillSetData ? GlobalData.$mConfig_skill[skillB.skillSetData.id] : null;
         if(openingPassive && openingPassive[1]=="six_kennen_p" ||
            openingRow && openingRow.sixStarBalance105 && openingRow.modCondition && openingRow.modCondition.kind=="absent_buff")
            skillB.checkUse();
         else if(checkBuffOfSkillB())
         {
            checkSkillB();
         }
         if(abilityState.sixTurret105 || abilityState.sixCaitlyn105) sixStarTurnStart105();
         if(hp>0 && (skillB || abilityState.sixMorganaLinks105)) sixFollowupTurn105();
         getTeamHp();
         if(GameMap.currentMap.isEnd(line))
         {
            _gl.delayCall(_currentMap.endAction,GameMap.actionDelay);
            return true;
         }
         if(skill0)
         {
            skill0.onOwnerTurnStart();
         }
         if(skill1)
         {
            skill1.onOwnerTurnStart();
         }
         if(abilityTurnStart())
         {
            if(skin2.eggUntil && hp > 0 && checkBuff()) dead();
            _gl.delayCall(_currentMap.endAction,GameMap.actionDelay);
            return true;
         }
         if(checkBuff())
         {
            dead();
            _gl.delayCall(_currentMap.endAction,GameMap.actionDelay);
            return true;
         }
         var cocoon:Object=abilityState.sixReactionElise105;
         if(cocoon && cocoon.skip)
         {
            cocoon.skip=false;
            cocoon.until=abilitySerial;
         }
         else if(buffs["stun"])
         {
            _gl.delayCall(SoundManager.getOnlyExample().playSound,GameMap.actionDelay,"stun");
            GameMap.actionDelay += 0.2;
         }
         else if(abilityState.sixBatchSand105)
         {
            if(!sixStarLane105(getRange()).length && sixStarLane105().length) checkMove(true);
         }
         else
         {
            GameMapTools.gameTrace("隊伍:" + team + "  " + id + "開始行動，位置：" + pos + "line:" + line);
            _avatarData = avatarData;
            _checkList = _currentMap.getAliveList(otherTeam) as Vector.<Avatar>;
            _hasBack = false;
            GlobalData.skillBoo = false;
            if(getEffectiveActionType() == 1)
            {
               _aimAvatar = checkAttack(_checkList,getSortOnFun());
               checkSkillB();
               if(!_aimAvatar)
               {
                  if(checkMove(true))
                  {
                     _aimAvatar = checkAttack(_checkList,getSortOnFun());
                     checkSkillB();
                     checkSkill();
                     checkSkillB();
                  }
                  else
                  {
                     checkSkill();
                     checkSkillB();
                  }
               }
               else
               {
                  checkSkill();
                  checkSkillB();
               }
            }
            else if(getEffectiveActionType() == 2)
            {
               _hasBack = checkSkill();
               checkSkillB();
               _aimAvatar = checkAttack(_checkList,getSortOnFun());
               checkSkillB();
               if(!_aimAvatar)
               {
                  if(!_hasBack && checkMove(true))
                  {
                     checkSkill();
                     checkSkillB();
                     _aimAvatar = checkAttack(_checkList,getSortOnFun());
                     checkSkillB();
                  }
               }
               else if(checkDangerous())
               {
                  checkMove(false);
               }
            }
            else if(getEffectiveActionType() == 4)
            {
               _hasBack = checkSkill();
               checkSkillB();
               _aimAvatar = checkAttack(_checkList,getSortOnFun());
               checkSkillB();
               if(!_aimAvatar)
               {
                  if(!_hasBack && checkMove(true))
                  {
                     checkSkill();
                     checkSkillB();
                     _aimAvatar = checkAttack(_checkList,getSortOnFun());
                     checkSkillB();
                  }
               }
               else
               {
                  checkMove(false);
               }
            }
            else
            {
               checkSkill();
               checkSkillB();
               _aimAvatar = checkAttack(_checkList,getSortOnFun());
               checkSkillB();
            }
            GameMapTools.gameTrace("隊伍:" + team + "  " + id + "結束行動，位置：" + pos + "line:" + line);
         }
         GameMap.actionDelay = Math.max(GameMap.actionDelay,0.3);
         _fun = function():void
         {
            _gl.juggler.removeTweens(fightRes);
            var _loc1_:Tween = new Tween(fightRes,0.3 / 2,"easeInOut");
            _loc1_.scaleTo(getScale());
            _loc1_.fadeTo(1);
            _loc1_.animate("x",GameMapConfig.offsetToPixel(offset));
            _loc1_.animate("y",GameMapConfig.posToPixel(pos));
            _gl.addTween(_loc1_);
         };
         _gl.delayCall(_fun,GameMap.actionDelay,fightRes);
         _gl.delayCall(_currentMap.endAction,GameMap.actionDelay);
         return true;
      }

      private function checkBuffOfSkillB() : Boolean
      {
         if(skillB && skillB.isModEffectSequence()) return skillB.modConditionReady();
         var _loc1_:Boolean = false;
         if(!this.avatarData.skill_diff)
         {
            return _loc1_;
         }
         for(var _loc2_:String in buffs)
         {
            if(_loc2_ == "evil" && this.avatarData.skill_diff == 4)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "silence" && this.avatarData.skill_diff == 5)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "stun" && this.avatarData.skill_diff == 6)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "burn" && this.avatarData.skill_diff == 7)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "sunder" && this.avatarData.skill_diff == 8)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "poison" && this.avatarData.skill_diff == 9)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "weak" && this.avatarData.skill_diff == 10)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "shield" && this.avatarData.skill_diff == 11)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "purify" && this.avatarData.skill_diff == 12)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "strong" && this.avatarData.skill_diff == 13)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if((_loc2_ == "hitup" || _loc2_ == "fleeup" || _loc2_ == "critup" || _loc2_ == "toughup") && this.avatarData.skill_diff == 14)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "bless" && this.avatarData.skill_diff == 15)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "steel" && this.avatarData.skill_diff == 16)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc2_ == "taunt" && this.avatarData.skill_diff == 17)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if((_loc2_ == "evil" || _loc2_ == "silence" || _loc2_ == "stun" || _loc2_ == "burn" || _loc2_ == "sunder" || _loc2_ == "poison" || _loc2_ == "weak" || _loc2_ == "shield" || _loc2_ == "purify" || _loc2_ == "strong" || _loc2_ == "hitup" || _loc2_ == "fleeup" || _loc2_ == "critup" || _loc2_ == "toughup" || _loc2_ == "bless" || _loc2_ == "steel" || _loc2_ == "taunt") && this.avatarData.skill_diff == 18)
            {
               _loc1_ = false;
               GlobalData.skillBoo = false;
               return false;
            }
            if((_loc2_ == "root" || _loc2_ == "evil" || _loc2_ == "silence" || _loc2_ == "stun" || _loc2_ == "burn" || _loc2_ == "sunder" || _loc2_ == "poison" || _loc2_ == "weak" || _loc2_ == "curse") && this.avatarData.skill_diff == 19)
            {
               _loc1_ = true;
               GlobalData.skillBoo = true;
            }
            if(_loc1_)
            {
               trace(_loc2_ + "------" + this.avatarData.id + "---------------------------------------------------------" + "");
            }
         }
         if(this.avatarData.skill_diff == 18)
         {
            _loc1_ = true;
            GlobalData.skillBoo = true;
         }
         return _loc1_;
      }

      public function showMove(param1:Number = -1) : void
      {
         var _loc9_:int = 0;
         var _loc2_:int = 0;
         var _loc7_:int = 0;
         var _loc10_:int = 0;
         var _loc6_:GameMapLayer = GameMapLayer.gl;
         var _loc3_:int = 0;
         if(getSpeed() != 0)
         {
            _loc3_ = GameMapConfig.pixelToPos(0,GameMapConfig.FIGHT_HEIGHT * GameMapConfig.FIGHT_EXTRA_Y).y;
         }
         var _loc5_:int = pos;
         var _loc4_:int = pos;
         if(team == 1)
         {
            _loc3_ = -_loc3_;
         }
         else
         {
            _loc3_ = _loc3_;
         }
         _loc5_ = _loc4_ - _loc3_;
         var _loc8_:Number = 1.2;
         _loc3_ = Math.abs(_loc5_ - _loc4_);
         if(_loc3_ < 400)
         {
            _loc8_ *= _loc3_ / 400;
         }
         if(_loc8_ > 0)
         {
            _loc9_ = GameMapConfig.offsetToPixel(offset);
            _loc2_ = GameMapConfig.posToPixel(_loc5_);
            fightRes.x = _loc9_;
            fightRes.y = _loc2_;
            _loc7_ = GameMapConfig.offsetToPixel(offset);
            _loc10_ = GameMapConfig.posToPixel(_loc4_);
            _loc6_.delayCall(resBounce,param1,_loc7_,_loc10_,1.15,0.4 * 0.8,_loc8_);
         }
      }

      public function checkMove(param1:Boolean, param2:int = 0, param3:Avatar = null, param4:Number = -1, param5:Boolean = false, param6:String = null) : Number
      {
         if(abilityState.sixTurret105 || param5 && abilityState.channel) return 0;
         if(!param5 && s2LiveMark(this,"cold") && param2>0) param2=Math.round(param2*s2ColdMoveFactor());
         if(abilityState.root && !param5) return 0;
         var _loc18_:int = 0;
         var _loc13_:int = 0;
         var _loc20_:int = 0;
         var _loc12_:Tween = null;
         var _loc19_:* = undefined;
         var _loc17_:Tween = null;
         var _loc15_:Tween = null;
         if(GameMap.currentMap.isEnd(line))
         {
            return 0;
         }
         var _loc8_:GameMapLayer = GameMapLayer.gl;
         var _loc7_:Boolean = false;
         if(param2 == 0)
         {
            param2 = getSpeed();
            _loc7_ = true;
         }
         var _loc16_:int = GameMapConfig.offsetToPixel(offset);
         var _loc11_:int = GameMapConfig.posToPixel(pos);
         param2 = Math.abs(param2);
         var _loc10_:int = 0;
         var _loc9_:int = pos;
         if(param4 < 0)
         {
            param4 = GameMap.actionDelay;
         }
         if(param1)
         {
            if(team == 1)
            {
               _loc18_ = -param2;
            }
            else
            {
               _loc18_ = param2;
            }
         }
         else if(team == 1)
         {
            _loc18_ = param2;
         }
         else
         {
            _loc18_ = -param2;
         }
         var requestedPos:int = pos + _loc18_;
         if(_loc7_ && !param5 && !param3)
         {
            requestedPos = clampSummonFormation(requestedPos);
            if(param1) requestedPos = clampOwnerAdvance(requestedPos);
         }
         pos = GameMap.currentMap.getFinalPos(team,line,requestedPos);
         var _loc14_:Number = 0.4;
         param2 = Math.abs(_loc9_ - pos);
         if(param2 < 400)
         {
            _loc14_ *= param2 / 400;
         }
         if(_loc14_ > 0)
         {
            if(GameMap.currentAvatar === this)
            {
               rangeMoveEndsAt = Math.max(rangeMoveEndsAt,param4 + _loc14_);
            }
            if(param3)
            {
               offset += (param3.offset - offset) * ((pos - _loc9_) / (param3.pos - _loc9_));
               offset = Math.max(-GameMapConfig.sideOffset,Math.min(offset,GameMapConfig.sideOffset));
            }
            _loc13_ = GameMapConfig.offsetToPixel(offset);
            _loc20_ = GameMapConfig.posToPixel(pos);
            if(_loc7_)
            {
               _loc8_.delayCall((fightRes.parent as AvatarLayer).setFirst,param4,fightRes);
               _loc8_.delayCall(resBounce,param4,_loc13_,_loc20_,1.15,0.4 / 2,_loc14_);
               _loc8_.delayCall(SoundManager.getOnlyExample().playSound,param4,"move");
            }
            else
            {
               if(param3)
               {
                  _loc8_.delayCall(SoundManager.getOnlyExample().playSound,param4,"beMoved");
               }
               else
               {
                  _loc8_.delayCall(SoundManager.getOnlyExample().playSound,param4,"dash");
               }
               _loc12_ = new Tween(fightRes,_loc14_,"easeInOutBack");
               _loc12_.delay = param4;
               _loc12_.moveTo(_loc13_,_loc20_);
               _loc8_.addTween(_loc12_);
               if(param6)
               {
                  _loc19_ = DisplayTools.getAttrs(param6);
                  _loc19_.a1 = this;
                  _loc19_.x1 = _loc16_ + _loc8_.getLineSpr(line).x;
                  _loc19_.y1 = _loc11_;
                  _loc19_.x2 = _loc13_ + _loc8_.getLineSpr(line).x;
                  _loc19_.y2 = _loc20_;
                  _loc19_.par = _loc8_.effectLayer;
                  _loc8_.delayCall(DisplayTools.addBullet,param4,_loc19_);
               }
            }
            if(GameMap.currentAvatar != this)
            {
               _loc17_ = new Tween(fightRes,0.2,"easeInOut");
               _loc17_.delay = param4;
               _loc17_.scaleTo(getScale() * 1.2);
               _loc8_.addTween(_loc17_);
               _loc15_ = new Tween(fightRes,0.2,"easeInOut");
               _loc15_.delay = param4 + 0.2;
               _loc15_.scaleTo(getScale());
               _loc8_.addTween(_loc15_);
            }
         }
         if(!param5)
         {
            GameMap.actionDelay += Math.max(0,_loc14_ - 0.08);
         }
         skin2Moved();
         return _loc14_;
      }

      public function resSpeak() : void
      {
         var _loc1_:Tween = null;
         if(team == 0)
         {
            return;
         }
         var _loc3_:GameMapLayer = GameMapLayer.gl;
         var _loc2_:Sprite = fightRes;
         if(!_loc2_ || !_loc2_.parent)
         {
            return;
         }
         (_loc2_.parent as AvatarLayer).setFirst(_loc2_);
         _loc1_ = new Tween(_loc2_,0.2,"easeIn");
         _loc1_.delay = 0.2 * 1;
         _loc1_.scaleTo(_loc2_.scaleX * 1.3);
         _loc3_.addTween(_loc1_);
         _loc1_ = new Tween(_loc2_,0.2,"easeOutBack");
         _loc1_.delay = 0.2 * 4;
         _loc1_.scaleTo(_loc2_.scaleX);
         _loc3_.addTween(_loc1_);
      }

      public function resBounce(param1:int, param2:int, param3:Number, param4:Number, param5:Number) : void
      {
         var _loc11_:int = 0;
         var _loc10_:Tween = null;
         var _loc9_:Tween = null;
         var _loc6_:int = param5 / param4 + 1;
         param4 = param5 / _loc6_;
         var _loc8_:GameMapLayer = GameMapLayer.gl;
         var _loc7_:Sprite = fightRes;
         _loc11_ = 0;
         while(_loc11_ < _loc6_)
         {
            _loc10_ = new Tween(_loc7_,param4 / 2,"easeIn");
            _loc10_.delay = param4 * _loc11_;
            _loc10_.scaleTo(_loc7_.scaleX * param3);
            _loc10_.animate("rotation",_loc11_ % 2 == 0 ? 0.1 : -0.1);
            _loc10_.moveTo(_loc7_.x + (param1 - _loc7_.x) * (_loc11_ + 0.5) / _loc6_,_loc7_.y + (param2 - _loc7_.y) * (_loc11_ + 0.5) / _loc6_);
            _loc8_.addTween(_loc10_);
            _loc9_ = new Tween(_loc7_,param4 / 2,"easeOut");
            _loc9_.delay = param4 * _loc11_ + param4 / 2;
            _loc9_.scaleTo(_loc7_.scaleX);
            _loc9_.animate("rotation",0);
            _loc9_.moveTo(_loc7_.x + (param1 - _loc7_.x) * (_loc11_ + 1) / _loc6_,_loc7_.y + (param2 - _loc7_.y) * (_loc11_ + 1) / _loc6_);
            _loc8_.addTween(_loc9_);
            _loc11_++;
         }
      }

      public function resSwing(param1:Number, param2:Number) : void
      {
         var _loc9_:int = 0;
         var _loc8_:Tween = null;
         var _loc7_:Tween = null;
         var _loc5_:Number = Number(NaN);
         var _loc3_:int = param2 / param1 + 1;
         param1 = param2 / _loc3_;
         var _loc6_:GameMapLayer = GameMapLayer.gl;
         var _loc4_:Sprite = fightRes;
         _loc9_ = 0;
         while(_loc9_ < _loc3_)
         {
            _loc5_ = 0.5 * (_loc3_ - _loc9_) / _loc3_;
            _loc8_ = new Tween(_loc4_,param1 / 2,"easeIn");
            _loc8_.delay = param1 * _loc9_;
            _loc8_.animate("rotation",_loc9_ % 2 == 0 ? _loc5_ : -_loc5_);
            _loc6_.addTween(_loc8_);
            _loc7_ = new Tween(_loc4_,param1 / 2,"easeOut");
            _loc7_.delay = param1 * _loc9_ + param1 / 2;
            _loc7_.animate("rotation",0);
            _loc6_.addTween(_loc7_);
            _loc9_++;
         }
      }

      public function reline(param1:int, param2:int = -2147483648, param3:int = -2147483648, param4:Number = 0, param5:Number = 0, forced:Boolean = false) : void
      {
         if(abilityState && abilityState.sixTurret105) return;
         if(forced && abilityState.channel) return;
         if(!forced && s2LiveMark(this,"cold") && param2!=-2147483648) param2=pos+Math.round((param2-pos)*s2ColdMoveFactor());
         if(abilityState.root && !forced) return;
         if(param1 != line) delete abilityState.channel;
         var _loc10_:* = undefined;
         var _loc6_:int = line;
         _loc10_ = DisplayTools.getAttrs("RE_LINE_OUT_EFF_" + team);
         _loc10_.a1 = this;
         DisplayTools.formatAttrs(_loc10_);
         line = param1;
         if(param2 == -2147483648)
         {
            if(team == 1)
            {
               pos = GameMapConfig.LINE_POS;
            }
            else
            {
               pos = 0;
            }
         }
         else
         {
            pos = GameMap.currentMap.getFinalPos(team,param1,param2);
         }
         if(param3 == -2147483648)
         {
            offset = 0;
         }
         else
         {
            offset = param3;
         }
         var _loc7_:GameMapLayer = GameMapLayer.gl;
         var _loc9_:Tween = new Tween(fightRes,2.8 / 6,"easeInOut");
         _loc9_.delay = GameMap.actionDelay + param5;
         _loc9_.scaleTo(0);
         _loc7_.addTween(_loc9_);
         _loc7_.delayCall(refreshReline,2.8 / 2 + GameMap.actionDelay + param4,line,pos,offset);
         var _loc8_:Tween = new Tween(fightRes,2.8 / 6,"easeInOut");
         _loc8_.delay = GameMap.actionDelay + 2.8 / 2 + param4 + 0.1 + param5;
         _loc8_.scaleTo(getScale());
         _loc7_.addTween(_loc8_);
         _loc10_.par = _loc7_.effectLayer;
         _loc7_.delayCall(DisplayTools.addEffects,GameMap.actionDelay + param5,_loc10_);
         _loc10_ = DisplayTools.getAttrs("RE_LINE_IN_EFF_" + team);
         _loc10_.a1 = this;
         _loc10_.par = _loc7_.effectLayer;
         _loc7_.delayCall(DisplayTools.addEffects,GameMap.actionDelay + param4 + param5 + 2.8 / 2,_loc10_);
         skin2Moved();
      }

      public function isResolvingSkill() : Boolean
      {
         var context:Object = currentAbilityAttack();
         return context && context.owner === this && context.kind == "active";
      }

      public function checkAttack(param1:Vector.<Avatar>, param2:Function, param3:int = -1, param4:Boolean = false, param5:int = -1, param6:Number = 1, param7:int = 0, param8:String = null, param9:Buff = null, param10:Number = 1) : Avatar
      {
         var _aim:Avatar;
         if(GameMap.currentMap.isEnd(line) && !isResolvingSkill())
         {
            return null;
         }
         _aim = checkAllAttack(param1,param2,param3,param4,param5,param6,param7,param8,param9,param10);
         if(_aim && manualFocusTarget === _aim)
         {
            manualFocusTarget = null;
         }
         return _aim;
      }

      public function checkAllAttack(param1:Vector.<Avatar>, param2:Function, param3:int = -1, param4:Boolean = false, param5:int = -1, param6:Number = 1, param7:int = 0, param8:String = null, param9:Buff = null, param10:Number = 1) : Avatar
      {
         var _loc11_:* = undefined;
         _loc11_ = findAimList(param1,param2,param3,param4);
         if(_loc11_.length > 0)
         {
            if(GameMap.currentAvatar === this && param5 < 0 && !currentAbilityAttack())
            {
               queueRangePreview();
            }
            attackAimList(_loc11_,param5,param6,param7,param8,param4,param9,param3,param10);
            return _loc11_[0];
         }
         return null;
      }

      public function checkMiss(param1:Avatar, param2:Avatar, param3:* = null) : Boolean
      {
         if(param2.getEffectiveActionType() == 3)
         {
            return false;
         }
         var _loc9_:* = damageAttack104();
         var _loc7_:int = Tools.toInt(param1.getHit() + param1.getHit() * param1.checkTalent(4));
         var _loc6_:int = Tools.toInt(param2.getFlee() + param2.getFlee() * param2.checkTalent(5));
         var delta:Number = ratioDamage104() ? Math.max(0,_loc6_) - Math.max(0,_loc7_) : Number(_loc6_) - _loc7_;
         var _loc5_:Number = ratioDamage104() ? opposedMissChance105(delta) :
             Tools.toInt(Math.min(_loc9_[6],Math.max(0,_loc9_[4]+100*delta/(_loc6_+_loc7_+_loc9_[9]))));
         GameMapTools.gameTrace("闪避判定",param1.id,param2.id);
         var _loc4_:Boolean = ratioDamage104() ? rollPercent105(_loc5_) : Random.getRandom() < _loc5_;
         var _loc8_:GameMapLayer = GameMapLayer.gl;
         if(_loc4_)
         {
            _loc8_.delayCall(_loc8_.infoLayer.popTextForAvatar,GameMap.actionDelay,GlobalLanguageStr.getLanguageStr(30010),param2,13684944,35,1);
            _loc8_.delayCall(missTween,GameMap.actionDelay - 0.2,param2);
            _loc8_.delayCall(SoundManager.getOnlyExample().playSound,GameMap.actionDelay - 0.1,"miss");
            param1.emitModEvent("miss",param1,param2);
            param2.emitModEvent("dodge",param1,param2);
            param2.abyssOnDodge104();
            GameMapTools.gameTrace(GameMap.currentAvatar.id,GameMap.currentAvatar.team,"        ",param2.id,param2.team + "閃避");
            if(param3)
            {
               param3 = Tools.clone(param3);
               param3.a1 = param2;
               param3.a2 = param1;
               param3.re = true;
               param3.par = _loc8_.effectLayer;
               _loc8_.delayCall(DisplayTools.addEffects,GameMap.actionDelay,param3);
            }
            if(param2.buffs["taunt"])
            {
               param3 = DisplayTools.getAttrs("TAUNT_HIT_EFF");
               param3.a1 = param2;
               param3.par = _loc8_.effectLayer;
               _loc8_.delayCall(DisplayTools.addEffects,GameMap.actionDelay - 1,param3);
            }
         }
         return _loc4_;
      }

      public function checkTalent(param1:int, param2:Boolean = false) : Number
      {
         if(this.summonStatSnapshot && param1 >= 1 && param1 <= 3) return 0;
         var _loc9_:int = 0;
         var _loc4_:Avatar = null;
         var _loc6_:Number = 0;
         var _loc8_:Number = 0;
         var _loc7_:GameMap = GameMap.currentMap;
         var _loc3_:Vector.<Avatar> = _loc7_ ? _loc7_.getAliveList(team) as Vector.<Avatar> : null;
         var _loc5_:Vector.<Avatar> = _loc7_ ? _loc7_.getAliveList(otherTeam) as Vector.<Avatar> : null;
         if(_loc7_ && team >= 1 && team <= 2 && _loc3_ && _loc5_)
         {
            if(param1 == 14 || param1 == 15 || param1 == 16)
            {
               _loc9_ = 0;
               while(_loc9_ < _loc3_.length)
               {
                  _loc4_ = _loc3_[_loc9_];
                  if(_loc4_ && _loc4_.talent && !_loc4_.isTeamFlatTalent() && !_loc4_.isPanelStatTalent())
                  {
                     if(_loc4_.talent.my_HaloData.plType == param1 && _loc4_.talent.my_HaloData.plUse == 1 && (_checkListmyCurrHp ? _checkListmyCurrHp[_loc9_] : 1) > 0)
                     {
                        _loc8_ = _loc8_ > _loc4_.talent.my_HaloData.plNum ? _loc8_ : _loc4_.talent.my_HaloData.plNum;
                     }
                  }
                  _loc9_++;
               }
               if(talent && !isTeamFlatTalent() && !isPanelStatTalent())
               {
                  if(talent.my_HaloData.plType == param1 && talent.my_HaloData.plUse == 0)
                  {
                     _loc8_ = _loc8_ > talent.my_HaloData.plNum ? _loc8_ : talent.my_HaloData.plNum;
                  }
               }
               _loc8_ = -_loc8_;
               trace(_loc8_ / 100);
               return _loc8_ / 100 < -1 ? -1 : _loc8_ / 100;
            }
            _loc9_ = 0;
            while(_loc9_ < _loc3_.length)
            {
               _loc4_ = _loc3_[_loc9_];
               if(_loc4_ && _loc4_.talent && !_loc4_.isTeamFlatTalent() && !_loc4_.isPanelStatTalent())
               {
                  if((_loc4_.talent.my_HaloData.plType == param1 || param1 == 3 && _loc4_.ownGrowthValue("defense") > 0) && _loc4_.talent.my_HaloData.plUse == 1 && (_checkListmyCurrHp ? _checkListmyCurrHp[_loc9_] : 1) > 0)
                  {
                     _loc6_ = _loc6_ > _loc4_.talent.my_HaloData.plNum ? _loc6_ : _loc4_.talent.my_HaloData.plNum;
                  }
               }
               _loc9_++;
            }
            if(talent && !isTeamFlatTalent() && !isPanelStatTalent())
            {
               if((talent.my_HaloData.plType == param1 || param1 == 3 && ownGrowthValue("defense") > 0) && talent.my_HaloData.plNum > _loc6_ && talent.my_HaloData.plUse == 0)
               {
                  _loc6_ = talent.my_HaloData.plNum;
               }
            }
            _loc9_ = 0;
            while(_loc9_ < _loc5_.length)
            {
               _loc4_ = _loc5_[_loc9_];
               if(_loc4_ && _loc4_.talent && !_loc4_.isTeamFlatTalent() && !_loc4_.isPanelStatTalent())
               {
                  if(_loc4_.talent.my_HaloData.plType < 8)
                  {
                     if(_loc4_.talent.my_HaloData.plType == param1 && _loc4_.talent.my_HaloData.plUse == 2 && (_checkListotherCurrHp ? _checkListotherCurrHp[_loc9_] : 1) > 0)
                     {
                        _loc8_ = _loc8_ > _loc4_.talent.my_HaloData.plNum ? _loc8_ : _loc4_.talent.my_HaloData.plNum;
                     }
                  }
               }
               _loc9_++;
            }
            _loc6_ -= _loc8_;
            if(_loc6_ != 0)
            {
               trace("+++++++++++++++++++++++++++++++++++++++++++++++++++++++增加数据百分比" + _loc6_);
            }
            return _loc6_ / 100 < -1 ? -1 : _loc6_ / 100;
         }
         return 0;
      }

      public function getTeamHp() : void
      {
         var _loc1_:* = 0;
         var _loc4_:GameMap = GameMap.currentMap;
         var _loc2_:Vector.<Avatar> = _loc4_.getAliveList(this.team) as Vector.<Avatar>;
         var _loc3_:Vector.<Avatar> = _loc4_.getAliveList(this.team - 1) as Vector.<Avatar>;
         _checkListmyCurrHp = [];
         _checkListotherCurrHp = [];
         _loc1_ = 0;
         while(_loc1_ < _loc2_.length)
         {
            _checkListmyCurrHp.push(_loc2_[_loc1_].hp);
            _loc1_++;
         }
         _loc1_ = 0;
         while(_loc1_ < _loc3_.length)
         {
            _checkListotherCurrHp.push(_loc3_[_loc1_].hp);
            _loc1_++;
         }
      }

      public function attackAimList(param1:Vector.<Avatar>, param2:int = -1, param3:Number = 1, param4:int = 0, param5:String = null, param6:Boolean = false, param7:Buff = null, param8:int = -1, param9:Number = 1, effectSource:Avatar = null) : int
      {
         if(abilityState.sixBatchSand105 && (param2<0 || param2>=1 && param2<=3)) return 0;
         var kayleStage:int=param2==-1 && skillB ? sixBatchKayleStage105() : 0;
         if(kayleStage>=2 && param1 && param1.length) return sixBatchKayleAttack105(param1[0],kayleStage);
         var basicPassive105:Array = param2 == -1 && skillB ? sixStarPassive105() : null;
         if(basicPassive105 && basicPassive105[1]=="six_caitlyn_p") param3 *= Number(basicPassive105[4]);
         if(param2 < 0 || param2 >= 1 && param2 <= 4) param3 *= purpleBondMultiplier();
         if(param7 && param7.type == "shield") param7.value *= purpleBondMultiplier();
         var basicContext:Object = null;
         var aimTarget:Avatar = param1 && param1.length ? param1[0] : null;
         if(param1 && param1.length == 1) prepareParallelVisualTarget(aimTarget,true);
         var playBatchAttack:Boolean = param1 && param1.length ? playParallelAttackTween() : true;
         var markedBasic:Boolean = false;
         if(!currentAbilityAttack() && (param2 < 0 || param2 >= 1 && param2 <= 3))
         {
            basicContext = beginAbilityAttack(this,"basic");
            if(param2==-1)
            {
               if(abilityState.sixFire105) sixStarSkillBegin105(basicContext,null);
               var shenCharge105:Object=abilityState.sixShen105;
               if(shenCharge105 && shenCharge105.charges>0)
               {
                  basicContext.sixShenStrike105=shenCharge105.ratio;
                  --shenCharge105.charges;
               }
            }
            markedBasic = aimTarget && aimTarget.abilityHasMark(this,"aim");
            if(markedBasic) param3 *= 1+0.8*Number(aimTarget.abilityState["mark_aim_"+abilityIndex].scale);
         }
         var sixAttack105:Object=currentAbilityAttack();
         var sixCritical105:Boolean=sixAttack105 && sixAttack105.owner===this && sixAttack105.sixCritTrue105;
         var sixDirect105:Boolean=sixAttack105 && sixAttack105.owner===this && (
            sixCritical105 || sixAttack105.sixLeech105 || sixAttack105.sixShenStrike105 || sixAttack105.sixFioraTrue105 ||
            abilityState.highlander && abilityState.highlander.extra);
         try
         {

         var bookBasicAttack:Boolean = param2 == -1;
         var bookHPBefore:int = 0;
         var _loc38_:* = 0;
         var _loc10_:Avatar = null;
         var _loc12_:Avatar = null;
         var _loc46_:Array = null;
         var _loc24_:int = 0;
         var _loc48_:int = 0;
         var _loc37_:Number = Number(NaN);
         var _loc23_:Number = Number(NaN);
         var _loc28_:Number = Number(NaN);
         var _loc15_:* = undefined;
         var _loc20_:Number = Number(NaN);
         var _loc40_:Number = Number(NaN);
         var _loc18_:Point = null;
         var _loc27_:* = undefined;
         var _loc34_:int = 0;
         var _loc43_:Number = Number(NaN);
         var _loc36_:int = 0;
         var _loc11_:Avatar = null;
         if(!param1 || param1.length == 0)
         {
            return 0;
         }
         getTeamHp();
         var _loc32_:GameMap = GameMap.currentMap;
         var _loc17_:Vector.<Avatar> = _loc32_.getAliveList(this.team) as Vector.<Avatar>;
         var _loc19_:Vector.<Avatar> = _loc32_.getAliveList(this.team - 1) as Vector.<Avatar>;
         _loc38_ = 0;
         while(_loc38_ < _loc17_.length)
         {
            _loc17_[_loc38_].getTeamHp();
            _loc38_++;
         }
         _loc38_ = 0;
         while(_loc38_ < _loc19_.length)
         {
            _loc19_[_loc38_].getTeamHp();
            _loc38_++;
         }
         param8 = Math.min(GameMapConfig.LINE_POS + 1,param8);
         var _loc16_:Number = checkTalent(1);
         var _loc29_:Number = getDamage();
         var recoveryBase:Number = Tools.toInt(_loc29_ + _loc29_ * _loc16_);
         if(param2 == 4)
         {
            recoveryBase += getHpMax() * 0.1;
         }
         var _loc14_:int = Tools.toInt(recoveryBase * param3);
          if(param2 == 4)
          {
             var recoveryHit:Number = Tools.toInt(getHit() * (1 + checkTalent(4)));
             var recoveryU:Number = ratioDamage104() ? 1 : 1 + 0.5 * recoveryHit / (recoveryHit + 3000);
             _loc14_ = Tools.toInt(_loc14_ * recoveryU * getRecoveryTalentMultiplier() * activeManualEffectMultiplier());
          }
         trace(this.id + "|||||||||||||oldDamage" + getDamage() + "*" + _loc16_ + "|||||||" + getDamage() * _loc16_ + "|||||||||||" + param3 + "|||||||||||newDamage" + _loc14_);
         var _loc21_:int = 0;
         var _loc33_:int = 0;
         var _loc26_:int = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(line),offset);
         var _loc35_:int = GameMapConfig.posToPixel(pos);
         var _loc47_:Number = 0;
         var _loc45_:Number = 0;
         var _loc30_:GameMapLayer = GameMapLayer.gl;
         var _loc39_:Sprite = fightRes;
         var _loc22_:int = otherTeam;
         var _loc44_:int = 0;
         var _loc13_:Boolean = AvatarData.isAttack(param2);
         var _loc42_:Boolean = AvatarData.canMiss(param2);
         var _loc31_:Boolean = false;
         if(!_loc13_)
         {
            _loc22_ = team;
         }
         if(param2 < 0)
         {
            param2 = avatarData.damageType;
         }
         if(param5 == null)
         {
            param5 = avatarData.effectSet;
         }
         var _loc41_:* = DisplayTools.getAttrs(param5);
         if(!_loc41_)
         {
            _loc41_ = {};
         }
         // Keep the steel-impact presentation alive even when a device is
         // running an older effect table that does not know the custom marker.
         var isSteelLaneWave:Boolean = param5 == "FX_STEEL_LANE_WAVE";
         var _loc25_:* = _loc41_.h;
         if(!_loc25_)
         {
            _loc25_ = {};
         }
         _loc25_.par = _loc30_.effectLayer;
         if(_loc41_.nativeContact104===true)
         {
            for each(var contactTarget104:Avatar in param1)
            {
               if(!contactTarget104 || contactTarget104.hp<=0) continue;
               if(_loc42_ && checkMiss(this,contactTarget104,_loc25_)) continue;
               _loc46_ = _loc42_ ? countDamage(this,contactTarget104,_loc14_,param2,param9) : [_loc14_,false];
               _loc20_ = _loc42_ ? checkCrit(this,contactTarget104) : 1;
               if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(contactTarget104,_loc14_,param9);
               _loc21_+=(sixDirect105 ? sixStarDirectInjury105(contactTarget104,_loc46_,_loc20_,_loc25_,param2,this,param7,_loc14_,param9) : contactTarget104.injured(_loc46_[0],_loc20_,_loc25_,param2,this,_loc46_[1],this,param7));
            }
            return _loc21_;
         }
         GameMap.actionDelay += 0.3;
         if(playBatchAttack && (!effectSource || effectSource === this) && fightRes.parent)
         {
            _loc30_.delayCall((fightRes.parent as AvatarLayer).setFirst,GameMap.actionDelay,fightRes);
         }
         _loc27_ = Tools.clone(_loc41_.pre);
         if(_loc27_ && (!effectSource || effectSource === this))
         {
            _loc23_ = 0.05;
            _loc27_.a1 = effectSource || this;
            _loc27_.par = _loc30_.effectLayer;
            _loc30_.delayCall(DisplayTools.addEffects,GameMap.actionDelay - 0.3 / 2,_loc27_);
            GameMap.actionDelay += _loc23_;
         }
         if(_loc41_.laneWave || isSteelLaneWave)
         {
            _loc30_.delayCall(showLaneShockwave,GameMap.actionDelay,effectSource || this);
            if(playBatchAttack && (!effectSource || effectSource === this))
            {
               _loc30_.delayCall(attackTween,GameMap.actionDelay,this,param1[0]);
            }
            // A fixed impact time aligns the existing full-lane shockwave.
            // Keep the normal miss, crit, shield and injury paths for each unit.
            var waveHitDelay:Number = GameMap.actionDelay + 0.18;
            var waveEndDelay:Number = waveHitDelay;
            for each(var waveTarget:Avatar in param1)
            {
               GameMap.actionDelay = waveHitDelay;
               if(_loc42_ && checkMiss(this,waveTarget,_loc25_))
               {
                  if(skillB && avatarData.skill_diff == 1) GlobalData.skillBoo = true;
               }
               else
               {
                  _loc46_ = _loc42_ ? countDamage(this,waveTarget,_loc14_,param2,param9) : [_loc14_,false];
                  _loc20_ = _loc42_ ? checkCrit(this,waveTarget) : 1;
                  if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(waveTarget,_loc14_,param9);
                  if(_loc20_ != 1 && skillB && avatarData.skill_diff == 2) GlobalData.skillBoo = true;
                  bookHPBefore = waveTarget.hp;
                  _loc21_ += (sixDirect105 ? sixStarDirectInjury105(waveTarget,_loc46_,_loc20_,_loc25_,param2,this,param7,_loc14_,param9) : waveTarget.injured(_loc46_[0],_loc20_,_loc25_,param2,this,_loc46_[1],this,param7));
                  if(bookBasicAttack) applyBookAttackEffects(waveTarget,Math.max(0,bookHPBefore - waveTarget.hp));
               }
               waveEndDelay = Math.max(waveEndDelay,GameMap.actionDelay);
            }
            GameMap.actionDelay = Math.max(waveEndDelay,waveHitDelay + 0.32);
            return _loc21_;
         }
         if(param4 == GameMapConfig.MIN_SPACE_POS - 1)
         {
            _loc24_ = _loc26_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(line),0);
            _loc34_ = int(param8 == GameMapConfig.LINE_POS ? param8 + 400 : param8);
            _loc34_ = Math.max(-400,Math.min(GameMapConfig.LINE_POS + 400,team == 1 ? pos - _loc34_ : pos + _loc34_));
            _loc48_ = GameMapConfig.posToPixel(_loc34_);
            _loc27_ = Tools.clone(_loc41_);
            _loc27_.a1 = effectSource || this;
            _loc27_.x1 = _loc26_;
            _loc27_.x2 = _loc24_;
            _loc27_.y1 = _loc35_;
            _loc27_.y2 = _loc48_;
            _loc27_.check = true;
            _loc28_ = Math.max(DisplayTools.addBullet(_loc27_) - 0.08,0);
            delete _loc27_.check;
            _loc27_.par = _loc30_.effectLayer;
            _loc30_.delayCall(DisplayTools.addBullet,GameMap.actionDelay + 0.25,_loc27_);
            _loc26_ = GameMapConfig.offsetToPixel(0);
            if(playBatchAttack) _loc30_.delayCall(attackTween,GameMap.actionDelay,this,null,_loc26_);
            _loc26_ = pos;
            _loc10_ = param1[0];
            if(_loc10_.pos - _loc26_ < 0)
            {
               param8 = -param8;
            }
            _loc34_ = 0;
            while(_loc34_ < param1.length)
            {
               _loc10_ = param1[_loc34_];
               _loc23_ = _loc28_ * (_loc10_.pos - _loc26_) / param8;
               GameMap.actionDelay += _loc23_;
               if(_loc42_ && checkMiss(this,_loc10_))
               {
                  if(skillB)
                  {
                     if(this.avatarData.skill_diff == 1)
                     {
                        GlobalData.skillBoo = true;
                     }
                  }
               }
               else
               {
                  _loc46_ = _loc42_ ? countDamage(this,_loc10_,_loc14_,param2,param9) : [_loc14_,false];
                  _loc20_ = _loc42_ ? checkCrit(this,_loc10_) : 1;
                  if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(_loc10_,_loc14_,param9);
                  if(_loc20_ != 1)
                  {
                     if(skillB)
                     {
                        if(this.avatarData.skill_diff == 2)
                        {
                           GlobalData.skillBoo = true;
                        }
                     }
                  }
                  bookHPBefore = _loc10_.hp;
                  _loc21_ += (sixDirect105 ? sixStarDirectInjury105(_loc10_,_loc46_,_loc20_,_loc25_,param2,this,param7,_loc14_,param9) : _loc10_.injured(_loc46_[0],_loc20_,_loc25_,param2,this,_loc46_[1],this,param7));
                  if(bookBasicAttack) applyBookAttackEffects(_loc10_,Math.max(0,bookHPBefore - _loc10_.hp));
                  _loc33_++;
                  _loc26_ = _loc10_.pos;
               }
               _loc34_++;
            }
            return _loc21_;
         }
         _loc34_ = 0;
         while(_loc34_ < param1.length)
         {
            if(param4 >= 0 && param4 < GameMapConfig.MIN_SPACE_POS)
            {
               if(_loc34_ > param4)
               {
                  break;
               }
            }
            else if(_loc34_ > 0)
            {
               break;
            }
            _loc10_ = param1[_loc34_];
            GameMap.actionDelay -= _loc47_;
            if(param4 >= GameMapConfig.MIN_SPACE_POS)
            {
               _loc24_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(_loc10_.line),_loc10_.offset / 2);
            }
            else
            {
               _loc24_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(_loc10_.line),_loc10_.offset);
            }
            _loc48_ = GameMapConfig.posToPixel(_loc10_.pos);
            _loc27_ = Tools.clone(_loc41_);
            _loc27_.a1 = effectSource || this;
            _loc27_.x1 = _loc26_;
            _loc27_.x2 = _loc24_;
            _loc27_.y1 = _loc35_;
            _loc27_.y2 = _loc48_;
            _loc27_.check = true;
            _loc28_ = Math.max(DisplayTools.addBullet(_loc27_) - 0.08,0);
            _loc45_ = Math.max(_loc28_,_loc45_);
            delete _loc27_.check;
            _loc27_.par = _loc30_.effectLayer;
            _loc30_.delayCall(DisplayTools.addBullet,GameMap.actionDelay,_loc27_);
            if(playBatchAttack && (!effectSource || effectSource === this) && param4 != GameMapConfig.MIN_SPACE_POS - 1 && _loc34_ == 0)
            {
               _loc30_.delayCall(attackTween,GameMap.actionDelay,this,_loc10_);
            }
            GameMap.actionDelay += _loc28_;
            _loc47_ = _loc28_;
            if(_loc42_ && checkMiss(this,_loc10_,_loc27_.h))
            {
               if(skillB)
               {
                  if(this.avatarData.skill_diff == 1)
                  {
                     GlobalData.skillBoo = true;
                  }
               }
            }
            else
            {
               _loc46_ = _loc42_ ? countDamage(this,_loc10_,_loc14_,param2,param9) : [_loc14_,false];
               _loc20_ = _loc42_ ? checkCrit(this,_loc10_) : 1;
               if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(_loc10_,_loc14_,param9);
               if(_loc20_ != 1)
               {
                  if(skillB)
                  {
                     if(this.avatarData.skill_diff == 2)
                     {
                        GlobalData.skillBoo = true;
                     }
                  }
               }
               bookHPBefore = _loc10_.hp;
               _loc21_ += (sixDirect105 ? sixStarDirectInjury105(_loc10_,_loc46_,_loc20_,_loc25_,param2,this,param7,_loc14_,param9) : _loc10_.injured(_loc46_[0],_loc20_,_loc25_,param2,this,_loc46_[1],this,param7));
               if(bookBasicAttack) applyBookAttackEffects(_loc10_,Math.max(0,bookHPBefore - _loc10_.hp));
               _loc33_++;
            }
            _loc34_++;
         }
         if(param4 > 0 && param4 < GameMapConfig.MIN_SPACE_POS)
         {
            _loc44_ = Math.min(6,param4 + 1 - param1.length);
            if(_loc44_ > 0)
            {
               GameMap.actionDelay -= _loc47_;
               _loc40_ = GameMapTools.getRadians(new Point(_loc26_,_loc35_),new Point(_loc24_,_loc48_));
               _loc43_ = (1 / (_loc44_ + 5) + 0.12) * 1200 / param8;
               _loc34_ = 0;
               while(_loc34_ < _loc44_)
               {
                  _loc18_ = GameMapTools.vectorToGrid(_loc40_ + _loc43_ * (_loc34_ % 2 == 0 ? _loc34_ / 2 + 1 : -((_loc34_ - 1) / 2 + 1)),param8 * GameMapConfig.LANDFORM_POS);
                  _loc24_ = _loc26_ + _loc18_.x;
                  _loc48_ = _loc35_ + _loc18_.y;
                  _loc27_ = Tools.clone(_loc41_);
                  _loc27_.a1 = effectSource || this;
                  _loc27_.x1 = _loc26_;
                  _loc27_.x2 = _loc24_;
                  _loc27_.y1 = _loc35_;
                  _loc27_.y2 = _loc48_;
                  _loc27_.par = _loc30_.effectLayer;
                  _loc30_.delayCall(DisplayTools.addBullet,GameMap.actionDelay,_loc27_);
                  _loc34_++;
               }
               GameMap.actionDelay += _loc47_;
            }
         }
         GameMap.actionDelay += _loc45_ - _loc47_;
         if(param4 >= GameMapConfig.MIN_SPACE_POS)
         {
            if(_loc33_ == 0)
            {
               if(_loc41_.h)
               {
                  _loc30_.delayCall(DisplayTools.addSound,GameMap.actionDelay,_loc41_.h.s);
               }
            }
            _loc15_ = GameMap.currentMap.getAliveList(_loc22_) as Vector.<Avatar>;
            _loc15_ = _loc10_.findAimList(_loc15_,null,param4,param6);
            _loc36_ = GameMapConfig.posToPixel(param4);
            _loc47_ = 0;
            _loc45_ = 0;
            _loc34_ = 0;
            while(_loc34_ < _loc15_.length)
            {
               _loc12_ = _loc15_[_loc34_];
               if(_loc10_ != _loc12_)
               {
                  GameMap.actionDelay -= _loc47_;
                  _loc23_ = 0.15 + _loc47_;
                  _loc45_ = Math.max(_loc23_,_loc45_);
                  GameMap.actionDelay += _loc23_;
                  _loc47_ = _loc23_;
                  if(_loc42_ && checkMiss(this,_loc12_))
                  {
                     if(skillB)
                     {
                        if(this.avatarData.skill_diff == 1)
                        {
                           GlobalData.skillBoo = true;
                        }
                     }
                  }
                  else
                  {
                     _loc46_ = _loc42_ ? countDamage(this,_loc12_,_loc14_,param2,param9) : [_loc14_,false];
                     _loc20_ = _loc42_ ? checkCrit(this,_loc12_) : 1;
                     if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(_loc12_,_loc14_,param9);
                     if(_loc20_ != 1)
                     {
                        if(skillB)
                        {
                           if(this.avatarData.skill_diff == 2)
                           {
                              GlobalData.skillBoo = true;
                           }
                        }
                     }
                     bookHPBefore = _loc12_.hp;
                     _loc21_ += (sixDirect105 ? sixStarDirectInjury105(_loc12_,_loc46_,_loc20_,_loc25_,param2,_loc10_,param7,_loc14_,param9) : _loc12_.injured(_loc46_[0],_loc20_,_loc25_,param2,_loc10_,_loc46_[1],this,param7));
                     if(bookBasicAttack) applyBookAttackEffects(_loc12_,Math.max(0,bookHPBefore - _loc12_.hp));
                     _loc33_++;
                  }
               }
               _loc34_++;
            }
            GameMap.actionDelay += _loc45_ - _loc47_;
         }
         else if(param4 < 0)
         {
            _loc15_ = GameMap.currentMap.getAliveList(_loc22_) as Vector.<Avatar>;
            _loc15_ = _loc10_.findAimList(_loc15_,_loc10_.sortOnPos,GameMapConfig.LINE_POS,param6);
            param4 = -param4;
            _loc11_ = _loc10_;
            _loc34_ = 0;
            while(_loc34_ < _loc15_.length)
            {
               if(_loc44_ >= param4)
               {
                  break;
               }
               _loc12_ = _loc15_[_loc34_];
               if(_loc10_ != _loc12_)
               {
                  _loc44_++;
                  _loc26_ = _loc24_;
                  _loc35_ = _loc48_;
                  _loc24_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(_loc12_.line),_loc12_.offset);
                  _loc48_ = GameMapConfig.posToPixel(_loc12_.pos);
                  _loc27_ = Tools.clone(_loc41_);
                  _loc27_.a1 = effectSource || this;
                  _loc27_.x1 = _loc26_;
                  _loc27_.x2 = _loc24_;
                  _loc27_.y1 = _loc35_;
                  _loc27_.y2 = _loc48_;
                  _loc27_.check = true;
                  _loc23_ = Math.max(DisplayTools.addBullet(_loc27_) - 0.08,0);
                  delete _loc27_.check;
                  _loc27_.par = _loc30_.effectLayer;
                  _loc30_.delayCall(DisplayTools.addBullet,GameMap.actionDelay,_loc27_);
                  _loc11_ = _loc12_;
                  GameMap.actionDelay += _loc23_;
                  if(_loc42_ && checkMiss(this,_loc12_,_loc27_.h))
                  {
                     if(skillB)
                     {
                        if(this.avatarData.skill_diff == 1)
                        {
                           GlobalData.skillBoo = true;
                        }
                     }
                  }
                  else
                  {
                     _loc46_ = _loc42_ ? countDamage(this,_loc12_,_loc14_,param2,param9) : [_loc14_,false];
                     _loc20_ = _loc42_ ? checkCrit(this,_loc12_) : 1;
                     if(sixCritical105 && param2==1 && _loc20_>1) _loc46_ = sixStarCriticalDamage105(_loc12_,_loc14_,param9);
                     if(_loc20_ != 1)
                     {
                        if(skillB)
                        {
                           if(this.avatarData.skill_diff == 2)
                           {
                              GlobalData.skillBoo = true;
                           }
                        }
                     }
                     bookHPBefore = _loc12_.hp;
                     _loc21_ += (sixDirect105 ? sixStarDirectInjury105(_loc12_,_loc46_,_loc20_,_loc25_,param2,_loc11_,param7,_loc14_,param9) : _loc12_.injured(_loc46_[0],_loc20_,_loc25_,param2,_loc11_,_loc46_[1],this,param7));
                     if(bookBasicAttack) applyBookAttackEffects(_loc12_,Math.max(0,bookHPBefore - _loc12_.hp));
                     _loc33_++;
                  }
               }
               _loc34_++;
            }
         }
         return _loc21_;

         }
         finally
         {
            if(basicContext)
            {
               if(markedBasic && basicContext.hits.indexOf(aimTarget) >= 0) delete aimTarget.abilityState["mark_aim_"+abilityIndex];
               endAbilityAttack(basicContext);
               if(bookBasicAttack) emitModEvent("basic_attack",this,aimTarget);
               if(bookBasicAttack && this.skillB && this.skillB.skills && this.skillB.skills.length && this.skillB.skills[0][0] == "polar_basic") polarBasicAttack();
            }
         }
      }

      public function checkDangerous() : Boolean
      {
         var _loc2_:* = undefined;
         var _loc5_:int = 0;
         var _loc1_:* = null;
         var _loc6_:Number = hpRate;
         if(_loc6_ >= DANGEROUS_RATE)
         {
            return false;
         }
         return true;
      }

      public function get hpRate() : Number
      {
         return hp / hpMax;
      }

      private static function showLaneShockwave(source:Avatar) : void
      {
         var layer:GameMapLayer = GameMapLayer.gl;
         if(!layer || !source || !source.fightRes || !source.fightRes.parent) return;
         // Resolve the rendered origin at playback, including the attack bounce,
         // horizontal offset, lane translation and camera transformation.
         var origin:Point = layer.effectLayer.globalToLocal(source.fightRes.localToGlobal(new Point(source.fightRes.pivotX,source.fightRes.pivotY)));
         var endPos:int = source.team == 1 ? -150 : GameMapConfig.LINE_POS + 150;
         var finish:Point = layer.effectLayer.globalToLocal(layer.getLineSpr(source.line).localToGlobal(new Point(0,GameMapConfig.posToPixel(endPos))));
         var laneWidth:Number = Math.abs(GameMapConfig.offsetToPixel(GameMapConfig.lineOffset * 0.92));
         var wave:Sprite = new Sprite();
         wave.name = "steelLaneWave";
         wave.touchable = false;
         wave.x = origin.x;
         wave.y = origin.y;
         layer.effectLayer.addChild(wave);
         // Hold a fully formed native ring frame. Its startup bounds are zero
         // and its later swirl frames would shrink a lane wave into a dot.
         for(var echo:int = 0;echo < 3;echo++)
         {
            var front:Sprite = new Sprite();
            var art:DragonBonesSprite = DisplayTools.newDisplayObject({id:"e001",loop:true,m:"add"}) as DragonBonesSprite;
            if(!art) continue;
            wave.addChild(front);
            front.addChild(art);
            art.armature.advanceTime(0);
            art.armature.advanceTime(0.52);
            art.stop();
            var artWidth:Number = Math.max(1,art.width);
            var fullScale:Number = laneWidth / artWidth;
            art.scaleX = fullScale;
            art.scaleY = fullScale * 0.38;
            // Keep only the forward half: a broad crescent, not a flat beam.
            front.clipRect = new Rectangle(-laneWidth * 0.6,source.team == 1 ? -laneWidth * 0.26 : 0,laneWidth * 1.2,laneWidth * 0.26);
            front.scaleX = 0.45;
            front.scaleY = 0.65;
            front.alpha = 0.8 - echo * 0.22;
            var travel:Tween = new Tween(front,0.32,"easeOut");
            travel.delay = echo * 0.035;
            travel.moveTo(finish.x - origin.x,finish.y - origin.y);
            travel.animate("scaleX",1);
            travel.animate("scaleY",1);
            layer.addTween(travel);
         }
         var fade:Tween = new Tween(wave,0.22,"easeOut");
         fade.delay = 0.39;
         fade.fadeTo(0);
         fade.onComplete = wave.removeFromParent;
         fade.onCompleteArgs = [true];
         layer.addTween(fade);
      }

      private function showCurseImpact() : void
      {
         var layer:GameMapLayer = GameMapLayer.gl;
         if(!layer || !fightRes || !fightRes.parent) return;
         var impact:DisplayObject = DisplayTools.newDisplayObject(DisplayTools.getAttrs("CURSE_IMPACT"));
         if(!impact) return;
         impact.name = "curseImpact";
         var origin:Point = layer.effectLayer.globalToLocal(fightRes.localToGlobal(new Point(fightRes.pivotX,fightRes.pivotY)));
         impact.x = origin.x;
         impact.y = origin.y;
         layer.effectLayer.addChild(impact);
         var pulse:Tween = new Tween(impact,0.35,"easeOut");
         pulse.scaleTo(1.15);
         pulse.fadeTo(0);
         pulse.onComplete = impact.removeFromParent;
         pulse.onCompleteArgs = [true];
         layer.addTween(pulse);
      }

      private function absorbShieldDamage(amount:int, factor:Number) : int
      {
         if(amount<=0) return amount;
         if(!isFinite(factor) || factor<1) factor=1;
         var keys:Array=[];
         for(var key:String in buffs) if(buffs[key] && buffs[key].type=="shield") keys.push(key);
         // Consume the soonest-expiring pool first. Round only once after all
         // pools so splitting shields cannot lose damage to repeated rounding.
         var pools:Object=buffs;
         keys.sort(function(a:String,b:String):Number {return pools[a].round-pools[b].round || (a<b ? -1 : a>b ? 1 : 0);});
         var budget:Number=Tools.toInt(amount*factor);
         var spent:Number=0;
         for each(key in keys)
         {
            var shield:Buff=buffs[key] as Buff;
            var take:Number=Math.min(Math.max(0,shield.value),budget-spent);
            shield.value-=take;spent+=take;
            if(shield.value<=0) removeBuff(key,false,false);
            if(spent>=budget) break;
         }
         return Tools.toInt(Math.max(0,Number(amount)-spent/factor));
      }

      public function injured(param1:int, param2:Number = 1, param3:* = null, param4:int = -1, param5:Avatar = null, param6:Boolean = false, param7:Avatar = null, param8:Buff = null, dotKind:String = "", derivedDamage104:Boolean = false, fixedRecovery105:Boolean = false) : int
      {
         if(abilityState.sixReactionElise105 && param4!=0 && param4!=4 && param4!=5) return 0;
         if(abilityState.sixReactionMfWound105 || param7 && param7.sixReactionPassive105("mf"))
            param1=sixReactionIncoming105(param1,param7,param4);
         var settledCriticalDamage104:Number=0;
         var abilityHpBefore:int = hp;
         if(abilityState.sixBatchZiggsWound105 || abilityState.sixBatchKayleGuard105 ||
            skillB && avatarData.id=="A_1119_6" || param7 && param7.skillB && param7.avatarData.id=="A_1126_6")
            param1=sixBatchIncoming105(param1,param7,param4,dotKind);
         var modShieldBefore:Number = shieldValue104();
         var nurseHealAmount:int = 0;
         var abilityDamageTaken:Number = 0;
         var statisticsShield104:Number = 0;
         var abyssShieldSpent104:Number = 0;
         var abyssRevivedNow104:Boolean = false;
         if(abyssOrigin104 != "relic_reflect") param1 = int(param1 * abilityDirectMultiplier(param7,param4));
         var _loc12_:String = null;
         var _loc21_:* = 0;
         var _loc9_:Buff = null;
         var _loc17_:* = undefined;
         var _loc13_:Number = Number(NaN);
         var _loc18_:Number = Number(NaN);
         var _loc10_:int = 0;
         var _loc16_:int = 0;
         var _loc22_:int = 0;
         var _loc15_:int = 0;
         var _loc25_:int = 0;
         var _loc23_:String = null;
         if(hp <= 0)
         {
            return 0;
         }
         if(param4 == 0)
         {
            if(param8)
            {
               var priorCurse:Buff = buffs["curse"];
               addBuff(param8.type,param8.round,param8.value,0,-1,param7 || param5);
               // Zero-damage actions return before the normal hit VFX below.
               // Show a burst only when the curse was actually accepted;
               // purification and weaker reapplications must not fake a hit.
               if(param8.type == "curse" && buffs["curse"] && buffs["curse"] !== priorCurse)
               {
                  GameMapLayer.gl.delayCall(showCurseImpact,GameMap.actionDelay);
               }
            }
            return 0;
         }
         if(param7 && param7.currentSkillKillContext)
         {
            param7.currentSkillKillContext.hit = true;
            if(getType() == 1)
            {
               param7.currentSkillKillContext.hitHero = true;
               if(param7.currentSkillKillContext.hitHeroes is Array && param7.currentSkillKillContext.hitHeroes.indexOf(this) < 0)
               {
                  param7.currentSkillKillContext.hitHeroes.push(this);
               }
            }
         }
         var _loc19_:GameMapLayer = GameMapLayer.gl;
         var _loc11_:int = 35;
         var _loc14_:Number = 0.5;
         param3 = Tools.clone(param3);
         if(param4 == 1)
         {
            _loc21_ = 16728128;
         }
         else if(param4 == 2)
         {
            _loc21_ = 8421631;
         }
         else if(param4 == 3)
         {
            _loc21_ = 13648080;
         }
         else if(param4 == 8)
         {
            _loc21_ = 13648127;
         }
         else if(param4 == 4)
         {
            _loc21_ = 65280;
         }
         else if(param4 == 6)
         {
            _loc21_ = 53248;
            _loc14_ = 0.75;
            if(!dotPopup104) GameMap.actionDelay += 1 / 2;
         }
         else if(param4 == 7)
         {
            _loc21_ = 16737792;
            _loc14_ = 0.75;
            if(!dotPopup104) GameMap.actionDelay += 1 / 2;
         }
         else
         {
            _loc21_ = 0;
         }
         param1 *= 1;
         var _loc24_:* = damageAttack104();
         if(param4 == 4)
         {
            param1 = int(skin2Incoming(param1,param7 || param5,param4));
            var bookHealer:Avatar = param7 || param5 || this;
            if(!fixedRecovery105 && abyssOrigin104 != "relic_lifesteal" && ratioDamage104()) param1 = Tools.toInt(param1 * precisionRecovery105(bookHealer));
            param1 = int(bookHealer.abyssAmplifyHeal104(param1));
            param1 = Tools.toInt(param1 * (1 + bookHealer.getBookCombatBonus("healing")));
            if(hasManualDotKind("burn"))
            {
               param1 = Tools.toInt(param1 * 0.6);
            }
            nurseHealAmount = Math.max(0,param1);
            param1 = Math.min(param1,hpMax - hp);
            hp += param1;
            var sustain:Object=currentAbilityAttack();
            if(sustain && sustain.owner===this && sustain.sixReactionMfHeal105)
            {
               sustain.sixReactionMfHeal105=false;
               sustain.sixReactionMfOverflow105=Math.max(0,nurseHealAmount-param1);
            }
            recordStatistics104(bookHealer,this,0,Math.max(0,param1));
            GameMapTools.gameTrace(id + "治療++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + param1);
            _loc12_ = GlobalLanguageStr.getLanguageStr(30000) + param1;
            _loc14_ = 0.75;
         }
         else
         {
            if(!derivedDamage104) param1 = Tools.toInt(Tools.toInt(param1 * param2) * _loc24_[21]);
            _loc13_ = Tools.toInt(getTough() * (1 + checkTalent(7)));
            if(ratioDamage104())
            {
               var damageSource:Avatar = param7 || param5;
               var critical:Number = damageSource ? Tools.toInt(damageSource.getCrit()*(1+damageSource.checkTalent(6))) : 0;
               _loc18_ = abyssOrigin104 == "relic_reflect" ? 1 : opposedPower105(Math.max(0,_loc13_) - Math.max(0,critical));
            }
            else _loc18_ = 1 + _loc13_ * _loc24_[15] / (_loc13_ + _loc24_[13]);
            GameMapTools.gameTrace("減傷" + _loc18_,"原傷害" + param1,"新傷害" + Tools.toInt(param1 / _loc18_));
            var fioraAttack:Object=currentAbilityAttack();
            if(!derivedDamage104 && !(fioraAttack && fioraAttack.owner===param7 && fioraAttack.sixForceCrit105))
               param1 = Tools.toInt(param1 / _loc18_);
            trace("最终伤害算减伤之前" + param1);
            if(abyssOrigin104 != "relic_reflect") switch(param4 - 1)
            {
               case 0:
                  param1 = Tools.toInt(param1 + param1 * checkTalent(14,param7 ? 1 : 0));
                  break;
               case 1:
                  param1 = Tools.toInt(param1 + param1 * checkTalent(15,param7 ? 1 : 0));
                  break;
               case 2:
                  param1 = Tools.toInt(param1 + param1 * checkTalent(16,param7 ? 1 : 0));
                  break;
               case 5:
                  param1 = Tools.toInt(param1 + param1 * checkTalent(16,param7 ? 1 : 0));
                  break;
               case 6:
                  param1 = Tools.toInt(param1 + param1 * checkTalent(16,param7 ? 1 : 0));
            }
            trace("最终伤害算减伤之后" + param1);
            if(hasManualDotKind("poison")) param1 = Tools.toInt(param1 * 1.2);
            if(abyssOrigin104 != "relic_reflect")
            {
               param1 = int(skin2Incoming(param1,param7 || param5,param4));
               param1 = int(yasuoDamage104(param1,param7 || param5,derivedDamage104));
            }
            if(abilityState.sixMorganaSources105 || param7 && param7.skillB && param7.avatarData.id=="A_1024_6")
               param1 = sixFollowupIncoming105(param1,param7,param4,dotKind);
            param1 = abyssModifyDamage104(param1,param7,param4,dotKind);
            settledCriticalDamage104=Math.max(0,param1);
            _loc9_ = buffs["shield"] as Buff;
            if(shieldValue104()>0)
            {
               var bookShieldFactor:Number = (1 + (param7 ? param7.getBookCombatBonus("shield_damage") : 0)) * (param7 ? param7.abyssShieldMultiplier104() : 1);
               if(dotKind == "bleed" || dotKind == "phantasm") bookShieldFactor *= 3;
               var statisticsBeforeShield104:Number = param1;
               param1 = absorbShieldDamage(param1,bookShieldFactor);
               statisticsShield104 = Math.max(0,statisticsBeforeShield104-param1);
               abyssShieldSpent104 = Math.max(0,modShieldBefore - shieldValue104());
            }
            if(param7 && param7.manualSkillDamageCapture && param7.manualSkillDamageCapture.active === true && param7.manualSkillDamageCapture.owner === param7)
            {
               param7.manualSkillDamageCapture.total = Number(param7.manualSkillDamageCapture.total) + Math.min(Math.max(0,param1),Math.max(0,hp));
            }
            hp -= param1;
            abilityDamageTaken = Math.min(Math.max(0,param1),Math.max(0,abilityHpBefore));
            if(param4 == 6)
            {
               _loc12_ = (dotKind == "bleed" ? "流血" : dotKind == "phantasm" ? "幻象" : GlobalLanguageStr.getLanguageStr(30013)) + param1;
            }
            else if(param4 == 7)
            {
               _loc12_ = GlobalLanguageStr.getLanguageStr(30029) + param1;
            }
            else
            {
               _loc12_ = String(param1);
            }
            if(!param7 && dotKind == "")
            {
               param7 = GameMap.currentAvatar;
            }
            // Native DOTs retain their source for events without becoming direct-hit retaliation.
            if(param7 && param7.team != team && param4 != 6 && param4 != 7)
            {
               _loc17_ = DisplayTools.getAttrs("BACK_BUL");
               if(hp > 0)
               {
                  _loc9_ = buffs["back"] as Buff;
                  if(_loc9_)
                  {
                     _loc16_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(line),offset);
                     _loc22_ = GameMapConfig.posToPixel(pos);
                     _loc15_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(param7.line),param7.offset);
                     _loc25_ = GameMapConfig.posToPixel(param7.pos);
                     _loc17_.a1 = this;
                     _loc17_.a2 = param7;
                     _loc17_.par = _loc19_.effectLayer;
                     _loc19_.delayCall(DisplayTools.addBullet,GameMap.actionDelay,_loc17_);
                     _loc19_.delayCall(_loc19_.infoLayer.popText,GameMap.actionDelay,GlobalLanguageStr.getLanguageStr(30060),_loc16_,_loc22_,16737792,25,0.5,team == 1);
                     param7.addBuff("burn",1,Tools.toInt(Tools.toInt(getDamage() + getDamage() * checkTalent(1)) * _loc9_.value),0.25 * 2,25,this);
                  }
               }
               else
               {
                  _loc9_ = buffs["avenge"] as Buff;
                  if(_loc9_)
                  {
                     _loc16_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(line),offset);
                     _loc22_ = GameMapConfig.posToPixel(pos);
                     _loc15_ = GameMapConfig.lineToPixel(GameMap.currentMap.getShowLine(param7.line),param7.offset);
                     _loc25_ = GameMapConfig.posToPixel(param7.pos);
                     _loc17_.a1 = this;
                     _loc17_.a2 = param7;
                     _loc17_.par = _loc19_.effectLayer;
                     _loc19_.delayCall(DisplayTools.addBullet,GameMap.actionDelay,_loc17_);
                     _loc19_.delayCall(_loc19_.infoLayer.popText,GameMap.actionDelay,GlobalLanguageStr.getLanguageStr(30061),_loc16_,_loc22_,16737792,25,0.5,team == 1);
                     param7.addBuff("burn",1,Tools.toInt(hpMax * _loc9_.value),0.25 * 2,25,this);
                     removeBuff("avenge");
                  }
               }
            }
         }
         if(fightRes.parent)
         {
            _loc19_.delayCall((fightRes.parent as AvatarLayer).setFirst,GameMap.actionDelay,fightRes);
         }
         var _loc20_:String = null;
         if(param2 > 1)
         {
            _loc12_ = GlobalLanguageStr.getLanguageStr(30011) + _loc12_;
            _loc11_ = 45;
            _loc14_ = 0.75;
            _loc20_ = "critBg";
         }
         if(param6 == true)
         {
            _loc12_ = GlobalLanguageStr.getLanguageStr(30004) + _loc12_;
         }
         _loc19_.delayCall(refreshHp,GameMap.actionDelay,hp,false,shieldValue104(),hpMax);
         if(param3)
         {
            param3.a1 = this;
            param3.a2 = param5;
            param3.re = true;
            // A visual effect is optional; keep HP/status settlement and number
            // popups running when a data-authored action intentionally has none.
            param3.par = _loc19_.effectLayer;
            _loc19_.delayCall(DisplayTools.addEffects,GameMap.actionDelay,param3);
         }
         if(buffs["taunt"])
         {
            if(param4 != 4 && param4 != 6 && param4 != 7 && param4 != 5 && param4 != 8)
            {
               _loc17_ = DisplayTools.getAttrs("TAUNT_HIT_EFF");
               _loc17_.a1 = this;
               _loc17_.par = _loc19_.effectLayer;
               _loc19_.delayCall(DisplayTools.addEffects,GameMap.actionDelay - 1,_loc17_);
            }
         }
         if(_loc21_ != 0)
         {
            if(dotPopup104 && (param4 == 6 || param4 == 7)) collectDotPopup104(param1,param4);
            else _loc19_.delayCall(_loc19_.infoLayer.popInjuredForAvatar,GameMap.actionDelay,_loc12_,this,_loc21_,_loc11_,_loc14_,_loc20_,param5);
         }
         if(param8)
         {
            addBuff(param8.type,param8.round,param8.value,0,-1,param7 || param5);
         }
         if(hp <= 0)
         {
            if(param7)
            {
               if(param7.skillB)
               {
                  if(param7.avatarData.skill_diff == 3)
                  {
                     GlobalData.skillBoo = true;
                  }
               }
            }
         }
         if(hp <= 0 && manualLethalFloor)
         {
            var lethalKey:String = null;
            var lethalFloor:Object = null;
            var lethalMinHp:int = 0;
            var manualLethalCleanse:Boolean = false;
            for(lethalKey in manualLethalFloor)
            {
               lethalFloor = manualLethalFloor[lethalKey];
               if(lethalFloor && int(lethalFloor.rounds) > 0)
               {
                  lethalMinHp = Math.max(lethalMinHp,int(lethalFloor.minHp));
                  if(lethalFloor.cleanseOnTrigger === true) manualLethalCleanse = true;
               }
            }
            if(lethalMinHp > 0)
            {
               if(manualLethalCleanse) removeAllDebuff();
               hp = Math.max(1,Math.min(hpMax,lethalMinHp));
               if(_loc19_) _loc19_.delayCall(refreshHp,GameMap.actionDelay,hp,false,shieldValue104(),hpMax);
               GameMapTools.gameTrace(id + "触发限时保命，保留" + hp + "生命");
            }
         }
         skin2Lethal();
         if(hp <= 0 && buffs["bless"])
         {
            removeAllDebuff();
            removeBuff("bless");
            hp = Math.max(1,Tools.toInt(hpMax * damageAttack104()[20]));
            GameMapTools.gameTrace(id + "之后神佑+" + hp);
            _loc19_.delayCall(blessFade,GameMap.actionDelay);
            _loc19_.delayCall(blessCure,GameMap.actionDelay + 1,hp);
            GameMap.actionDelay += 1 / 2;
         }
         if(hp <= 0 && tryndUndyingActive)
         {
            tryndUndyingActive = false;
            tryndUndyingRounds = 0;
            hp = 1;
            GameMapTools.gameTrace(id + "触发限时一次免死，保留1生命");
            _loc19_.delayCall(refreshHp,GameMap.actionDelay,hp,false,shieldValue104(),hpMax);
         }
         if(hp <= 0 && abilityHpBefore > 0 && param4 != 4 && abyssTryRevive104())
         {
            abyssRevivedNow104 = true;
            _loc19_.delayCall(refreshHp,GameMap.actionDelay,hp,false,shieldValue104(),hpMax);
         }
         var modActualDamage:Number = param4 == 4 ? 0 : (abyssRevivedNow104 ? Math.max(0,abilityHpBefore) : Math.max(0,abilityHpBefore-Math.max(0,hp)));
         if(modActualDamage>0 && (abilityState.sixReactionMfStacks105 || skillB && avatarData.id=="A_1036_6"))
            sixReactionDamageTaken105();
         if(abilityHpBefore > 0 && param4 != 0 && param4 != 4 && param4 != 5) abyssAfterDamage104(param7,modActualDamage,abyssShieldSpent104,param4,dotKind);
         if(param4 >= 1 && param4 != 4 && param4 != 5)
            recordStatistics104(param7 || param5,this,abilityDamageTaken+statisticsShield104,0);
         var modActualHeal:Number = Math.min(Math.max(0,hpMax-abilityHpBefore),nurseHealAmount);
         var modOverheal:Number = Math.max(0,nurseHealAmount-modActualHeal);
         if(param4==6 && param7 && param7.s2Family()==1209 && modActualDamage>0) param7.skin2PoisonTick(this);
         var modKilled:Boolean = abilityHpBefore > 0 && hp <= 0;
         var modShieldBroke:Boolean = modShieldBefore > 0 && shieldValue104()<=0;
         if(param4 == 4 && nurseHealAmount > 0)
         {
            emitModEvent("healed",param7 || param5 || this,this,modActualHeal,modOverheal);
            if(param7 || param5) (param7 || param5).emitModEvent("heal_done",param7 || param5,this,modActualHeal,modOverheal);
         }
         else if(param4 >= 1 && param4 != 4 && param4 != 5)
         {
            if(modActualDamage > 0)
            {
               emitModEvent("damage_taken",param7,this,modActualDamage);
               if(param7) param7.emitModEvent("damage_dealt",param7,this,modActualDamage);
            }
            if(param4 <= 3 && param7)
            {
               param7.emitModEvent("hit",param7,this,modActualDamage);
               if(param2 > 1)
               {
                  param7.emitModEvent("crit",param7,this,modActualDamage);
                  param7.yasuoCritical104(this,settledCriticalDamage104);
               }
            }
            if(modShieldBroke)
               emitModEvent("shield_break",param7,this,modActualDamage);
            if(modKilled)
            {
               if(param7 && param7.team != team) param7.emitModEvent("kill",param7,this,modActualDamage);
               emitModEvent("death",param7,this,modActualDamage);
            }
         }
         if(param4 == 6 || param4 == 7 || param4 == 8)
         {
            GameMap.actionDelay += 1;
         }
         else if(hp <= 0)
         {
            if(hp <= -hpMax * 0.2)
            {
               dead(param5);
            }
            else
            {
               dead();
            }
         }
         if(hp <= 0 && param7 && param7.currentSkillKillContext)
         {
            param7.currentSkillKillContext.killed = true;
            param7.currentSkillKillContext.killedTarget = this;
            param7.currentSkillKillContext.killedType = getType();
            param7.currentSkillKillContext.killedSummon = buffs && buffs["summon"] != null;
         }
         if(param4 <= 3 || param4 >= 6)
         {
            ++GameMap.damageNum;
            _loc23_ = "受傷";
            if(param4 == 6)
            {
               _loc23_ = "毒";
            }
            else if(param4 == 7)
            {
               _loc23_ = "烧";
            }
            else if(param4 == 8)
            {
               _loc23_ = "劈";
            }
            if(GameMap.currentAvatar)
            {
               GameMapTools.gameTrace(GameMap.damageNum + ":" + GameMap.currentAvatar.id,GameMap.currentAvatar.team,"        ",id,team + _loc23_ + ":",param1);
            }
            else
            {
               GameMapTools.gameTrace(GameMap.damageNum + ":" + id,team + _loc23_ + ":",param1);
            }
         }
         if(param4 != 4) abilityRecordDamage(param7,param4,abilityHpBefore,abilityDamageTaken);
         if(modActualDamage>0 && skillB && avatarData.id=="A_1138_6" && sixFollowupPassive105("tahm"))
            abilityState.sixTahmGrey105=Number(abilityState.sixTahmGrey105 || 0)+modActualDamage;
         var catContext:Object = currentAbilityAttack();
         if(param2 > 1 && param4 >= 1 && param4 <= 3 && param7 && catContext && catContext.owner === param7 && catContext.catCaptainCapture)
            catContext.catCrits = int(catContext.catCrits) + 1;
         if(hp <= 0 && abilityHpBefore > 0 && param7 && param7.team != team && param7.skillB && param7.skillB.skills && param7.skillB.skills.length && param7.skillB.skills[0][0] == "cat_passive")
            param7.queueCatSkinKill();
         if(hp <= 0 && abilityHpBefore > 0 && param7 && param7.team != team && param7.skillB && param7.skillB.skills && param7.skillB.skills.length && param7.skillB.skills[0][0] == "santa_kill")
            if(getType() == 1 && !isManualSummonUnit) param7.queueSantaKill();
         if(param4 == 4 && nurseHealAmount > 0 && abyssOrigin104 != "relic_lifesteal") queueNurseHealing(nurseHealAmount,Math.max(0,nurseHealAmount-Math.max(0,hpMax-abilityHpBefore)));
         if(param4>=1 && param4<=3 && param7 && catContext &&
            (catContext.sixNamiWave105 || catContext.sixNamiTicket105 || param7.abilityState.sixNamiBless105))
            param7.sixFollowupAfterHit105(this,catContext,abilityDamageTaken+statisticsShield104);
         if(param7 && param7.skillB && (param4>=1 && param4<=3 || param4>=6 && param4<=8))
         {
            param7.sixBatchAfterDamage105(this,abilityDamageTaken+statisticsShield104);
            param7.sixReactionMfDealt105(this,modActualDamage+statisticsShield104);
         }
         return param1;
      }

      public function ready() : void
      {
         var _loc1_:GameMapLayer = GameMapLayer.gl;
         _loc1_.juggler.removeTweens(fightRes);
         hideRange();
         rangePreviewQueued = false;
         rangeMoveEndsAt = 0;
         if(hp <= 0)
         {
            hp = hpMax;
         }
         else
         {
            refreshHp(hp,true);
         }
         fightRes.visible = true;
         fightRes.alpha = 1;
         fightRes.scaleX = fightRes.scaleY = getScale();
         fightRes.rotation = 0;
         if(skill0)
         {
            skill0.ready();
         }
         if(skill1)
         {
            skill1.ready();
         }
         if(skill2)
         {
            skill2.ready();
         }
         if(skillB)
         {
            skillB.ready();
         }
         if(m_buff)
         {
            m_buff.removeChildren();
         }
         if(m_fightBg)
         {
            m_fightBg.flatten();
         }
         resetBuff();
      }

      private function queueVitalBar104(delay:Number = -1) : void
      {
         var layer:GameMapLayer = GameMapLayer.gl;
         if(!mBloodSpr || !layer) return;
         // Capture all three values now: later hits/buffs may settle before
         // this visual frame is played by the battle animation queue.
         layer.delayCall(refreshVitalBar104,delay<0 ? GameMap.actionDelay : delay,hp,hpMax,shieldValue104());
      }

      private function refreshVitalBar104(health:Number, maximum:Number, shield:Number) : void
      {
         if(!mBloodSpr) return;
         mBloodSpr.setHealthValues104(health,maximum);
         maximum = Math.max(1,maximum);
         mBloodSpr.refresh(health/maximum,false,shield/maximum);
      }

      public function refreshHp(param1:int, param2:Boolean = false, shield:Number = -1, maximum:Number = 0) : void
      {
         if(!mBloodSpr) return;
         if(maximum<=0) maximum=hpMax;
         if(shield<0) shield=shieldValue104();
         var _loc5_:int = 0;
         var _loc4_:int = 0;
         var _loc3_:int = 0;
         var _loc6_:Tween = null;
         var _loc7_:GameMapLayer = GameMapLayer.gl;
         var _loc8_:Boolean = param1 / Math.max(1,maximum) < mBloodSpr.perRate;
         if(GameMap.currentAvatar != this)
         {
            if(!param2 && _loc8_)
            {
               _loc6_ = new Tween(fightRes,0.2 / 2,"easeOutBack");
               _loc6_.animate("pivotY",team == 1 ? -20 : 20);
               _loc7_.addTween(_loc6_);
               _loc6_ = new Tween(fightRes,0.2,"easeIn");
               _loc6_.delay = 0.2 / 2;
               _loc6_.animate("pivotY",0);
               _loc7_.addTween(_loc6_);
            }
            else if(GameMap.currentMap && GameMap.currentMap.isFight)
            {
               _loc6_ = new Tween(fightRes,0.2,"easeInOut");
               _loc6_.scaleTo(getScale() * 1.2);
               _loc7_.addTween(_loc6_);
               _loc6_ = new Tween(fightRes,0.2,"easeInOut");
               _loc6_.delay = 0.2;
               _loc6_.scaleTo(getScale());
               _loc7_.addTween(_loc6_);
            }
         }
         else
         {
            _loc6_ = new Tween(fightRes,0.2,"easeInOut");
            _loc6_.scaleTo(getScale());
            _loc7_.addTween(_loc6_);
            _loc6_ = new Tween(fightRes,0.2,"easeInOut");
            _loc6_.delay = 0.2;
            _loc6_.scaleTo(getScale() * 1.2);
            _loc7_.addTween(_loc6_);
         }
         refreshVitalBar104(param1,maximum,shield);
      }

      public function dead(param1:Avatar = null) : void
      {
         if(hp <= 0) abilityDeath();
         var _loc2_:GameMapLayer = GameMapLayer.gl;
         hideRange();
         if(GameMapLayer.isFastest)
         {
            _loc2_.delayCall(deadFast,GameMap.actionDelay);
         }
         else
         {
            _loc2_.delayCall(deadFade,GameMap.actionDelay,param1);
         }
         GameMap.currentMap.checkLineLose(team,line);
         if(getEffectiveActionType() != 3)
         {
            GameMap.currentMap.checkEnd();
         }
      }

      public function deadFast() : void
      {
         var _loc1_:GameMapLayer = GameMapLayer.gl;
         _loc1_.juggler.removeTweens(fightRes);
         fightRes.visible = false;
      }

      public function drop() : void
      {
         var _loc3_:Tween = null;
         var _loc4_:GameMapLayer = GameMapLayer.gl;
         var _loc1_:int = fightRes.x + _loc4_.getLineSpr(line).x;
         var _loc2_:int = fightRes.y;
         var _loc5_:Object = {
            "id":"e301",
            "x":"_x",
            "y":"_y"
         };
         _loc5_.par = _loc4_.effectLayer;
         m_drop = DisplayTools.addEffectOne(_loc5_);
         m_drop.scaleX = m_drop.scaleY = 0.2;
         _loc3_ = new Tween(m_drop,0.4,"easeOut");
         _loc3_.scaleTo(1.5);
         _loc3_.animate("rotation",3.141592653589793 * 2);
         _loc3_.animate("y",m_drop.y - 30);
         _loc4_.addTween(_loc3_);
         _loc3_ = new Tween(m_drop,0.3,"easeIn");
         _loc3_.delay = 0.8;
         _loc3_.scaleTo(1);
         _loc4_.addTween(_loc3_);
         SoundManager.getOnlyExample().playSound("drop");
         _loc4_.delayCall(dropFade,1.5);
      }

      public function dropFade() : void
      {
         var _gl:GameMapLayer;
         var _x1:int;
         var _x2:int;
         var _time:Number;
         var _tween:Tween;
         if(!m_drop)
         {
            return;
         }
         _gl = GameMapLayer.gl;
         _x1 = m_drop.x;
         _x2 = 40;
         _time = new Point(_x1 - _x2,m_drop.y - GameMapConfig.FIGHT_HEIGHT).length / GameMapConfig.FIGHT_HEIGHT;
         _time *= 0.6;
         _tween = new Tween(m_drop,_time);
         _tween.animate("y",GameMapConfig.FIGHT_HEIGHT);
         _tween.onComplete = function():void
         {
            if(m_drop)
            {
               m_drop.removeFromParent(true);
               m_drop = null;
            }
            if(_gl.uiLayer.m_bag)
            {
               _gl.juggler.removeTweens(_gl.uiLayer.m_bag);
               _tween = new Tween(_gl.uiLayer.m_bag,0.2,"easeOut");
               _tween.scaleTo(1.1);
               _gl.addTween(_tween);
               _tween = new Tween(_gl.uiLayer.m_bag,0.2,"easeIn");
               _tween.delay = 0.2;
               _tween.scaleTo(1);
               _gl.addTween(_tween);
            }
         };
         _gl.addTween(_tween);
         _tween = new Tween(m_drop,_time,"easeInBack");
         _tween.animate("x",_x2);
         _gl.addTween(_tween);
      }

      public function blessFade() : void
      {
         var _loc1_:Tween = null;
         var _loc2_:GameMapLayer = GameMapLayer.gl;
         if(fightRes)
         {
            _loc1_ = new Tween(fightRes,1 / 2,"easeInOut");
            _loc1_.fadeTo(0);
            _loc1_.scaleTo(0.2);
            _loc2_.addTween(_loc1_);
         }
      }

      public function blessCure(param1:int) : void
      {
         var _loc4_:String = null;
         var _loc2_:Tween = null;
         var _loc5_:* = undefined;
         _loc4_ = GlobalLanguageStr.getLanguageStr(30081) + GlobalLanguageStr.getLanguageStr(30000) + param1;
         var _loc3_:GameMapLayer = GameMapLayer.gl;
         if(fightRes)
         {
            _loc2_ = new Tween(fightRes,1 / 2,"easeInOut");
            _loc2_.fadeTo(1);
            _loc2_.scaleTo(getScale());
            _loc3_.addTween(_loc2_);
         }
         refreshHp(param1);
         _loc5_ = DisplayTools.getAttrs("BLESS_EFF");
         _loc5_.a1 = this;
         _loc5_.par = _loc3_.effectLayer;
         DisplayTools.addEffects(_loc5_);
         _loc3_.infoLayer.popInjuredForAvatar(_loc4_,this,65280,35,0.75);
      }

      public function deadFade(param1:Avatar = null) : void
      {
         var _tween:Tween;
         var _res1:Sprite;
         var _res2:Sprite;
         var _SpeedX:Number;
         var _SpeedY:Number;
         var _dis:Number;
         var _w:int;
         var _rect:Rectangle;
         var _re:Object;
         var i:int;
         var _x:int;
         var _y:int;
         var _srcAvatar:Avatar = param1;
         var _gl:GameMapLayer = GameMapLayer.gl;
         var _delay:Number = 0;
         _gl.juggler.removeTweens(fightRes);
         _tween = new Tween(fightRes,0.2 / 2,"easeOutBack");
         _tween.animate("pivotY",team == 1 ? -20 : 20);
         _gl.addTween(_tween);
         _tween = new Tween(fightRes,0.2,"easeIn");
         _tween.delay = 0.2 / 2;
         _tween.animate("pivotY",0);
         _gl.addTween(_tween);
         if(isDrop)
         {
            drop();
         }
         if(_srcAvatar && avatarData.actionType != 3)
         {
            _delay = 0.4;
            _res1 = fightRes;
            _res2 = _srcAvatar.fightRes;
            _SpeedX = _res1.x - _res2.x + Math.random() * 100 - 100 / 2;
            _SpeedY = _res1.y - _res2.y;
            _dis = new Point(_SpeedX,_SpeedY).length;
            _SpeedX = _SpeedX * 1000 / _dis;
            _SpeedY = _SpeedY * 1000 / _dis;
            _w = GameMapConfig.offsetToPixel(GameMapConfig.lineOffset);
            _rect = new Rectangle(-_w / 2,0,_w,GameMapConfig.FIGHT_HEIGHT);
            _x = _res1.x;
            _y = _res1.y;
            _res1.parent.setChildIndex(_res1,_res1.parent.numChildren - 1);
            _res1.scaleX = _res1.scaleY = 1.1;
            i = 0;
            while(i < 3)
            {
               _re = GameMapTools.getHitTime(_x,_y,_SpeedX,_SpeedY,_rect);
               _x = int(_re.pos.x);
               _y = int(_re.pos.y);
               _tween = new Tween(fightRes,_re.time);
               _tween.delay = _delay;
               _tween.moveTo(_x,_y);
               _tween.animate("rotation",(_delay + _re.time) * 10);
               _gl.addTween(_tween);
               if(i == 3 - 1)
               {
                  _tween = new Tween(fightRes,0.1);
                  _tween.delay = _delay + _re.time - 0.1;
                  _tween.fadeTo(0);
                  _tween.onComplete = function():void
                  {
                     fightRes.removeFromParent();
                     fightRes.visible = false;
                  };
                  _gl.addTween(_tween);
               }
               if(_re.side == 1)
               {
                  _SpeedX = -_SpeedX;
               }
               else
               {
                  _SpeedY = -_SpeedY;
               }
               _delay += _re.time;
               i += 1;
            }
            return;
         }
         _tween = new Tween(fightRes,0.5,"easeInOut");
         _tween.delay = _delay;
         _tween.fadeTo(0);
         _tween.scaleTo(0.2);
         _tween.onComplete = function():void
         {
            fightRes.visible = false;
            fightRes.removeFromParent();
         };
         _tween.animate("y",fightRes.y - 30);
         _gl.addTween(_tween);
      }

      public function checkSkillB() : void
      {
         if(skillB && GlobalData.skillBoo)
         {
            GlobalData.skillBoo = false;
            // A global passive can still have a valid target after this lane
            // is cleared. Keep checking it when its cast range crosses lanes.
            if(!GameMap.currentMap || GameMap.currentMap.isEnd() || (GameMap.currentMap.isEnd(line) && skillB.getCastRange() <= GameMapConfig.LINE_POS))
            {
               return;
            }
            skillB.checkUse();
         }
      }

      public function checkSkill() : Boolean
      {
         var _loc1_:Boolean = false;
         if(buffs["silence"])
         {
            // This bond permits only Yasuo's ready captain skill, not his Q
            // or book. checkUse still owns cooldown and target validation.
            if(yasuoCastSilenced104() && isLeader && skill1 && GameMap.currentMap && !GameMap.currentMap.isEnd(line))
               return skill1.checkUse();
            return _loc1_;
         }
         if(GameMap.currentMap.isEnd(line))
         {
            return _loc1_;
         }
         if(skill2)
         {
            if(skill2.checkUse())
            {
               _loc1_ = true;
            }
            if(GameMap.currentMap.isEnd(line))
            {
               return _loc1_;
            }
         }
         if(skill0)
         {
            if(skill0.checkUse())
            {
               _loc1_ = true;
            }
            if(GameMap.currentMap.isEnd(line))
            {
               return _loc1_;
            }
         }
         if(isLeader && skill1)
         {
            if(skill1.checkUse())
            {
               _loc1_ = true;
            }
         }
         return _loc1_;
      }

      public function findAimList(param1:Vector.<Avatar>, param2:Function = null, param3:int = -1, param4:Boolean = false) : Vector.<Avatar>
      {
         var _loc7_:int = 0;
         var _loc6_:* = undefined;
         var _loc8_:int = 0;
         var _loc5_:Avatar = null;
         _loc6_ = new Vector.<Avatar>();
         if(param3 == 0)
         {
            if(param1.indexOf(this) != -1)
            {
               _loc6_.push(this);
            }
            return _loc6_;
         }
         if(param3 < 0)
         {
            param3 = getRange();
         }
         if(param3 > GameMapConfig.LINE_POS)
         {
            _loc7_ = -1;
         }
         else
         {
            _loc7_ = line;
         }
         _loc8_ = 0;
         while(_loc8_ < param1.length)
         {
            _loc5_ = param1[_loc8_];
            if(_loc5_)
            {
               if(!(_loc7_ >= 0 && _loc5_.line != _loc7_))
               {
                  if(!(param4 && _loc5_.getEffectiveActionType() == 3))
                  {
                     if(_loc5_.hp > 0 && Math.abs(pos - _loc5_.pos) <= param3)
                     {
                        _loc6_.push(_loc5_);
                     }
                  }
               }
            }
            _loc8_++;
         }
         if(_loc6_.length == 0)
         {
            return _loc6_;
         }
         if(Boolean(param2))
         {
            _loc6_ = Tools.sortVector(_loc6_,param2);
         }
         return _loc6_;
      }

      public function findAim(param1:Vector.<Avatar>, param2:Function = null, param3:int = -1, param4:Boolean = false) : Avatar
      {
         param1 = findAimList(param1,param2,param3,param4);
         if(param1.length > 0)
         {
            return param1[0];
         }
         return null;
      }

      public function getSortOnFun() : Function
      {
         var _loc1_:AvatarData = avatarData;
         var _baseSort:Function;
         if(getEffectiveActionType() == 1)
         {
            _baseSort = sortOnPos;
         }
         else if(getEffectiveActionType() == 2)
         {
            _baseSort = sortOnHpLoss;
         }
         else
         {
            _baseSort = sortOnDamage;
         }
         if(manualFocusTarget && manualFocusTarget.hp > 0 && manualFocusTarget.team != team)
         {
            var _focus:Avatar = manualFocusTarget;
            var _fallback:Function = _baseSort;
            return function(param1:Avatar,param2:Avatar):int
            {
               if(param1 === _focus && param2 !== _focus) return -1;
               if(param2 === _focus && param1 !== _focus) return 1;
               return _fallback(param1,param2);
            };
         }
         return _baseSort;
      }

      public function setManualFocusTarget(param1:Avatar) : void
      {
         manualFocusTarget = param1 && param1.hp > 0 && param1.team != team ? param1 : null;
      }

      public function clearManualFocusTarget(param1:Avatar = null) : void
      {
         if(param1 == null || manualFocusTarget === param1)
         {
            manualFocusTarget = null;
         }
      }

      protected function sortOnPos(param1:Avatar, param2:Avatar) : int
      {
         if(param1 == this)
         {
            return -1;
         }
         if(param2 == this)
         {
            return 1;
         }
         if(param1.team != team)
         {
            if(param1.buffs["taunt"] && !param2.buffs["taunt"])
            {
               return -1;
            }
            if(param2.buffs["taunt"] && !param1.buffs["taunt"])
            {
               return 1;
            }
         }
         var _loc4_:int = Math.abs(line - param1.line) * (GameMapConfig.LINE_POS + 1) + Math.abs(pos - param1.pos);
         var _loc3_:int = Math.abs(line - param2.line) * (GameMapConfig.LINE_POS + 1) + Math.abs(pos - param2.pos);
         if(_loc4_ < _loc3_)
         {
            return -1;
         }
         if(_loc4_ > _loc3_)
         {
            return 1;
         }
         return 0;
      }

      protected function sortOnHpLoss(param1:Avatar, param2:Avatar) : int
      {
         if(param1.team != team)
         {
            if(param1.buffs["taunt"] && !param2.buffs["taunt"])
            {
               return -1;
            }
            if(param2.buffs["taunt"] && !param1.buffs["taunt"])
            {
               return 1;
            }
         }
         var _loc3_:int = param1.hpMax - param1.hp - (param2.hpMax - param2.hp);
         if(_loc3_ > 0)
         {
            return -1;
         }
         if(_loc3_ < 0)
         {
            return 1;
         }
         if(param1.hp < param2.hp)
         {
            return -1;
         }
         if(param1.hp > param2.hp)
         {
            return 1;
         }
         return 0;
      }

      protected function sortOnDamage(param1:Avatar, param2:Avatar) : int
      {
         if(param1.team != team)
         {
            if(param1.buffs["taunt"] && !param2.buffs["taunt"])
            {
               return -1;
            }
            if(param2.buffs["taunt"] && !param1.buffs["taunt"])
            {
               return 1;
            }
         }
         var _loc4_:int = param1.getDamage() * (1 + param1.checkTalent(1));
         var _loc3_:int = param2.getDamage() * (1 + param2.checkTalent(1));
         if(_loc4_ > _loc3_)
         {
            return -1;
         }
         if(_loc4_ < _loc3_)
         {
            return 1;
         }
         return 0;
      }

      public function clearUI() : void
      {
         clearLimitBreakEdge(m_avatarRes);
         if(m_avatarRes)
         {
            StarlingTools.removeChildrenClear(m_avatarRes);
            m_avatarRes.removeFromParent(true);
            m_avatarRes = null;
         }
      }

      public function clearRes() : void
      {
         clearLimitBreakEdge();
         var _loc1_:* = null;
         if(m_fightRange)
         {
            m_fightRange.removeFromParent(true);
            m_fightRange = null;
         }
         if(m_fightRes)
         {
            m_fightRes.removeChildren();
         }
         if(m_icon)
         {
            if(m_icon.filter)
            {
               m_icon.filter.clearCache();
               m_icon.filter.dispose();
               m_icon.filter = null;
            }
         }
         if(equips)
         {
            for each(_loc1_ in equips)
            {
               _loc1_.clear();
            }
         }
         equips = null;
         m_icon = null;
         m_buff = null;
         m_avatarRes = null;
         m_fightRes = null;
         m_fightBg = null;
         m_fightRange = null;
         m_actionNum = null;
         if(m_tf)
         {
            m_tf.removeFromParent(true);
            m_tf = null;
         }
      }

      public function clearData() : void
      {
         if(skill0)
         {
            skill0.clear();
         }
         if(skill1)
         {
            skill1.clear();
         }
         if(skill2)
         {
            skill2.clear();
         }
         if(skillB)
         {
            skillB.clear();
         }
         if(talent)
         {
            talent.clear();
         }
         clearRes();
         talent = null;
         skill0 = null;
         skill1 = null;
         skill2 = null;
         skillB = null;
         buffs = null;
      }

      public function clear() : void
      {
         this.clearUI();
         this.clearData();
      }

      public function allClear() : void
      {
         clearUI();
         clearRes();
         clearData();
      }

      // BEGIN ABYSS_PASSIVES_104
      // ---- Abyss relic equipment passives -------------------------------------
      // Spec: docs/roguelite-abyss-equip-passive.md (server: abyss_equip_passives.py).
      // B-class affixes come from snapshot.equip_passives and never touch skillB.
      // A-class affixes come from snapshot.skill.abyss_relic_A and apply only inside
      // the owner's own small-skill (skill0) cast context. Abyss-standardized
      // snapshots carry neither field and are ignored even if one is sent.
      public var equipPassives104:Array = null;
      public var abyssRelicA104:Object = null;
      public var abyssReduction104:Number = 0;
      public var abyssRevived104:Boolean = false;
      public var abyssRecovered104:Boolean = false;
      public var abyssDodgeRound104:int = -1;
      public var abyssDodgeCount104:int = 0;
      public var abyssDots104:Array = null;
      public var abyssToken104:String = null;
      // relic_reflect / relic_lifesteal while that settlement is running.
      public static var abyssOrigin104:String = null;
      // Optional event trace (tests); null in the game.
      public static var abyssEvents104:Array = null;

      public function loadAbyssPassives104(data:Object) : void
      {
         equipPassives104 = null;
         abyssRelicA104 = null;
         abyssReduction104 = 0;
         abyssRevived104 = false;
         abyssRecovered104 = false;
         abyssDodgeRound104 = -1;
         abyssDodgeCount104 = 0;
         abyssDots104 = null;
         if(!data || data.abyss_standardized) return;
         if(data.equip_passives is Array && data.equip_passives.length) equipPassives104 = (data.equip_passives as Array).concat();
         if(data.skill && data.skill.abyss_relic_A) abyssRelicA104 = data.skill.abyss_relic_A;
      }

      public function abyssEffect104(kind:int) : Object
      {
         if(!equipPassives104) return null;
         for each(var affix:Object in equipPassives104)
         {
            if(affix && int(affix.id) == kind) return affix;
         }
         return null;
      }

      private static function abyssRound104() : int
      {
         return GameMap.currentMap ? GameMap.currentMap.roundNum : 0;
      }

      private static function abyssTrace104(event:String, owner:Avatar, target:Avatar, fields:Object = null) : void
      {
         if(!abyssEvents104) return;
         var row:Object = {"event":event,"round":abyssRound104(),
            "owner":owner ? (owner.abyssToken104 ? owner.abyssToken104 : owner.id) : null,
            "target":(target || owner) ? ((target || owner).abyssToken104 ? (target || owner).abyssToken104 : (target || owner).id) : null};
         if(fields) for(var key:String in fields) row[key] = fields[key];
         abyssEvents104.push(row);
      }

      // Once per battle, before the first action: captain auras, then entry shields
      // and the captain's ultimate preparation.
      public static function abyssInitialize104(teamA:*, teamB:*) : void
      {
         var rosters:Array = [teamA,teamB];
         for each(var roster:* in rosters)
         {
            if(!roster) continue;
            var unit:Avatar;
            for each(var captain:Avatar in roster)
            {
               if(!captain.isLeader || captain.hp <= 0) continue;
               var reduction:Object = captain.abyssEffect104(15);
               if(reduction)
               {
                  for each(unit in roster)
                  {
                     unit.abyssReduction104 = 1 - (1 - unit.abyssReduction104) * (1 - Number(reduction.value));
                     abyssTrace104("captain_aura",captain,unit,{"kind":15,"value":reduction.value});
                  }
               }
               var command:Object = captain.abyssEffect104(16);
               if(command)
               {
                  for each(unit in roster)
                  {
                     unit.ap = int(unit.ap * (1 + Number(command.value)));
                     abyssTrace104("captain_aura",captain,unit,{"kind":16,"value":command.value});
                  }
               }
            }
            for each(unit in roster)
            {
               if(!unit.equipPassives104) continue;
               for each(var affix:Object in unit.equipPassives104)
               {
                  var kind:int = int(affix.id);
                  if(kind == 1)
                  {
                     unit.abyssShield104(unit,int(unit.hpMax * Number(affix.value)),3,"entry_shield");
                  }
                  else if(kind == 19 && unit.isLeader && unit.skill1)
                  {
                     unit.skill1.m_cooldownNum = Math.max(0,unit.skill1.m_cooldownNum - 2);
                     abyssTrace104("leader_preparation",unit,unit,{"value":unit.skill1.m_cooldownNum});
                  }
               }
            }
         }
      }

      public function abyssShield104(source:Avatar, amount:int, rounds:int, event:String) : void
      {
         var previous:String = abyssOrigin104;
         abyssOrigin104 = "relic_shield";
         try { addBuff("shield",rounds,amount,0,-1,source); }
         finally { abyssOrigin104 = previous; }
         abyssTrace104(event,source,this,{"amount":amount,"duration":rounds});
      }

      // 圣佑: healing and shields cast by the wearer, applied once.
      public function abyssAmplifyHeal104(amount:Number) : Number
      {
         var affix:Object = abyssEffect104(14);
         return affix ? int(amount * (1 + Number(affix.value))) : amount;
      }

      // The owner's small-skill cast context, or null (ultimate, normal attack,
      // skillB and other casters never inherit it).
      private static function abyssNormalContext104(source:Avatar) : Object
      {
         if(!source || !source.abyssRelicA104) return null;
         var context:Object = currentAbilityAttack();
         if(!context || context.owner !== source || context.kind != "active") return null;
         if(context.abyssNormalOwner104 !== source && (!source.skill0 || context.skill !== source.skill0)) return null;
         if(!(context.abyssHits104 is Array)) context.abyssHits104 = [];
         return context;
      }

      // Deferred hits retain the original cast, including its once-per-target set.
      private static function abyssCaptureContext104(source:Avatar) : Object
      {
         var context:Object = abyssNormalContext104(source);
         return context ? {owner:source,skill:context.skill,hits:context.abyssHits104} : null;
      }

      private static function abyssRestoreContext104(context:Object, saved:Object) : void
      {
         if(!saved || saved.owner !== context.owner) return;
         context.skill = saved.skill;
         context.abyssHits104 = saved.hits;
         context.abyssNormalOwner104 = saved.owner;
      }

      public function abyssConversion104() : Number
      {
         var context:Object = abyssNormalContext104(this);
         return context && int(abyssRelicA104.id) == 20 ? Number(abyssRelicA104.value) : 0;
      }

      private function abyssRemoveDots104(kind:String) : void
      {
         if(!abyssDots104 || (kind != "poison" && kind != "burn")) return;
         var kept:Array = [];
         for each(var dot:Object in abyssDots104) if(dot.kind != kind) kept.push(dot);
         abyssDots104 = kept.length ? kept : null;
      }

      public function abyssShieldMultiplier104() : Number
      {
         var affix:Object = abyssEffect104(12);
         return affix ? 1 + Number(affix.value) : 1;
      }

      // 先声夺人 -> 同心 -> A-class hp line -> 坚城 (target), after existing modifiers.
      public function abyssModifyDamage104(amount:int, source:Avatar, damageType:int, dotKind:String) : int
      {
         var before:int = amount;
         if(source)
         {
            var affix:Object = source.abyssEffect104(2);
            if(affix && abyssRound104() == 0) amount = Tools.toInt(amount * (1 + Number(affix.value)));
            affix = source.abyssEffect104(17);
            if(affix)
            {
               var count:int = 0;
               var allies:* = GameMap.currentMap ? GameMap.currentMap.getAliveList(source.team) : null;
               for each(var ally:Avatar in allies)
               {
                  if(ally !== source && ally.hp > 0 && ally.line == source.line) count++;
               }
               amount = Tools.toInt(amount * (1 + Number(affix.value) * count));
            }
            var context:Object = abyssNormalContext104(source);
            affix = context ? source.abyssRelicA104 : null;
            if(affix && damageType >= 1 && damageType <= 3 && !dotKind)
            {
               var ratio:Number = hp / Math.max(1,hpMax);
               if(int(affix.id) == 8 && ratio > 0.5 || int(affix.id) == 9 && ratio < 0.5) amount = Tools.toInt(amount * (1 + Number(affix.value)));
            }
         }
         if(abyssReduction104) amount = Tools.toInt(amount * (1 - abyssReduction104));
         if(amount != before) abyssTrace104("damage_adjust",source || this,this,{"before":before,"after":amount});
         return amount;
      }

      // 复苏之羽, after bless and Tryndamere undying failed to save the unit.
      public function abyssTryRevive104() : Boolean
      {
         var affix:Object = abyssEffect104(4);
         if(!affix || abyssRevived104) return false;
         abyssRevived104 = true;
         hp = Math.max(1,int(hpMax * Number(affix.value)));
         removeAllDebuff();
         abyssTrace104("revive",this,this,{"amount":hp});
         return true;
      }

      // 坚守誓约 -> 嗜血 (attacker) -> 荆棘之躯 -> A-class status, after a hit settled.
      public function abyssAfterDamage104(source:Avatar, healthDamage:Number, shieldDamage:Number, damageType:int, dotKind:String) : void
      {
         var total:Number = Math.max(0,healthDamage) + Math.max(0,shieldDamage);
         var amount:int;
         var previous:String;
         var affix:Object = abyssEffect104(3);
         if(affix && !abyssRecovered104 && hp > 0 && hp < hpMax * 0.5)
         {
            abyssRecovered104 = true;
            amount = hpMax - hp;
            hp = hpMax;
            abyssTrace104("full_recovery",this,this,{"amount":amount});
            if(Number(affix.shield_rate) > 0) abyssShield104(this,int(hpMax * Number(affix.shield_rate)),3,"recovery_shield");
            if(GameMapLayer.gl) GameMapLayer.gl.delayCall(refreshHp,GameMap.actionDelay,hp,false,shieldValue104(),hpMax);
         }
         if(!source || total <= 0) return;
         affix = source.abyssEffect104(7);
         if(affix && source.hp > 0)
         {
            amount = int(total * Number(affix.value));
            previous = abyssOrigin104;
            abyssOrigin104 = "relic_lifesteal";
            var healed:int = 0;
            try
            {
               healed = source.injured(amount,1,null,4,null,false,source);
            }
            finally
            {
               abyssOrigin104 = previous;
            }
            abyssTrace104("lifesteal",source,source,{"amount":amount,"healed":healed,"source_tag":"relic_lifesteal"});
         }
         affix = abyssEffect104(5);
         if(affix && damageType >= 1 && damageType <= 3 && !dotKind && abyssOrigin104 != "relic_reflect" && source.hp > 0 && source.team != team)
         {
            amount = int(total * Number(affix.value));
            abyssTrace104("reflect",this,source,{"amount":amount,"source_tag":"relic_reflect"});
            previous = abyssOrigin104;
            abyssOrigin104 = "relic_reflect";
            try
            {
               // Absolute true damage: no crit/global multiplier/toughness (derived).
               source.injured(amount,1,null,3,null,false,this,null,"",true);
            }
            finally
            {
               abyssOrigin104 = previous;
            }
         }
         var context:Object = abyssNormalContext104(source);
         var normal:Object = context ? source.abyssRelicA104 : null;
         if(!normal || dotKind || damageType < 1 || damageType > 3 || context.abyssHits104.indexOf(this) >= 0 || hp <= 0) return;
         context.abyssHits104.push(this);
         var kind:int = int(normal.id);
         if(kind == 10 || kind == 11)
         {
            var dotName:String = kind == 10 ? "burn" : "poison";
            var dotAmount:int = int(source.abyssApWithTalent104() * Number(normal.value));
            if(yasuoImmune104(dotName)) return;
            if(s2AnnieImmune()) return;
            if(buffs["purify"])
            {
               removeBuff("purify",true);
               return;
            }
            var kept:Array = [];
            for each(var row:Object in abyssDots104)
            {
               if(row.kind != dotName || row.source !== source) kept.push(row);
            }
            kept.push({"kind":dotName,"source":source,"amount":dotAmount,"left":2});
            abyssDots104 = kept;
            s2AnnieStatus(dotName);
            if(dotName=="burn") sixReactionBurnChanged105();
            abyssTrace104("normal_dot",source,this,{"kind":dotName,"amount":dotAmount,"duration":2});
         }
         else if(kind == 13 && Random.getRandom(1000000) < int(Number(normal.value) * 1000000))
         {
            addBuff("stun",1,0,0,-1,source);
            abyssTrace104("normal_stun",source,this,{"duration":1});
         }
      }

      public function abyssApWithTalent104() : int
      {
         return Tools.toInt(getDamage() + getDamage() * checkTalent(1));
      }

      // Relic DOT layers tick on the holder's turn before native buffs.
      public function abyssTickDots104() : void
      {
         if(!abyssDots104 || !abyssDots104.length) return;
         for each(var dot:Object in abyssDots104.concat())
         {
            if(hp <= 0) break;
            if(!abyssDots104 || abyssDots104.indexOf(dot) < 0) continue;
            abyssTrace104("dot_tick",dot.source as Avatar,this,{"kind":dot.kind,"amount":dot.amount});
            injured(int(dot.amount),1,null,dot.kind == "poison" ? 6 : 7,null,false,dot.source as Avatar,null,String(dot.kind));
            dot.left = int(dot.left) - 1;
            if(int(dot.left) <= 0 && abyssDots104)
            {
               var at:int = abyssDots104.indexOf(dot);
               if(at >= 0) abyssDots104.splice(at,1);
            }
         }
      }

      public function hasAbyssDot104(kind:String) : Boolean
      {
         for each(var dot:Object in abyssDots104)
         {
            if(dot && dot.kind == kind) return true;
         }
         return false;
      }

      // 疾风步: shield after a successful dodge, at most twice per global round.
      public function abyssOnDodge104() : void
      {
         if(hp <= 0) return;
         var affix:Object = abyssEffect104(6);
         if(!affix) return;
         var nowRound:int = abyssRound104();
         if(abyssDodgeRound104 != nowRound)
         {
            abyssDodgeRound104 = nowRound;
            abyssDodgeCount104 = 0;
         }
         if(abyssDodgeCount104 >= 2) return;
         abyssDodgeCount104++;
         abyssShield104(this,int(hpMax * Number(affix.value)),2,"dodge_shield");
      }

      // 召唤契约: the owner's 8-stat snapshot before the summon's own inheritance ratios.
      public function abyssSummonPanel104(panel:Object) : Object
      {
         var affix:Object = abyssEffect104(18);
         if(!affix || !panel) return panel;
         var result:Object = {};
         for(var key:String in panel) result[key] = panel[key];
         for each(var stat:String in ["hpMax","ap","dePh","deMa","hit","flee","crit","tough"])
         {
            if(result[stat] != null) result[stat] = int(Number(result[stat]) * (1 + Number(affix.value)));
         }
         return result;
      }
      // ---- end Abyss relic equipment passives ---------------------------------
      // END ABYSS_PASSIVES_104

   }
}
